<?php
/* Smarty version 4.2.1, created on 2023-03-02 08:42:22
  from '/var/www/html/sib/webapp/app/core/template/base/baseAjax.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_640099ae18aa23_87396584',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '1d3e371edf512169e95ec666ed1b7074cd8fa3c3' => 
    array (
      0 => '/var/www/html/sib/webapp/app/core/template/base/baseAjax.tpl',
      1 => 1668028010,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_640099ae18aa23_87396584 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender(((string)$_smarty_tpl->tpl_vars['subpage']->value), $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, true);
}
}
