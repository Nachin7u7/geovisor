<?php
/* Smarty version 4.2.1, created on 2022-11-09 17:25:50
  from '/var/www/html/sib/webapp/app/sib/module/index/snippet/index/view/index.css.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_636c1adea6e269_43130530',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6d86a7c814e44d4cbf69e279d15e99bcf3c4a14d' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/index/snippet/index/view/index.css.tpl',
      1 => 1668028010,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_636c1adea6e269_43130530 (Smarty_Internal_Template $_smarty_tpl) {
?>
<style>
 div[rel="color_0"]{
     border-bottom: 3px solid #FFB900!important;
 }
 div[rel="color_1"]{
     border-bottom: 3px solid #00C6DE!important;
 }
 div[rel="color_2"]{
     border-bottom: 3px solid #FF506D!important;
 }
 div[rel="color_3"]{
     border-bottom: 3px solid #00C0A3!important;
 }
 div[rel="color_4"]{
     border-bottom: 3px solid #5067E1!important;
 }
 div[rel="color_5"]{
     border-bottom: 3px solid #FFB900!important;
 }
 div[rel="color_6"]{
     border-bottom: 3px solid #00C6DE!important;
 }
 div[rel="color_7"]{
     border-bottom: 3px solid #FF506D!important;
 }
 div[rel="color_8"]{
     border-bottom: 3px solid #00C0A3!important;
 }
 div[rel="color_9"]{
     border-bottom: 3px solid #5067E1!important;
 }

</style>
<?php }
}
