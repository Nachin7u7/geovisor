<?php
/* Smarty version 4.2.1, created on 2022-11-11 00:11:24
  from '/var/www/html/sib/webapp/app/sib/module/user/snippet/permits/view/form/form.css.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_636dcb6cc815b3_03680702',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '10efd49b312129e11a348126f5c0508e38318c75' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/user/snippet/permits/view/form/form.css.tpl',
      1 => 1668028010,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_636dcb6cc815b3_03680702 (Smarty_Internal_Template $_smarty_tpl) {
?>
    <style>
        .custom-file-label::after {
            content: "<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'gl_search_file');?>
" !important;
        }

        .form-table .dtrg-level-0 td{
            background: #d2f0ff !important;
            color: #00709b;
            border-top: 2px solid #c0d8e6;
            padding:2px 2px 2px 10px!important;
            font-weight: normal !important;

        }
        .form-table .dtrg-level-0 td::before {
            font-family: "Font Awesome 5 Free";
            font-weight: 900;
            content: "\f135";
            margin-right: 5px;
        }

        .form-table .dtrg-level-1 td{
            background: #f1fed1 !important;
            color: #5c721b;
            /*border-top: 2px solid #c0d8e6;*/
            padding:2px 2px 2px 15px!important;
        }
        .form-table .dtrg-level-1 td::before {
            font-family: "Font Awesome 5 Free";
            font-weight: 900;
            content: "\f103";
            margin-right: 5px;
        }

        .form-table th{
            padding: 3px!important;
        }

        .form-table tr.even td, .form-table tr.odd td {
            padding: 7px 3px 7px 10px; !important;
        }
    </style>
<?php }
}
