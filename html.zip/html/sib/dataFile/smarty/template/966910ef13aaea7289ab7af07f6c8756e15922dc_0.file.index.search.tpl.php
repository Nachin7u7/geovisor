<?php
/* Smarty version 4.2.1, created on 2023-01-10 11:32:09
  from '/var/www/html/sib/webapp/app/setting/module/app/snippet/group/view/index.search.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_63bd84f940d403_15668310',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '966910ef13aaea7289ab7af07f6c8756e15922dc' => 
    array (
      0 => '/var/www/html/sib/webapp/app/setting/module/app/snippet/group/view/index.search.tpl',
      1 => 1668028010,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_63bd84f940d403_15668310 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="row alert alert-custom alert-light-primary fade show mb-5" role="alert" >
    <div class="col-lg-6 alert-text">
        <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'filterName');?>
:</label>
        <input type="text" class="filtro-buscar-text form-control" placeholder="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'filterNameHolder');?>
" data-col-index="0">
    </div>

    </div>
<div class="m-separator m-separator--md m-separator--dashed"></div>
<?php }
}
