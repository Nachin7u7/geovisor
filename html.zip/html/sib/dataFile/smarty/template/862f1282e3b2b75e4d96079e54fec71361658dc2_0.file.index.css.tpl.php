<?php
/* Smarty version 4.2.1, created on 2023-09-20 09:41:10
  from '/var/www/html/sib/webapp/app/sib/module/zoologia_ormitologia/snippet/datoscolecta/view/index.css.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_650af676208fb3_91195978',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '862f1282e3b2b75e4d96079e54fec71361658dc2' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/zoologia_ormitologia/snippet/datoscolecta/view/index.css.tpl',
      1 => 1678278586,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_650af676208fb3_91195978 (Smarty_Internal_Template $_smarty_tpl) {
?>
    <style>
        .select2-results__group{
            background: #e7f1f6;
            border-bottom: 2px solid #006ba2;
        }

    </style>
<?php }
}
