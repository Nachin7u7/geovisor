<?php
/* Smarty version 4.2.1, created on 2023-11-06 08:28:22
  from '/var/www/html/sib/webapp/app/sib/module/taxonomia_p_invertebrado/snippet/index/view/index.js.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_6548dbe6c90594_54112707',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '5a70f5b1d3b8605b79bd63864b63677be64b2135' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/taxonomia_p_invertebrado/snippet/index/view/index.js.tpl',
      1 => 1694087965,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6548dbe6c90594_54112707 (Smarty_Internal_Template $_smarty_tpl) {
echo '<script'; ?>
>

    var table_list;
    var snippet_list = function() {
        "use strict";
        var urlsys = '<?php echo $_smarty_tpl->tpl_vars['path_url']->value;?>
';
        var initTable = function() {
            let table_list_var = $('#index_list');
            let export_title = "<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'dataTableExportTitle');?>
";
            let noExport = tableSetting.noExport;
            // begin first table
            table_list = table_list_var.DataTable({
                initComplete: function(settings, json) {
                    $('#index_list').removeClass('d-none');
                },
                keys: {
                    columns: noExport,
                    clipboard: false,
                },
                dom: tableSetting.dom,
                buttons: [
                    /*
                    {extend:'colvis',text:lngUyuni.dataTableWatch
                        ,columnText: function ( dt, idx, title ) {
                            return (idx+1)+': '+title;
                        }
                    },

                     */
                    {extend:'excelHtml5'
                        ,exportOptions: {columns: noExport}
                        , title: export_title
                    },
                    {extend:'pdfHtml5'
                        ,exportOptions: {columns: noExport}
                        , title: export_title
                        , download: 'open'

                        , pageSize: 'LETTER'
                        ,customize: function(doc) {
                            doc.styles.tableHeader.fontSize = 7;
                            doc.defaultStyle.fontSize = 7;
                            doc.pageMargins= [ 20, 20];
                        }
                    },
                    {extend:'print'
                        ,exportOptions: {columns: noExport}
                        ,text: lngUyuni.dataTablePrint
                    }

                ],
                responsive: true,
                colReorder: true,
                language: {"url": "/language/js/datatable."+lng+".json"},
                lengthMenu: [[10, 25, 50,-1], [10, 25, 50, lngUyuni.dataTableAll]],
                pageLength: 10,
                //order: [[ 1, "asc" ]], // Por que campo ordenara al momento de desplegar
                InfoFiltered: false,
                searchDelay: 500,
                processing: true,
                serverSide: true,
                ajax: {
                    url: urlsys+'/list',
                    type: 'POST',
                    data: {},
                },
                columns: [
                    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['gridItem']->value, 'row', false, 'idx');
$_smarty_tpl->tpl_vars['row']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['idx']->value => $_smarty_tpl->tpl_vars['row']->value) {
$_smarty_tpl->tpl_vars['row']->do_else = false;
?>
                    <?php if ($_smarty_tpl->tpl_vars['idx']->value != 0) {?>,<?php }?>{data: '<?php if ($_smarty_tpl->tpl_vars['row']->value['as']) {
echo $_smarty_tpl->tpl_vars['row']->value['as'];
} else {
echo $_smarty_tpl->tpl_vars['row']->value['field'];
}?>'<?php if ($_smarty_tpl->tpl_vars['row']->value['responsive']) {?>, responsivePriority: -1<?php }?>}
                    <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                ],
                /*
                rowGroup: {
                    dataSrc: ['parentname','groupname']
                },

                 */
                columnDefs: [
                    {
                        targets: -1,
                        width: "90px",
                        className: 'noExport',
                        orderable: false,
                        searchable: false,
                        render: function(data, type, full, meta) {
                            var boton = '<div class="btn-group btn-group-sm " role="group" aria-label="Accion">';
                            var lbEdit = <?php if ($_smarty_tpl->tpl_vars['privFace']->value['edit'] == 1) {?>lngUyuni.btnEdit<?php } else { ?>lngUyuni.btnViewData<?php }?>;
                            boton += '<a href="javascript:snippet_list.update(\''+data+'\');" class="btn btn-success btn-sm" title="'+lbEdit+'">'+lbEdit+'</a>';
                            <?php if ($_smarty_tpl->tpl_vars['privFace']->value['edit'] == 1 && $_smarty_tpl->tpl_vars['privFace']->value['delete'] == 1) {?>
                            boton += '<a href="javascript:snippet_list.delete(\''+data+'\');" class="btn btn-icon btn-light-danger btn-sm" title="'+lngUyuni.btnDelete+'"><i class="flaticon-delete-1"></i></a>';
                            <?php }?>
                            boton += '<div>';
                            return boton;
                        },
                    },
                    /*
                    {
                        targets: [0],
                        className:"text-left",
                        render: function(data,type,full,meta){
                            return '<span style="color: #0357ae;">' + data + ' </span>';
                        },
                    },
                    {
                        targets: [2,3,4],
                        className: "none",
                    },
                    {
                        targets: [3,5],
                        searchable: false,
                    },

                     */
                    {
                        targets: [-2,-3],
                        searchable: false,
                        className: "none",
                        render: function(data,type,full,meta){
                            if (data == null){ data = "";}
                            return '<span class="text-primary font-size-xs">' + data+ '</span>';
                        },
                    },

                ],
            });
        };

        /**
         * New and Update
         */
        //var btn_update = $('#btn_update');
        var btn_update = $('#btn_new');
        var handle_button_update = function(){
            btn_update.click(function(e){
                e.preventDefault();
                item_update("","new");
            });
        };

        var item_update = function(id,type){
            coreUyuni.itemUpdateIndex(id,type,urlsys);
        };
        /**
         * Delete
         */
        var  item_delete = function(id){
            var url = urlsys+"/"+id+"/delete";
            coreUyuni.itemDelete(id,url,table_list);
        };
        /**
         * Inicializar componentes
         */
        var handle_components = function(){
            coreUyuni.setComponents();
        };
        /**
         * Filtros
         */
        var handle_filtro = function () {
            coreUyuni.tableFilter();
        };

        return {
            //main function to initiate the module
            init: function() {
                initTable();
                handle_button_update();
                handle_components();
                handle_filtro();
            },
            update: function(id,type){
                item_update(id,type);
            },
            delete: function(id){
                item_delete(id);
            },
        };

    }();

    jQuery(document).ready(function() {
        $('#btn_new').removeClass('d-none');
        snippet_list.init();
    });
<?php echo '</script'; ?>
>
<?php }
}
