<?php
/* Smarty version 4.2.1, created on 2022-11-10 11:22:34
  from '/var/www/html/sib/webapp/app/core/template/frontend_core_72/_footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_636d173a356380_14832889',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '893cf065bb4247309ee42d9689af223320957b5d' => 
    array (
      0 => '/var/www/html/sib/webapp/app/core/template/frontend_core_72/_footer.tpl',
      1 => 1668028010,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_636d173a356380_14832889 (Smarty_Internal_Template $_smarty_tpl) {
?><!--begin::Footer-->
<div class="footer bg-white py-4 d-flex flex-lg-column" id="kt_footer">
    <!--begin::Container-->
    <div class="container-fluid d-flex flex-column flex-md-row align-items-center justify-content-between">
        <!--begin::Copyright-->
        <div class="text-dark order-2 order-md-1">
            <span class="text-muted font-weight-bold mr-2">2022-2023 ©
                <a href="http://www.mnhn.gob.bo/" target="_blank" class="text-dark-50 text-hover-primary">MNHN / SIB</a>
                - </span>
            <a href="http://seth.com.bo" target="_blank" class="text-dark-50 text-hover-primary">SETH Solution</a>
            <span class="text-muted font-weight-bold mr-2">| Uyuni v.<?php echo $_smarty_tpl->tpl_vars['version']->value;?>
</span>
        </div>
        <!--end::Copyright-->
        <!--begin::Nav-->
            </div>
    <!--end::Container-->
</div>
<!--end::Footer--><?php }
}
