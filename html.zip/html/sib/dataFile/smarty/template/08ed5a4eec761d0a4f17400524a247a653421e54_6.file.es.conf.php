<?php /* Smarty version 4.2.1, created on 2023-01-10 11:32:09
         compiled from '/var/www/html/sib/webapp/app/setting/module/app/snippet/group/language/es.conf' */ ?>
<?php
/* Smarty version 4.2.1, created on 2023-01-10 11:32:09
  from '/var/www/html/sib/webapp/app/setting/module/app/snippet/group/language/es.conf' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_63bd84f934e807_38838788',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '08ed5a4eec761d0a4f17400524a247a653421e54' => 
    array (
      0 => '/var/www/html/sib/webapp/app/setting/module/app/snippet/group/language/es.conf',
      1 => 1668028010,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_63bd84f934e807_38838788 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigVars($_smarty_tpl, array (
  'sections' => 
  array (
    'index' => 
    array (
      'vars' => 
      array (
        'title' => 'Lista de grupos de la aplicación',
        'btnNew' => 'Nueva grupo',
        'filterName' => 'Nombre',
        'filterNameHolder' => 'Buscar por nombre de aplicación',
        'filterAppStatus' => 'Estado de la aplicación',
        'filterAppStatusSelectAll' => 'Todos los estados',
        'dataTableExportTitle' => 'Lista de grupos de la aplicación',
      ),
    ),
    'tableIndex' => 
    array (
      'vars' => 
      array (
        'tableName' => 'Nombre',
        'tableFolder' => 'Carpeta',
        'tableId' => 'Id',
        'tableOrder' => 'Orden',
        'tableClass' => 'Icon',
        'tableDescription' => 'Descripcion',
        'tableStatus' => 'Estado',
      ),
    ),
    'formItem' => 
    array (
      'vars' => 
      array (
        'title' => 'Grupo',
        'message' => 'Podrás realizar el registro y configuración de una aplicación para el FrameWork Uyuni',
        'fieldName' => 'Nombre del grupo',
        'fieldNameLength' => 'Tiene que ser mayor o igual a 3 caracteres',
        'fieldNameMsg' => 'Ingrese el nombre del grupo',
        'fielClass' => 'Icono - Class',
        'fielClassMsg' => 'Ingrese la "clase" del ícono (CSS)',
        'fielOrder' => 'Orden',
        'fielOrderMsg' => 'Ingrese el número de posición',
        'fieldActive' => 'Activo',
        'fieldActiveMsg' => 'Para poder activar o desactivar el grupo para ver',
        'fieldDescription' => 'Descripción',
      ),
    ),
  ),
  'vars' => 
  array (
  ),
));
}
}
