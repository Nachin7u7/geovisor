<?php
/* Smarty version 4.2.1, created on 2024-05-27 12:01:36
  from '/var/www/html/sib/webapp/app/sib/module/taxonomia_mastozoologia/snippet/general/view/index.css.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_6654ae60aca5c2_92992225',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '9921d472fd240f62aaed0522d12d8561f45a2ba4' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/taxonomia_mastozoologia/snippet/general/view/index.css.tpl',
      1 => 1686678877,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6654ae60aca5c2_92992225 (Smarty_Internal_Template $_smarty_tpl) {
?>
    <style>
        .select2-results__group{
            background: #e7f1f6;
            border-bottom: 2px solid #006ba2;
        }

    </style>
<?php }
}
