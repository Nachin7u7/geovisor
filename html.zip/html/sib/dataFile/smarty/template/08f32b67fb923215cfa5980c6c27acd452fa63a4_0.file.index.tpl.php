<?php
/* Smarty version 4.2.1, created on 2023-09-14 22:09:55
  from '/var/www/html/sib/webapp/app/sib/module/zoologia_anfibios/snippet/lugarcolecta/view/formprincipal/index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_6503bcf38de666_33513611',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '08f32b67fb923215cfa5980c6c27acd452fa63a4' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/zoologia_anfibios/snippet/lugarcolecta/view/formprincipal/index.tpl',
      1 => 1688391178,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:formprincipal/index.css.tpl' => 1,
    'file:formprincipal/index.js.tpl' => 1,
  ),
),false)) {
function content_6503bcf38de666_33513611 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_checkPlugins(array(0=>array('file'=>'/var/www/html/sib/vendor/smarty/smarty/libs/plugins/function.html_options.php','function'=>'smarty_function_html_options',),));
$_smarty_tpl->_subTemplateRender("file:formprincipal/index.css.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
<div class="card card-custom gutter-b ">
    <!--begin::Form-->
    <form method="POST"
          action="<?php echo $_smarty_tpl->tpl_vars['path_url']->value;?>
/<?php echo $_smarty_tpl->tpl_vars['subcontrol']->value;?>
_/<?php if ($_smarty_tpl->tpl_vars['type']->value == "update") {
echo $_smarty_tpl->tpl_vars['id']->value;?>
/<?php }?>save.principal/"
          id="general_form">

        <div class="card-header py-3">
            <div class="card-title  m-0">
                <span class="card-icon"><i class="flaticon2-next text-dark-25"></i></span>
                <span class="font-weight-bold font-size-h4 text-primary"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'title_datos');?>
</span>
            </div>
        </div>

        <div class="card-body py-0">
            <div class="form-group">
                <div id="map" style="height:400px;"></div>
            </div>
            <div class="form-group row">
                <div class="col-lg-6">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_continent');?>
  <span class="text-danger bold">*</span> :</label>
                    <div class="input-group">
                        <input type="text" class="form-control"
                               name="item[continent]"
                               id="continent" required
                               value="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['item']->value['continent'], ENT_QUOTES, 'UTF-8', true);?>
"
                               data-fv-not-empty___message="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glFieldRequired');?>
" disabled
                        >
                        <div class="input-group-append"><span class="input-group-text"><i
                                        class="fas fa-map-marked-alt text-info"></i></span></div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_pais');?>
  <span class="text-danger bold">*</span> :</label>
                    <div class="input-group">
                        <input type="text" class="form-control"
                               name="item[country]"
                               id="country" required
                               value="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['item']->value['country'], ENT_QUOTES, 'UTF-8', true);?>
"
                               data-fv-not-empty___message="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glFieldRequired');?>
" disabled
                        >
                        <div class="input-group-append"><span class="input-group-text"><i
                                        class="fas fa-map-marked-alt text-info"></i></span></div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_departamento_id');?>
 <span class="text-danger bold">*</span> : </label>
                    <div class="input-group">
                        <select class="form-control m-select2 select2_general"
                                name="item[state_province_id]" id="state_province_id"
                                data-placeholder="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_Holder_departamento_id');?>
" <?php echo $_smarty_tpl->tpl_vars['privFace']->value['input'];?>

                                required
                                data-fv-not-empty___message="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glFieldRequired');?>
"
                        >
                            <option></option>
                            <?php echo smarty_function_html_options(array('options'=>$_smarty_tpl->tpl_vars['cataobj']->value['departamento'],'selected'=>$_smarty_tpl->tpl_vars['item']->value['state_province_id']),$_smarty_tpl);?>

                        </select>
                    </div>
                    <span class="form-text text-black-50"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_GroupMsg_departamento_id');?>
</span>
                </div>

                <div class="col-lg-4">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_municipio_id');?>
 <span class="text-danger bold">*</span> : </label>
                    <div class="input-group">
                        <select class="form-control m-select2 select2_general"
                                name="item[municipality_id]" id="municipality_id"
                                data-placeholder="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_Holder_municipio_id');?>
" <?php echo $_smarty_tpl->tpl_vars['privFace']->value['input'];?>

                                required
                                data-fv-not-empty___message="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glFieldRequired');?>
"
                        >
                            <option></option>
                            <?php echo smarty_function_html_options(array('options'=>$_smarty_tpl->tpl_vars['cataobj']->value['municipio'],'selected'=>$_smarty_tpl->tpl_vars['item']->value['municipality_id']),$_smarty_tpl);?>

                        </select>
                    </div>
                    <span class="form-text text-black-50"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_GroupMsg_municipio_id');?>
</span>
                </div>
                <div class="col-lg-4">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_locality');?>
:</label>
                    <div class="input-group">
                        <input type="text" class="form-control"
                               name="item[locality]"
                               id="locality"
                               value="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['item']->value['locality'], ENT_QUOTES, 'UTF-8', true);?>
"
                        >
                        <div class="input-group-append"><span class="input-group-text"><i
                                        class="fa fa-location-arrow text-info"></i></span></div>
                    </div>
                    <span class="form-text text-black-50"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_msg_locality');?>
</span>
                </div>
                <div class="col-lg-6">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'fiel_location_latitude_decimal');?>
  <span class="text-danger bold">*</span> :</label>
                    <div class="input-group">
                        <input type="text" class="form-control location_latitude_decimal"
                               name="item[location_latitude_decimal]"
                               id="location_latitude_decimal"
                               required
                               value="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['item']->value['location_latitude_decimal'], ENT_QUOTES, 'UTF-8', true);?>
"
                               data-fv-not-empty___message="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glFieldRequired');?>
"
                        >
                        <div class="input-group-append"><span class="input-group-text"><i
                                        class="fa fa-map-marker-alt text-danger"></i></span></div>
                    </div>
                    <span class="form-text text-black-50"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_msg_location_latitude_decimal');?>
</span>
                </div>
                <div class="col-lg-6">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'fiel_location_longitude_decimal');?>
  <span class="text-danger bold">*</span> :</label>
                    <div class="input-group">
                        <input type="text" class="form-control location_longitude_decimal"
                               id="location_longitude_decimal"
                               required
                               name="item[location_longitude_decimal]"
                               value="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['item']->value['location_longitude_decimal'], ENT_QUOTES, 'UTF-8', true);?>
"
                               data-fv-not-empty___message="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glFieldRequired');?>
"
                        >
                        <div class="input-group-append"><span class="input-group-text"><i
                                        class="fa fa-map-marker-alt text-danger"></i></span></div>
                    </div>
                    <span class="form-text text-black-50"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_msg_location_longitude_decimal');?>
</span>
                </div>
                <div class="col-lg-6">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_verbatim_latitude');?>
  <span class="text-danger bold">*</span> :</label>
                    <div class="input-group">
                        <input type="text" class="form-control"
                               name="item[verbatim_latitude]"
                               id="verbatim_latitude"
                               required
                               value="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['item']->value['verbatim_latitude'], ENT_QUOTES, 'UTF-8', true);?>
"
                               data-fv-not-empty___message="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glFieldRequired');?>
"
                        >
                        <div class="input-group-append"><span class="input-group-text"><i
                                        class="fa fa-map-marker-alt text-danger"></i></span></div>
                    </div>
                    <span class="form-text text-black-50"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_msg_verbatim_latitude');?>
</span>
                </div>
                <div class="col-lg-6">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_verbatim_longitude');?>
  <span class="text-danger bold">*</span> :</label>
                    <div class="input-group">
                        <input type="text" class="form-control"
                               id="verbatim_longitude"
                               required
                               name="item[verbatim_longitude]"
                               value="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['item']->value['field_verbatim_longitude'], ENT_QUOTES, 'UTF-8', true);?>
"
                               data-fv-not-empty___message="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glFieldRequired');?>
"
                        >
                        <div class="input-group-append"><span class="input-group-text"><i
                                        class="fa fa-map-marker-alt text-danger"></i></span></div>
                    </div>
                    <span class="form-text text-black-50"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_msg_verbatim_longitude');?>
</span>
                </div>
                <div class="col-lg-4">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_utm_latitude');?>
  <span class="text-danger bold">*</span> :</label>
                    <div class="input-group">
                        <input type="text" class="form-control"
                               name="item[utm_latitude]"
                               id="utm_latitude"
                               required
                               value="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['item']->value['utm_latitude'], ENT_QUOTES, 'UTF-8', true);?>
"
                               data-fv-not-empty___message="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glFieldRequired');?>
"
                        >
                        <div class="input-group-append"><span class="input-group-text"><i
                                        class="fa fa-map-marker-alt text-danger"></i></span></div>
                    </div>
                    <span class="form-text text-black-50"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_msg_utm_latitude');?>
</span>
                </div>
                <div class="col-lg-4">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_utm_longitude');?>
  <span class="text-danger bold">*</span> :</label>
                    <div class="input-group">
                        <input type="text" class="form-control"
                               id="utm_longitude"
                               required
                               name="item[utm_longitude]"
                               value="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['item']->value['utm_longitude'], ENT_QUOTES, 'UTF-8', true);?>
"
                               data-fv-not-empty___message="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glFieldRequired');?>
"
                        >
                        <div class="input-group-append"><span class="input-group-text"><i
                                        class="fa fa-map-marker-alt text-danger"></i></span></div>
                    </div>
                    <span class="form-text text-black-50"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_msg_utm_longitude');?>
</span>
                </div>
                <div class="col-lg-2">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_zona');?>
:</label>
                    <div class="input-group">
                        <input type="text" class="form-control number_integer2"
                               id="zone"
                               name="item[zone]"
                               value="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['item']->value['zone'], ENT_QUOTES, 'UTF-8', true);?>
"
                        >
                        <div class="input-group-append"><span class="input-group-text"><i class="fa fa-info"></i></span></div>
                    </div>
                    <span class="form-text text-muted"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_msg_zona');?>
</span>
                </div>
                <div class="col-lg-2">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_hemisferio');?>
 <span class="text-danger bold">*</span> : </label>
                    <div class="input-group">
                        <select class="form-control m-select2"
                                name="item[hemisferio]" id="hemisferio"
                                data-placeholder="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_Holder_hemisferio');?>
" <?php echo $_smarty_tpl->tpl_vars['privFace']->value['input'];?>

                                required
                                data-fv-not-empty___message="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glFieldRequired');?>
"
                        >
                            <option></option>
                            <?php echo smarty_function_html_options(array('options'=>$_smarty_tpl->tpl_vars['cataobj']->value['hemisferio'],'selected'=>$_smarty_tpl->tpl_vars['item']->value['hemisferio']),$_smarty_tpl);?>

                        </select>
                    </div>
                    <span class="form-text text-black-50"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_GroupMsg_hemisferio');?>
</span>
                </div>
            </div>
        </div>


        <div class="card-footer">
            <?php if ($_smarty_tpl->tpl_vars['privFace']->value['edit'] == 1) {?>
                <button type="reset" class="btn btn-primary mr-2" id="general_submit">
                    <i class="la la-save"></i>
                    <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glBtnSaveChanges');?>
</button>
            <?php }?>
                    </div>
    </form>
    <!--end::Form-->
</div>

<?php $_smarty_tpl->_subTemplateRender("file:formprincipal/index.js.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
