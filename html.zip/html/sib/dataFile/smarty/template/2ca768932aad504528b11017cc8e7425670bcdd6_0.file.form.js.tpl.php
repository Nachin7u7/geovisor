<?php
/* Smarty version 4.2.1, created on 2023-01-20 09:04:51
  from '/var/www/html/sib/webapp/app/setting/module/app/snippet/group/view/form/form.js.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_63ca91735c9fe3_14665972',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '2ca768932aad504528b11017cc8e7425670bcdd6' => 
    array (
      0 => '/var/www/html/sib/webapp/app/setting/module/app/snippet/group/view/form/form.js.tpl',
      1 => 1668028010,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_63ca91735c9fe3_14665972 (Smarty_Internal_Template $_smarty_tpl) {
echo '<script'; ?>
>
    var snippet_form_<?php echo $_smarty_tpl->tpl_vars['subcontrol']->value;?>
 = function() {
        "use strict";
        let form = $('#form_<?php echo $_smarty_tpl->tpl_vars['subcontrol']->value;?>
');
        let btn_submit = $('#form_submit_<?php echo $_smarty_tpl->tpl_vars['subcontrol']->value;?>
');
        let btn_close = $('#form_close_<?php echo $_smarty_tpl->tpl_vars['subcontrol']->value;?>
');
        let pmodal = $("#form_modal_<?php echo $_smarty_tpl->tpl_vars['subcontrol']->value;?>
");
        var formv;
        /**
         * Antes de enviar el formulario se ejecuta la siguiente funcion
         */
        var showRequest= function(formData, jqForm, op) {
            btn_submit.addClass('spinner spinner-white spinner-right').attr('disabled', true);
            btn_close.attr('disabled', true);
            return true;
        };
        var showResponse = function (res, statusText) {
            coreUyuni.itemFormShowResponse(res,pmodal,table_list);
            btn_close.attr('disabled', false);
            btn_submit.removeClass('spinner spinner-white spinner-right').attr('disabled', false);
        };
        /**
         * Opciones para generar el objeto del formulario
         */
        var options = {
            beforeSubmit:showRequest
            , success:  showResponse
            , data: {type:'<?php echo $_smarty_tpl->tpl_vars['type']->value;?>
'}
        };
        /**
         * Se da las propiedades de ajaxform al formulario
         */
        var handle_form_submit=function(){
            form.ajaxForm(options);
            formv = FormValidation.formValidation(
                document.getElementById('form_<?php echo $_smarty_tpl->tpl_vars['subcontrol']->value;?>
'),
                {
                    plugins: {
                        declarative: new FormValidation.plugins.Declarative({html5Input: true,}),
                        trigger: new FormValidation.plugins.Trigger(),
                        bootstrap: new FormValidation.plugins.Bootstrap(),
                        submitButton: new FormValidation.plugins.SubmitButton(),
                    }
                }
            );
        };
        /**
         * Se da las funcionalidades al boton enviar
         */
        var handle_btn_submit = function() {
            btn_submit.click(function(e) {
                e.preventDefault();
                /**
                 * Copiamos los datos de summerNote a una variable
                 */
                $('#description_input').val($('#description').summernote('code'));
                formv.validate().then(function(status) {
                    if(status === 'Valid'){
                        form.submit();
                    }
                });
            });
        };
        /**
         * Iniciamos los componentes necesarios como , summernote, select2 entre otros
         */
        var handle_components = function(){
            coreUyuni.setComponents();
        };

        //== Public Functions
        return {
            // public functions
            init: function() {
                handle_form_submit();
                handle_btn_submit();
                handle_components();
            }
        };
    }();

    //== Class Initialization
    jQuery(document).ready(function() {
        snippet_form_<?php echo $_smarty_tpl->tpl_vars['subcontrol']->value;?>
.init();
    });

<?php echo '</script'; ?>
>

<?php }
}
