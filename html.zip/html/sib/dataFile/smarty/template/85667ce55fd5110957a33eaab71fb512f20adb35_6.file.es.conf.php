<?php /* Smarty version 4.2.1, created on 2023-09-20 09:13:25
         compiled from '/var/www/html/sib/webapp/app/sib/module/zoologia_ormitologia/snippet/taxonomia/language/es.conf' */ ?>
<?php
/* Smarty version 4.2.1, created on 2023-09-20 09:13:25
  from '/var/www/html/sib/webapp/app/sib/module/zoologia_ormitologia/snippet/taxonomia/language/es.conf' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_650aeff58dfd73_07303224',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '85667ce55fd5110957a33eaab71fb512f20adb35' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/zoologia_ormitologia/snippet/taxonomia/language/es.conf',
      1 => 1688391178,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_650aeff58dfd73_07303224 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigVars($_smarty_tpl, array (
  'sections' => 
  array (
    'general' => 
    array (
      'vars' => 
      array (
        'title' => 'CARACTERISTICAS DE LA TAXONOMIA',
        'message' => 'Se podrá realizar el registro de la taxonomia',
        'field_date' => 'Fecha',
        'field_msg_date' => 'Ingrese la fecha',
        'field_verbatimEventDate' => 'Fecha original del evento',
        'field_msg_verbatimEventDate' => 'Ingrese la fecha original del evento',
        'field_fieldNumber' => 'Número de campo',
        'field_msg_fieldNumber' => 'Ingrese el número de campo',
        'field_cupos_utilizado' => 'Cupos utilizado',
        'field_msg_cupos_utilizado' => 'Ingrese el cupo utilizado',
        'field_identified_by' => 'Identificado por',
        'field_length_identified_by' => 'Tiene que ser mayor o igual a 3 caracteres',
        'field_msg_identified_by' => 'Ingrese por quién fue identificado',
        'field_type_status' => 'Tipo nomenclatural',
        'field_length_type_status' => 'Tiene que ser mayor o igual a 3 caracteres',
        'field_msg_type_status' => 'Ingrese el tipo nomenclatural',
        'field_scientific_name' => 'Nombre científico',
        'field_Holder_scientific_name' => 'Seleccione una opción',
        'field_GroupMsg_scientific_name' => 'Seleccione el nombre científico',
        'field_scientific_name_authorship' => 'Autoría del nombre científico',
        'field_length_scientific_name_authorship' => 'Tiene que ser mayor o igual a 3 caracteres',
        'field_msg_scientific_name_authorship' => 'Ingrese la autoría del nombre científico',
        'field_kingdom' => 'Reino',
        'field_class' => 'Clase',
        'field_order' => 'Orden',
        'field_family' => 'Familia',
        'field_genus' => 'Género',
        'field_identification_qualifier' => 'Calificador de la identificación',
        'field_length_identification_qualifier' => 'Tiene que ser mayor o igual a 3 caracteres',
        'field_msg_identification_qualifier' => 'Ingrese el calificador de la identificación',
        'field_specific_epithet' => 'Epíteto específico',
        'field_length_specific_epithet' => 'Tiene que ser mayor o igual a 3 caracteres',
        'field_msg_specific_epithet' => 'Ingrese el epíteto específico',
        'field_vernacular_name' => 'Nombre común',
        'field_length_vernacular_name' => 'Tiene que ser mayor o igual a 3 caracteres',
        'field_msg_vernacular_name' => 'Ingrese el nombre común',
        'field_taxon_rank' => 'Categoría del taxón',
        'field_length_taxon_rank' => 'Tiene que ser mayor o igual a 3 caracteres',
        'field_msg_taxon_rank' => 'Ingrese la categoría del taxón',
      ),
    ),
    'form' => 
    array (
      'vars' => 
      array (
        'title1' => 'INFORMACIÓN GENERAL DE LA TAXONOMIA BOTANICA',
      ),
    ),
  ),
  'vars' => 
  array (
  ),
));
}
}
