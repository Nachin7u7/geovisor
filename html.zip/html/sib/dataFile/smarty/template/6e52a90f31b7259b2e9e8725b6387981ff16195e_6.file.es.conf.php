<?php /* Smarty version 4.2.1, created on 2023-07-03 09:47:27
         compiled from '/var/www/html/sib/webapp/app/sib/module/institucion/snippet/general/language/es.conf' */ ?>
<?php
/* Smarty version 4.2.1, created on 2023-07-03 09:47:27
  from '/var/www/html/sib/webapp/app/sib/module/institucion/snippet/general/language/es.conf' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_64a2d16f1921c6_21379411',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6e52a90f31b7259b2e9e8725b6387981ff16195e' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/institucion/snippet/general/language/es.conf',
      1 => 1676393396,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_64a2d16f1921c6_21379411 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigVars($_smarty_tpl, array (
  'sections' => 
  array (
    'general' => 
    array (
      'vars' => 
      array (
        'title' => 'CARACTERÍSTICAS GENERALES DE LA INSTITUCIÓN CIENTÍFICA AUTORIZADA',
        'message' => 'Se podrá realizar el registro los datos iniciales de la institución cientifica autorizada',
        'field_vigente' => 'Vigente',
        'field_msg_vigente' => 'Si la institución esta vigente',
        'field_holder_vigente' => 'Seleccione vigente',
        'field_tipo_id' => 'Tipo de institución',
        'field_Holder_tipo_id' => 'Seleccione una opción',
        'field_GroupMsg_tipo_id' => 'Seleccione el tipo de institución',
        'field_nombre' => 'Nombre',
        'field_length_nombre' => 'Tiene que ser mayor o igual a 3 caracteres',
        'field_msg_nombre' => 'Ingrese el nombre de la institución',
        'field_direccion' => 'Dirección',
        'field_length_direccion' => 'Tiene que ser mayor o igual a 3 caracteres',
        'field_msg_direccion' => 'Ingrese la dirección de la institución',
        'field_telefono' => 'Teléfono',
        'field_length_telefono' => 'Tiene que ser mayor o igual a 3 caracteres',
        'field_msg_telefono' => 'Ingrese el teléfono de la institución',
        'field_fax' => 'Fax',
        'field_length_fax' => 'Tiene que ser mayor o igual a 3 caracteres',
        'field_msg_fax' => 'Ingrese el fax de la institución',
        'field_celular' => 'Celular',
        'field_length_celular' => 'Tiene que ser mayor o igual a 3 caracteres',
        'field_msg_celular' => 'Ingrese el celular de la institución',
        'field_email' => 'Email',
        'field_length_email' => 'Tiene que ser mayor o igual a 3 caracteres',
        'field_msg_email' => 'Ingrese el email de la institución',
        'field_web' => 'Web',
        'field_length_web' => 'Tiene que ser mayor o igual a 3 caracteres',
        'field_msg_web' => 'Ingrese la web de la institución',
        'field_pais_id' => 'País',
        'field_Holder_pais_id' => 'Seleccione una opción',
        'field_GroupMsg_pais_id' => 'Seleccione el país',
        'field_departamento_id' => 'Departamento',
        'field_Holder_departamento_id' => 'Seleccione una opción',
        'field_GroupMsg_departamento_id' => 'Seleccione el departamento',
        'field_ciudad' => 'Ciudad',
        'field_length_ciudad' => 'Tiene que ser mayor o igual a 3 caracteres',
        'field_msg_ciudad' => 'Ingrese la ciudad',
        'field_responsable' => 'Responsable',
        'field_length_responsable' => 'Tiene que ser mayor o igual a 3 caracteres',
        'field_msg_responsable' => 'Ingrese el responsable de la institución',
        'field_responsable_operativo' => 'Responsable Operativo',
        'field_length_responsable_operativo' => 'Tiene que ser mayor o igual a 3 caracteres',
        'field_msg_responsable_operativo' => 'Ingrese el responsable de la institución',
        'field_fecha_acreditacion' => 'Fecha de acreditación',
        'field_fecha_expiracion' => 'Fecha de expiración',
      ),
    ),
    'form' => 
    array (
      'vars' => 
      array (
        'title1' => 'INFORMACIÓN GENERAL DE LA EMPRESA INSTALADORA',
      ),
    ),
  ),
  'vars' => 
  array (
  ),
));
}
}
