<?php
/* Smarty version 4.2.1, created on 2022-11-09 17:25:50
  from '/var/www/html/sib/webapp/app/sib/module/index/snippet/index/view/index.js.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_636c1adea860c0_22353790',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '585808ad4cbbf27225f6d8be926dcd9e1e988170' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/index/snippet/index/view/index.js.tpl',
      1 => 1668028010,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_636c1adea860c0_22353790 (Smarty_Internal_Template $_smarty_tpl) {
}
}
