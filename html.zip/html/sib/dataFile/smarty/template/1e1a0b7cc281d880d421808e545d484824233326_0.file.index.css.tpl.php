<?php
/* Smarty version 4.2.1, created on 2023-07-03 09:22:54
  from '/var/www/html/sib/webapp/app/sib/module/zoologia_anfibios/snippet/taxonomia/view/index.css.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_64a2cbaeb1db37_44744649',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '1e1a0b7cc281d880d421808e545d484824233326' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/zoologia_anfibios/snippet/taxonomia/view/index.css.tpl',
      1 => 1678278586,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_64a2cbaeb1db37_44744649 (Smarty_Internal_Template $_smarty_tpl) {
?>
    <style>
        .select2-results__group{
            background: #e7f1f6;
            border-bottom: 2px solid #006ba2;
        }

    </style>
<?php }
}
