<?php
/* Smarty version 4.2.1, created on 2023-02-03 16:44:15
  from '/var/www/html/sib/webapp/app/sib/module/taxonomia_botanica/snippet/index/view/index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_63dd721f04cc57_48935031',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '3fdbbbb00a2e90e5431ce2bcce57792535d5feb6' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/taxonomia_botanica/snippet/index/view/index.tpl',
      1 => 1675456623,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:index.css.tpl' => 1,
  ),
),false)) {
function content_63dd721f04cc57_48935031 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:index.css.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
<div class="d-flex flex-column flex-md-row">
    <div class="flex-md-row-fluid ">
        <div class="card card-custom gutter-b">
            <div class="card-body p-5">
                <!--begin: Datatable-->
                <table class="table  table-head-custom table-bordered table-hover
            table-checkable d-none table-sm " id="index_list">
                    <thead class="thead-dark thead-color"><tr>
                        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['gridItem']->value, 'row', false, 'idx');
$_smarty_tpl->tpl_vars['row']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['idx']->value => $_smarty_tpl->tpl_vars['row']->value) {
$_smarty_tpl->tpl_vars['row']->do_else = false;
?>
                            <th><?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['row']->value['label'], ENT_QUOTES, 'UTF-8', true);?>
</th>
                        <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                    </tr></thead>
                    <tbody></tbody>
                </table>
                <!--end: Datatable-->
            </div>
        </div>
    </div>


</div><?php }
}
