<?php
/* Smarty version 4.2.1, created on 2022-11-09 17:48:36
  from '/var/www/html/sib/webapp/app/sib/module/user/snippet/general/view/index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_636c2034f0ce22_07839429',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '5c6f12b4760f9f6b8d4b870374ea8fb6fa9dea21' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/user/snippet/general/view/index.tpl',
      1 => 1668028010,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:index.css.tpl' => 1,
    'file:index.js.tpl' => 1,
  ),
),false)) {
function content_636c2034f0ce22_07839429 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_checkPlugins(array(0=>array('file'=>'/var/www/html/sib/vendor/smarty/smarty/libs/plugins/function.html_options.php','function'=>'smarty_function_html_options',),));
$_smarty_tpl->_subTemplateRender("file:index.css.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
<div class="card card-custom gutter-b example example-compact">
    <div class="card-header py-3">
        <div class="card-title">
            <span class="card-icon"><i class="flaticon2-next text-dark-25"></i></span>
            <h3 class="card-label text-dark-50"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'title');?>
</h3>
        </div>
    </div>

    <div class="card-body pt-0 pb-0 pl-5 pr-5">
        <div class="alert alert-custom fade show pt-1 pb-1 pl-5 pr-5 ayuda" role="alert">
            <div class="alert-icon">
                <i class="flaticon-notes"></i>
            </div>
            <div class="alert-text text-justify text-dark-65" >
                <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'message');?>

            </div>
        </div>
    </div>

    <!--begin::Form-->
    <form method="POST"
          action="<?php echo $_smarty_tpl->tpl_vars['path_url']->value;?>
/<?php echo $_smarty_tpl->tpl_vars['subcontrol']->value;?>
_/<?php if ($_smarty_tpl->tpl_vars['type']->value == "update") {
echo $_smarty_tpl->tpl_vars['id']->value;?>
/<?php }?>save/"
          id="general_form">

        <div class="card-body pt-0 pb-0">

            <div class="form-group row">
                <div class="col-lg-6">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'fieldUserName');?>
  <span class="text-danger bold">*</span> :</label>
                    <div class="input-group">
                        <input type="text" class="form-control"
                               name="item[username]" value="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['item']->value['username'], ENT_QUOTES, 'UTF-8', true);?>
"
                               required
                               data-fv-not-empty___message="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glFieldRequired');?>
"

                        >
                        <div class="input-group-append"><span class="input-group-text"><i class="fa fa-user"></i></span></div>
                    </div>
                    <span class="form-text text-muted"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'fieldUserNameMsg');?>
</span>
                </div>

                <div class="col-lg-6">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'fieldPass');?>
 <span class="text-danger bold">*</span> :</label>
                    <div class="input-group">
                        <input type="text" class="form-control"
                               name="item[password]"
                               placeholder=""
                               <?php if ($_smarty_tpl->tpl_vars['type']->value == 'new') {?>
                                    required
                                    data-fv-not-empty___message="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glFieldRequired');?>
"
                                <?php }?>
                               minlength="3"
                               data-fv-string-length___message="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'fieldPassLength');?>
"
                        >
                        <div class="input-group-append"><span class="input-group-text"><i class="fa fa-unlock-alt"></i></span></div>
                    </div>
                    <?php if ($_smarty_tpl->tpl_vars['type']->value == 'new') {?>
                        <span class="form-text text-muted"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'fieldPassMsg');?>
</span>
                    <?php } else { ?>
                        <span class="form-text text-muted"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'fieldPassUpdateMsg');?>
</span>
                    <?php }?>
                </div>
                <div class="col-lg-6">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'fieldName');?>
  <span class="text-danger bold">*</span> :</label>
                    <div class="input-group">
                        <input type="text" class="form-control"
                               name="item[name]" value="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['item']->value['name'], ENT_QUOTES, 'UTF-8', true);?>
"
                               required
                               data-fv-not-empty___message="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glFieldRequired');?>
"
                               minlength="3"
                               data-fv-string-length___message="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'fieldNameLength');?>
"
                        >
                        <div class="input-group-append"><span class="input-group-text"><i class="fa fa-user"></i></span></div>
                    </div>
                    <span class="form-text text-muted"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'fieldNameMsg');?>
</span>
                </div>


                <div class="col-lg-6">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'fieldLastName');?>
 <span class="text-danger bold">*</span> :</label>
                    <div class="input-group">
                        <input type="text" class="form-control"
                               name="item[last_name]"
                               value="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['item']->value['last_name'], ENT_QUOTES, 'UTF-8', true);?>
"
                               placeholder=""
                               required
                               data-fv-not-empty___message="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glFieldRequired');?>
"
                               minlength="3"
                               data-fv-string-length___message="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'fieldLastNameLength');?>
"
                        >
                        <div class="input-group-append"><span class="input-group-text"><i class="fa fa-user"></i></span></div>
                    </div>
                    <span class="form-text text-muted"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'fieldLastNameMsg');?>
</span>
                </div>
                <div class="col-lg-6">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'fieldType');?>
 <span class="text-danger bold">*</span>: </label>
                    <div class="input-group">
                        <select class="form-control m-select2 select2_general"
                                name="item[type]" id="type"
                                data-placeholder="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_Holder_type');?>
" <?php echo $_smarty_tpl->tpl_vars['privFace']->value['input'];?>

                                required
                                data-fv-not-empty___message="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glFieldRequired');?>
"
                        >
                            <option></option>
                            <?php echo smarty_function_html_options(array('options'=>$_smarty_tpl->tpl_vars['cataobj']->value['type'],'selected'=>$_smarty_tpl->tpl_vars['item']->value['type']),$_smarty_tpl);?>

                        </select>
                    </div>
                    <span class="form-text text-muted"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_GroupMsg_type');?>
</span>
                </div>
                <div class="col-lg-6 <?php if ($_smarty_tpl->tpl_vars['item']->value['type'] != '3') {?>d-none<?php }?>" id="distribuidor_div">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_distribuidora');?>
 <span class="text-danger bold">*</span>: </label>
                    <div class="input-group">
                        <select class="form-control m-select2 select2_general"
                                name="item[distribuidor_id]" id="select_distribuidor"
                                data-placeholder="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_Holder_distribuidora');?>
" <?php echo $_smarty_tpl->tpl_vars['privFace']->value['input'];?>

                                data-fv-not-empty___message="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glFieldRequired');?>
"
                        >
                            <option></option>
                            <?php echo smarty_function_html_options(array('options'=>$_smarty_tpl->tpl_vars['cataobj']->value['distribuidor'],'selected'=>$_smarty_tpl->tpl_vars['item']->value['distribuidor_id']),$_smarty_tpl);?>

                        </select>
                    </div>
                    <span class="form-text text-muted"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_GroupMsg_distribuidora');?>
</span>
                </div>
            </div>
            <div class="form-group row">
                <div class="col-lg-4">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'fieldMobile');?>
:</label>
                    <div class="input-group">
                        <input type="text" class="form-control number_integer"
                               name="item[mobile]" value="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['item']->value['mobile'], ENT_QUOTES, 'UTF-8', true);?>
"
                               minlength="3"
                               data-fv-string-length___message="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'fieldMobileLength');?>
"
                        >
                        <div class="input-group-append"><span class="input-group-text"><i class="fa fa-phone"></i></span></div>
                    </div>
                    <span class="form-text text-muted"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'fieldMobileMsg');?>
</span>
                </div>
                <div class="col-lg-4">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'fieldPhone');?>
 :</label>
                    <div class="input-group">
                        <input type="text" class="form-control number_integer"
                               name="item[phone]" value="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['item']->value['phone'], ENT_QUOTES, 'UTF-8', true);?>
"
                               minlength="3"
                               data-fv-string-length___message="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'fieldPhoneLength');?>
"
                        >
                        <div class="input-group-append"><span class="input-group-text"><i class="fa fa-phone"></i></span></div>
                    </div>
                    <span class="form-text text-muted"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'fieldPhoneMsg');?>
</span>
                </div>
                <div class="col-lg-4">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'fieldActiveName');?>
:</label>
                    <div class="input-group">
                    <span class="switch switch-icon">
                        <label><input type="checkbox" <?php if ($_smarty_tpl->tpl_vars['item']->value['active'] == 1) {?>checked="checked"<?php }?> name="item[active]" value="1" ><span></span></label>
                    </span>
                    </div>
                    <span class="form-text text-muted"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'fieldActiveMsg');?>
</span>
                </div>

                <div class="col-lg-12">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'fieldDescription');?>
:</label>
                    <div class="input-group">
                        <textarea rows="2" class="form-control"
                                  name="item[description]" value="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['item']->value['description'], ENT_QUOTES, 'UTF-8', true);?>
"
                        ><?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['item']->value['description'], ENT_QUOTES, 'UTF-8', true);?>
</textarea>
                    </div>
                    <span class="form-text text-muted"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'fieldDescriptionMsg');?>
</span>
                </div>
            </div>
        </div>

        <div class="card-footer">
            <?php if ($_smarty_tpl->tpl_vars['privFace']->value['edit'] == 1) {?>
                <button type="reset" class="btn btn-primary mr-2" id="general_submit">
                    <i class="la la-save"></i>
                    <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glBtnSaveChanges');?>
</button>
            <?php }?>
            <a href="<?php echo $_smarty_tpl->tpl_vars['path_url']->value;?>
" class="btn btn-light-primary ">
                <i class="la la-angle-double-left"></i><?php if ($_smarty_tpl->tpl_vars['type']->value == "new") {?> <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glBtnCancel');?>
 <?php } else { ?> <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glBtnBackToList');
}?>
            </a>
        </div>
    </form>
    <!--end::Form-->
</div>


<?php $_smarty_tpl->_subTemplateRender("file:index.js.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
