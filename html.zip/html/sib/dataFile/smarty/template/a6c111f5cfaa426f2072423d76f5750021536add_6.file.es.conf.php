<?php /* Smarty version 4.2.1, created on 2023-09-14 22:19:11
         compiled from '/var/www/html/sib/webapp/app/sib/module/zoologia_anfibios/snippet/foto/language/es.conf' */ ?>
<?php
/* Smarty version 4.2.1, created on 2023-09-14 22:19:11
  from '/var/www/html/sib/webapp/app/sib/module/zoologia_anfibios/snippet/foto/language/es.conf' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_6503bf1f0f03e8_64051575',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a6c111f5cfaa426f2072423d76f5750021536add' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/zoologia_anfibios/snippet/foto/language/es.conf',
      1 => 1678278586,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6503bf1f0f03e8_64051575 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigVars($_smarty_tpl, array (
  'sections' => 
  array (
    'index' => 
    array (
      'vars' => 
      array (
        'title' => 'Subir fotos de la muestra',
        'message' => '<strong>Adicionar fotografías</strong><br> Haga clic en el boton <strong>"Adicionar fotografía"</strong> para subir fotos.',
        'btnNew' => 'Adicionar fotografía',
        'dataTableExportTitle' => 'Lista de fotografías',
      ),
    ),
    'tableIndex' => 
    array (
      'vars' => 
      array (
        'table_descripcion' => 'Descripción',
        'table_attached_name' => 'Archivo de fotografía',
        'table_attached_size' => 'Tamaño',
      ),
    ),
    'formItem' => 
    array (
      'vars' => 
      array (
        'title' => 'Archivo de la fotografía',
        'message' => 'Podrás adjuntar el archivo de fotografía',
        'field_descripcion' => 'Descripción',
        'field_length_descripcion' => 'Tiene que ser mayor o igual a 3 caracteres',
        'field_msg_descripcion' => 'Ingrese la descripción del archivo de fotografía',
        'field_file' => 'Adjunte el archivo de fotografía',
        'field_msg_file' => 'Seleccione el archivo de fotografía que quiere adjuntar',
        'field_holder_file' => 'Ingrese el archivo de fotografía',
        'fieldDescription' => 'Descripción',
      ),
    ),
  ),
  'vars' => 
  array (
  ),
));
}
}
