<?php
/* Smarty version 4.2.1, created on 2022-11-09 17:48:29
  from '/var/www/html/sib/webapp/app/sib/module/user/snippet/index/view/index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_636c202def2c52_42972345',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '3dff4a17ff39663f62bf2a82bc751ceb245fd969' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/user/snippet/index/view/index.tpl',
      1 => 1668028010,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:index.css.tpl' => 1,
    'file:index.search.tpl' => 1,
  ),
),false)) {
function content_636c202def2c52_42972345 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:index.css.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
<div class="d-flex flex-column flex-md-row">
    <div class="flex-md-row-fluid ">
        <div class="card card-custom gutter-b">
            <div class="card-body p-5">
                <!--begin: Datatable-->
                <table class="table  table-head-custom table-bordered table-hover
            table-checkable d-none table-sm " id="index_list">
                    <thead class="thead-dark thead-color"><tr>
                        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['gridItem']->value, 'row', false, 'idx');
$_smarty_tpl->tpl_vars['row']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['idx']->value => $_smarty_tpl->tpl_vars['row']->value) {
$_smarty_tpl->tpl_vars['row']->do_else = false;
?>
                            <th><?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['row']->value['label'], ENT_QUOTES, 'UTF-8', true);?>
</th>
                        <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                    </tr></thead>
                    <tbody></tbody>
                </table>
                <!--end: Datatable-->
            </div>
        </div>
    </div>

    <div class="flex-md-row-auto w-md-275px w-xl-325px ml-md-6 ml-lg-8">

        <div class="card card-custom bgi-no-repeat gutter-b " style="height: 140px; background-color: #385209;
                        background-position: calc(100% + 0.5rem) 100%; background-size: 100% auto;
                        background-image: url(/themes/metro72/assets/media/svg/patterns/taieri.svg)">
            <!--begin::Body-->
            <div class="card-body d-flex align-items-center pt-2 pb-2">
                <div>
                    <h3 class="text-white font-weight-bolder line-height-lg mb-5"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'title');?>
</h3>
                    <?php if ($_smarty_tpl->tpl_vars['privFace']->value['edit'] == 1 && $_smarty_tpl->tpl_vars['privFace']->value['add'] == 1) {?>
                        <a href="#" class="btn btn-success font-weight-bolder" id="btn_update" rel="new">
                            <span><i class="fa fa-plus"></i><span> <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'btnNew');?>
</a>
                    <?php }?>
                </div>
            </div>
            <!--end::Body-->
        </div>

        <div class="card card-custom gutter-b" style=" background-color: #27361e;">
            <!--begin::Body-->
            <div class="card-body p-5">
                <h4 class="card-label text-dark-25"><span class="card-icon">
                        <i class="fa fa-search text-dark-25"></i></span> <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'title_filter');?>
</h4>
                <!--begin::Container-->
                <?php $_smarty_tpl->_subTemplateRender("file:index.search.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
                <!--end::Container-->
            </div>
            <!--end::Body-->
        </div>
    </div>
</div><?php }
}
