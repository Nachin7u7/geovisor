<?php
/* Smarty version 4.2.1, created on 2023-01-10 11:32:32
  from '/var/www/html/sib/webapp/app/setting/module/app/snippet/module/view/index.search.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_63bd8510eb7922_24064679',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '9e1cf2efa3aa5ed554dc836d4d3de21504dbce70' => 
    array (
      0 => '/var/www/html/sib/webapp/app/setting/module/app/snippet/module/view/index.search.tpl',
      1 => 1668028010,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_63bd8510eb7922_24064679 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_checkPlugins(array(0=>array('file'=>'/var/www/html/sib/vendor/smarty/smarty/libs/plugins/function.html_options.php','function'=>'smarty_function_html_options',),));
?>
<div class="row alert alert-custom alert-light-primary fade show mb-5" role="alert" >
    <div class="col-lg-4 alert-text">
        <label>Group:</label>
        <select class="filtro-buscar form-control select2_busqueda " data-col-index="0">
            <option value="3">All the groups</option>
            <?php echo smarty_function_html_options(array('options'=>$_smarty_tpl->tpl_vars['cataobj']->value['group']),$_smarty_tpl);?>

        </select>
    </div>
    <div class="col-lg-4 alert-text">
        <label>Name:</label>
        <input type="text" class="filtro-buscar-text form-control" placeholder="Search by name" data-col-index="1">
    </div>
    </div>

<div class="m-separator m-separator--md m-separator--dashed"></div>

<?php }
}
