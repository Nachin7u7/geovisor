<?php
/* Smarty version 4.2.1, created on 2022-11-10 11:06:38
  from '/var/www/html/sib/webapp/app/setting/module/user/snippet/index/view/item/index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_636d137e11c946_60606950',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '910016183755bd5ef81c920fb1240b03c5f519f1' => 
    array (
      0 => '/var/www/html/sib/webapp/app/setting/module/user/snippet/index/view/item/index.tpl',
      1 => 1668028010,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_636d137e11c946_60606950 (Smarty_Internal_Template $_smarty_tpl) {
if (($_smarty_tpl->tpl_vars['item']->value['id'] != 0 && $_smarty_tpl->tpl_vars['item']->value['id'] != '' && $_smarty_tpl->tpl_vars['type']->value == "update") || $_smarty_tpl->tpl_vars['type']->value == "new") {?>


    
    <div class="d-flex flex-column flex-md-row">

        <div class="flex-md-row-fluid ">
            <div class="card card-custom">
                <div class="card-header card-header-tabs-line">
                    <div class="card-toolbar">
                        <ul class="nav nav-tabs nav-tabs-space-lg nav-tabs-line nav-tabs-bold nav-tabs-line-3x" id="myTab" role="tablist">
                            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['menu_tab']->value, 'row', false, 'idx');
$_smarty_tpl->tpl_vars['row']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['idx']->value => $_smarty_tpl->tpl_vars['row']->value) {
$_smarty_tpl->tpl_vars['row']->do_else = false;
?>
                                <li class="nav-item">
                                    <a class="nav-link"
                                       role="tab"
                                       data-toggle="tabajax"
                                       data-target="#<?php echo $_smarty_tpl->tpl_vars['row']->value['id_name'];?>
_pane"
                                       id = "<?php echo $_smarty_tpl->tpl_vars['row']->value['id_name'];?>
_tab"
                                            <?php if ($_smarty_tpl->tpl_vars['type']->value == 'update') {?>
                                                href="<?php echo $_smarty_tpl->tpl_vars['path_url']->value;?>
/<?php echo $_smarty_tpl->tpl_vars['row']->value['id_name'];?>
_/<?php echo $_smarty_tpl->tpl_vars['id']->value;?>
"
                                            <?php } else { ?>
                                                href="<?php echo $_smarty_tpl->tpl_vars['path_url']->value;?>
/<?php echo $_smarty_tpl->tpl_vars['row']->value['id_name'];?>
_/new/"
                                            <?php }?>
                                    >
                                        <span class="nav-icon"><i class="<?php echo $_smarty_tpl->tpl_vars['row']->value['icon'];?>
"></i></span>
                                        <span class="nav-text"><?php echo $_smarty_tpl->tpl_vars['row']->value['label'];?>
</span>
                                    </a>
                                </li>
                            <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>

                        </ul>
                    </div>
                </div>
                <div class="card-body" style="padding: 0px;">
                    <div class="tab-content mt-5" >
                        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['menu_tab']->value, 'row', false, 'idx');
$_smarty_tpl->tpl_vars['row']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['idx']->value => $_smarty_tpl->tpl_vars['row']->value) {
$_smarty_tpl->tpl_vars['row']->do_else = false;
?>
                            <div class="tab-pane fade" id="<?php echo $_smarty_tpl->tpl_vars['row']->value['id_name'];?>
_pane" role="tabpanel" aria-labelledby="<?php echo $_smarty_tpl->tpl_vars['row']->value['id_name'];?>
-tab"></div>
                        <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                    </div>
                </div>
            </div>
        </div>
        <?php if ($_smarty_tpl->tpl_vars['type']->value != "new") {?>
            <div class="flex-md-row-auto w-md-275px w-xl-325px ml-md-6 ml-lg-8">

                <div class="row">
                    <div class="col-xl-12">
                        <div class="card card-custom bgi-no-repeat gutter-b " style="height: 170px; background-color: #663259;
                        background-position: calc(100% + 0.5rem) 100%; background-size: 100% auto;
                        background-image: url(/themes/metro72/assets/media/svg/patterns/taieri.svg)">
                            <!--begin::Body-->
                            <div class="card-body d-flex align-items-center pt-2 pb-2">
                                <div>
                                    <h3 class="text-white font-weight-bolder line-height-lg mb-5"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'title');?>
</h3>
                                    <a href="<?php echo $_smarty_tpl->tpl_vars['path_url']->value;?>
" class="btn btn-primary  ">
                                        <i class="ki ki-double-arrow-back"></i> <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glBtnBack');?>

                                    </a>
                                </div>
                            </div>
                            <!--end::Body-->
                        </div>
                    </div>
                </div>

            </div>
        <?php }?>

    </div>

<?php } else { ?>
    <?php $_smarty_tpl->_subTemplateRender($_smarty_tpl->tpl_vars['frontend']->value['error_01'], $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, true);
}?>

<?php }
}
