<?php /* Smarty version 4.2.1, created on 2022-11-10 11:22:34
         compiled from '/var/www/html/sib/webapp/app/setting/module/app/snippet/index/language/es.conf' */ ?>
<?php
/* Smarty version 4.2.1, created on 2022-11-10 11:22:34
  from '/var/www/html/sib/webapp/app/setting/module/app/snippet/index/language/es.conf' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_636d173a29f8a5_27424275',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '9b7c1f6405eedbd6ca4f31f26bc5182499d5c4b7' => 
    array (
      0 => '/var/www/html/sib/webapp/app/setting/module/app/snippet/index/language/es.conf',
      1 => 1668028010,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_636d173a29f8a5_27424275 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigVars($_smarty_tpl, array (
  'sections' => 
  array (
    'index' => 
    array (
      'vars' => 
      array (
        'title' => 'Aplicaciones',
        'btnNew' => 'Nueva App',
        'filterName' => 'Nombre',
        'filterNameHolder' => 'Buscar por nombre de aplicación',
        'filterFolderName' => 'Nombre de Carpeta',
        'filterFolderNameHolder' => 'Buscar por nombre de carpeta',
        'filterAppStatus' => 'Estado de la aplicación',
        'filterAppStatusSelectAll' => 'Todos los estados',
        'dataTableExportTitle' => 'Lista de Aplicaciones',
      ),
    ),
    'tableIndex' => 
    array (
      'vars' => 
      array (
        'tableName' => 'Nombre',
        'tableId' => 'Id',
        'tableOrder' => 'Orden',
        'tableClass' => 'Icon',
        'tableTarget' => 'Nueva Ventana',
        'tableType' => 'Tipo',
        'tableFolder' => 'Carpeta',
        'tableUrl' => 'Url',
        'tableDescription' => 'Descripcion',
        'tableStatus' => 'Estado',
      ),
    ),
    'item' => 
    array (
      'vars' => 
      array (
        'title' => 'Aplicación',
      ),
    ),
    'tabItem' => 
    array (
      'vars' => 
      array (
        'tabGeneral' => 'General',
        'tabGroups' => 'Grupos',
        'tabModules' => 'Módulos',
      ),
    ),
  ),
  'vars' => 
  array (
  ),
));
}
}
