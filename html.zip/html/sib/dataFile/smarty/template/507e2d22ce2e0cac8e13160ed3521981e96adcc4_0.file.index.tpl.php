<?php
/* Smarty version 4.2.1, created on 2023-01-10 11:32:32
  from '/var/www/html/sib/webapp/app/setting/module/app/snippet/module/view/index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_63bd8510e7e004_03890703',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '507e2d22ce2e0cac8e13160ed3521981e96adcc4' => 
    array (
      0 => '/var/www/html/sib/webapp/app/setting/module/app/snippet/module/view/index.tpl',
      1 => 1668028010,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:index.css.tpl' => 1,
    'file:index.search.tpl' => 1,
    'file:index.js.tpl' => 1,
  ),
),false)) {
function content_63bd8510e7e004_03890703 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:index.css.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<div class="card card-custom">
    <!--begin:Titulo-->
    <div class="card-header py-3">
        <div class="card-title">
            <span class="card-icon"><i class="flaticon2-next text-dark-25"></i></span>
            <h3 class="card-label text-dark-50"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'title');?>
</h3>
        </div>
        <div class="card-toolbar">
            <?php if ($_smarty_tpl->tpl_vars['privFace']->value['edit'] == 1 && $_smarty_tpl->tpl_vars['privFace']->value['add'] == 1) {?>
                <!--begin::Button-->
                <a href="#" class="btn btn-success font-weight-bolder" id="btn_form_<?php echo $_smarty_tpl->tpl_vars['subcontrol']->value;?>
" rel="new">
                    <span><i class="fa fa-plus"></i><span> <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'btnNew');?>
</a>
                <!--end::Button-->
            <?php }?>
        </div>
    </div>
    <!--end:Titulo-->
    <!--begin: Lista de Datos-->
    <div class="card-body">
        <?php $_smarty_tpl->_subTemplateRender("file:index.search.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
        <!--begin: Datatable-->
        <table class="table  table-striped table-bordered table-hover table-head-custom table-checkable d-none table-sm  "
               id="tabla_<?php echo $_smarty_tpl->tpl_vars['subcontrol']->value;?>
" >
            <thead class="thead-dark thead-color">
            <tr>
                <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['gridItem']->value, 'row', false, 'idx');
$_smarty_tpl->tpl_vars['row']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['idx']->value => $_smarty_tpl->tpl_vars['row']->value) {
$_smarty_tpl->tpl_vars['row']->do_else = false;
?>
                    <th><?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['row']->value['label'], ENT_QUOTES, 'UTF-8', true);?>
</th>
                <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
            </tr>
            </thead>
            <tbody></tbody>
            <tfoot></tfoot>
        </table>
        <!--end: Datatable-->
    </div>
    <!--end: Lista de Datos-->
</div>

<!--begin::Modal-->
<div class="modal fade" id="form_modal_<?php echo $_smarty_tpl->tpl_vars['subcontrol']->value;?>
"
     data-backdrop="static" tabindex="-1" role="dialog"
     aria-labelledby="staticBackdrop" aria-hidden="true"
>
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content modal-lg" id="modal-content_<?php echo $_smarty_tpl->tpl_vars['subcontrol']->value;?>
">
        </div>
    </div>
</div>
<!--end::Modal-->
<?php $_smarty_tpl->_subTemplateRender("file:index.js.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
