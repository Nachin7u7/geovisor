<?php
/* Smarty version 4.2.1, created on 2022-11-11 00:11:24
  from '/var/www/html/sib/webapp/app/sib/module/user/snippet/permits/view/form/form.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_636dcb6cc787e3_75184717',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '5d9020986d912c97db8d70d742362dfb0d38967a' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/user/snippet/permits/view/form/form.tpl',
      1 => 1668028010,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:form/form.css.tpl' => 1,
    'file:form/form.js.tpl' => 1,
  ),
),false)) {
function content_636dcb6cc787e3_75184717 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_checkPlugins(array(0=>array('file'=>'/var/www/html/sib/vendor/smarty/smarty/libs/plugins/function.html_options.php','function'=>'smarty_function_html_options',),));
$_smarty_tpl->_subTemplateRender("file:form/form.css.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php if ($_smarty_tpl->tpl_vars['item']->value['id'] != '' || $_smarty_tpl->tpl_vars['type']->value == 'new') {?>
        <form method="POST"
              action="<?php echo $_smarty_tpl->tpl_vars['path_url']->value;?>
/<?php echo $_smarty_tpl->tpl_vars['subcontrol']->value;?>
_/<?php echo $_smarty_tpl->tpl_vars['item_id']->value;?>
/<?php if ($_smarty_tpl->tpl_vars['type']->value == "update") {
echo $_smarty_tpl->tpl_vars['id']->value;?>
/<?php }?>save/"
              id="form_<?php echo $_smarty_tpl->tpl_vars['subcontrol']->value;?>
">

        <div class="modal-body">
            <div class="alert alert-primary" role="alert">
                <?php if ($_smarty_tpl->tpl_vars['type']->value == 'new') {
echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glnew');
} else {
echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glupdate');
}?> - <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'title');?>

            </div>

            <div class="form-group row">
                    <label class="col-2 col-form-label"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_app');?>
 <span class="text-danger bold">*</span> : </label>
                    <div class="col-10">
                        <select class="form-control m-select2 select2_general filtro-buscar-form"
                                name="item[mes]" id="mes" data-col-index="0"
                                data-placeholder="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_holder_app');?>
" <?php echo $_smarty_tpl->tpl_vars['privFace']->value['input'];?>

                                required
                                data-fv-not-empty___message="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glFieldRequired');?>
">
                            <option value="3"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_all_app');?>
</option>
                            <?php echo smarty_function_html_options(array('options'=>$_smarty_tpl->tpl_vars['cataobj']->value['app'],'selected'=>$_smarty_tpl->tpl_vars['item']->value['mes']),$_smarty_tpl);?>

                        </select>
                    </div>
            </div>

            <div class="card-body p-0">
                <input type="hidden" name="item[module]" id="form_module" value="">
                <table class="table  form-table table-bordered table-hover table-head-custom table-checkable  table-sm  "
                       id="tabla_<?php echo $_smarty_tpl->tpl_vars['subcontrol']->value;?>
_form" >
                    <thead class="thead-dark thead-color"><tr>
                        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['gridItem']->value, 'row', false, 'idx');
$_smarty_tpl->tpl_vars['row']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['idx']->value => $_smarty_tpl->tpl_vars['row']->value) {
$_smarty_tpl->tpl_vars['row']->do_else = false;
?>
                            <th><?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['row']->value['label'], ENT_QUOTES, 'UTF-8', true);?>
</th>
                        <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                    </tr></thead>
                    <tbody></tbody>
                    <tfoot></tfoot>
                </table>
            </div>
        </div>
        </form>

        <div class="modal-footer">
            <button type="button" class="btn btn-light-primary" id="form_close_<?php echo $_smarty_tpl->tpl_vars['subcontrol']->value;?>
" data-dismiss="modal"><i class="la la-angle-double-left"></i><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glBtnCloce');?>
</button>
            <button type="button" class="btn btn-primary font-weight-bold" id="form_submit_<?php echo $_smarty_tpl->tpl_vars['subcontrol']->value;?>
"><i class="la la-save"></i><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glBtnSave');?>
</button>
        </div>

    <?php } else { ?>
        <div class="modal-body">
            No existe el registro
        </div>

        <div class="modal-footer">
            <button type="button" class="btn btn-light-primary" id="form_close_<?php echo $_smarty_tpl->tpl_vars['subcontrol']->value;?>
" data-dismiss="modal"><i class="la la-angle-double-left"></i>Cerrar</button>
        </div>
    <?php }?>

<?php $_smarty_tpl->_subTemplateRender("file:form/form.js.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
