<?php
/* Smarty version 4.2.1, created on 2023-03-29 08:21:26
  from '/var/www/html/sib/webapp/app/sib/module/taxonomia_botanica/snippet/general/view/addphylum/form.js.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_64242d46157038_85083676',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '306b2acbbdb55fe9904d4c7b27d170dab043df48' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/taxonomia_botanica/snippet/general/view/addphylum/form.js.tpl',
      1 => 1680015874,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_64242d46157038_85083676 (Smarty_Internal_Template $_smarty_tpl) {
echo '<script'; ?>
>
    var snippet_form_<?php echo $_smarty_tpl->tpl_vars['subcontrol']->value;?>
_phylum = function() {
        "use strict";
        let form = $('#form_<?php echo $_smarty_tpl->tpl_vars['subcontrol']->value;?>
_peque');
        let btn_submit = $('#form_submit_<?php echo $_smarty_tpl->tpl_vars['subcontrol']->value;?>
_peque');
        let btn_close = $('#form_close_<?php echo $_smarty_tpl->tpl_vars['subcontrol']->value;?>
_peque');
        let pmodal = $("#form_modal_<?php echo $_smarty_tpl->tpl_vars['subcontrol']->value;?>
_peque");
        var formv;
        /**
         * Antes de enviar el formulario se ejecuta la siguiente funcion
         */
        var showRequest= function(formData, jqForm, op) {
            btn_submit.addClass('spinner spinner-white spinner-right').attr('disabled', true);
            btn_close.attr('disabled', true);
            return true;
        };

        var showResponse = function (res, statusText) {
            coreUyuni.itemFormShowResponse(res,pmodal,"");
            btn_close.attr('disabled', false);
            btn_submit.removeClass('spinner spinner-white spinner-right').attr('disabled', false);
            snippet_<?php echo $_smarty_tpl->tpl_vars['subcontrol']->value;?>
_form.getPhylum(res.id);
        };
        /**
         * Opciones para generar el objeto del formulario
         */
        var options = {
            beforeSubmit:showRequest
            , success:  showResponse
            , data: {type:'<?php echo $_smarty_tpl->tpl_vars['type']->value;?>
'}
        };
        /**
         * Se da las propiedades de ajaxform al formulario
         */
        var handle_form_submit=function(){
            form.ajaxForm(options);
            formv = FormValidation.formValidation(
                document.getElementById('form_<?php echo $_smarty_tpl->tpl_vars['subcontrol']->value;?>
_peque'),
                {
                    plugins: {
                        declarative: new FormValidation.plugins.Declarative({html5Input: true,}),
                        trigger: new FormValidation.plugins.Trigger(),
                        bootstrap: new FormValidation.plugins.Bootstrap(),
                        submitButton: new FormValidation.plugins.SubmitButton(),
                    }
                }
            );
        };
        /**
         * Se da las funcionalidades al boton enviar
         */
        var handle_btn_submit = function() {
            btn_submit.click(function(e) {
                e.preventDefault();
                /**
                 * Copiamos los datos de summerNote a una variable
                 */

                formv.validate().then(function(status) {
                    if(status === 'Valid'){
                        form.submit();
                    }
                });
            });
        };
        /**
         * Iniciamos los componentes necesarios como , summernote, select2 entre otros
         */
        var handle_components = function(){
            coreUyuni.setComponents();
        };

        //== Public Functions
        return {
            // public functions
            init: function() {
                handle_form_submit();
                handle_btn_submit();
                handle_components();
            }
        };
    }();

    //== Class Initialization
    jQuery(document).ready(function() {
        snippet_form_<?php echo $_smarty_tpl->tpl_vars['subcontrol']->value;?>
_phylum.init();
    });

<?php echo '</script'; ?>
>

<?php }
}
