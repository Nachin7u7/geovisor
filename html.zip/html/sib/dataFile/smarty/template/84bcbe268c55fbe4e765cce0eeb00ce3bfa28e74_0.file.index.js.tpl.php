<?php
/* Smarty version 4.2.1, created on 2022-11-10 08:42:23
  from '/var/www/html/sib/webapp/app/web/module/singin/snippet/index/view/verifica/index.js.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_636cf1af8109a9_14206542',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '84bcbe268c55fbe4e765cce0eeb00ce3bfa28e74' => 
    array (
      0 => '/var/www/html/sib/webapp/app/web/module/singin/snippet/index/view/verifica/index.js.tpl',
      1 => 1668084031,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_636cf1af8109a9_14206542 (Smarty_Internal_Template $_smarty_tpl) {
}
}
