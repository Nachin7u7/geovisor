<?php
/* Smarty version 4.2.1, created on 2023-02-23 06:05:11
  from '/var/www/html/sib/webapp/app/sib/module/botanica/snippet/general/view/index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_63f73a57de0c48_02419390',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '32829a0e84c76351569cd19023393f50860fe243' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/botanica/snippet/general/view/index.tpl',
      1 => 1677146357,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:index.css.tpl' => 1,
    'file:index.js.tpl' => 1,
  ),
),false)) {
function content_63f73a57de0c48_02419390 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_checkPlugins(array(0=>array('file'=>'/var/www/html/sib/vendor/smarty/smarty/libs/plugins/function.html_options.php','function'=>'smarty_function_html_options',),));
$_smarty_tpl->_subTemplateRender("file:index.css.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
<div class="card card-custom gutter-b example example-compact">
    <div class="card-body pt-0 pb-0 pl-5 pr-5">
        <div class="alert alert-custom fade show pt-1 pb-1 pl-5 pr-5 ayuda" role="alert">
            <div class="alert-icon"><i class="flaticon-notes"></i></div>
            <div class="alert-text text-justify text-dark-65" ><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'message');?>
</div>
        </div>
    </div>

    <div class="card-header py-3">
        <div class="card-title">
            <span class="card-icon"><i class="flaticon2-next text-dark-25"></i></span>
            <h3 class="card-label text-dark-50"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'title');?>
</h3>
        </div>
    </div>
    <!--begin::Form-->
    <form method="POST"
          action="<?php echo $_smarty_tpl->tpl_vars['path_url']->value;?>
/<?php echo $_smarty_tpl->tpl_vars['subcontrol']->value;?>
_/<?php if ($_smarty_tpl->tpl_vars['type']->value == "update") {
echo $_smarty_tpl->tpl_vars['id']->value;?>
/<?php }?>save/"
          id="general_form">

        <div class="card-body  pt-1 pb-0">
            <div class="form-group row pt-0 pb-0 mb-0">
                <div class="col-lg-4">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_occurrence_id');?>
:</label>
                    <div class="input-group">
                        <input type="text" class="form-control number_integer2"
                               name="item[occurrence_id]" value="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['item']->value['occurrence_id'], ENT_QUOTES, 'UTF-8', true);?>
"
                        >
                        <div class="input-group-append"><span class="input-group-text field_info"><i class="fas fa-key"></i></span></div>
                    </div>
                    <span class="form-text text-muted"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_msg_occurrence_id');?>
</span>
                </div>
                <div class="col-lg-4">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_basis_of_record');?>
:</label>
                    <div class="input-group">
                        <input type="text" class="form-control number_integer2"
                               name="item[basis_of_record]" value="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['item']->value['basis_of_record'], ENT_QUOTES, 'UTF-8', true);?>
"
                        >
                        <div class="input-group-append"><span class="input-group-text field_info"><i class="fas fa-key"></i></span></div>
                    </div>
                    <span class="form-text text-muted"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_msg_basis_of_record');?>
</span>
                </div>
                <div class="col-lg-4">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_type');?>
  <span class="text-danger bold">*</span> :</label>
                    <div class="input-group">
                        <input type="text" class="form-control"
                               name="item[type]" value="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['item']->value['type'], ENT_QUOTES, 'UTF-8', true);?>
"
                               required
                               data-fv-not-empty___message="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glFieldRequired');?>
"
                               minlength="3"
                               data-fv-string-length___message="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_length_type');?>
"
                        >
                        <div class="input-group-append"><span class="input-group-text field_info"><i class="fas fa-info"></i></span></div>
                    </div>
                    <span class="form-text text-black-50"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_msg_type');?>
</span>
                </div>
            </div>
        </div>

        <div class="card-header py-3">
            <div class="card-title  m-0">
                <span class="card-icon"><i class="flaticon2-next text-dark-25"></i></span>
                <span class="font-weight-bold font-size-h4 text-dark-50"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'title2');?>
</span>
            </div>
        </div>
        <div class="card-body  pt-1 pb-0 proyecto" >
            <div class="form-group row  pt-0 pb-0 mb-0">
                <div class="col-lg-8">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_institution_id');?>
<span class="text-danger bold">*</span> : </label>
                    <div class="input-group">
                        <select class="form-control m-select2 select2_general"
                                name="item[institution_id]" id="institution_id"
                                data-placeholder="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_Holder_institution_id');?>
" <?php echo $_smarty_tpl->tpl_vars['privFace']->value['input'];?>

                                required
                                data-fv-not-empty___message="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glFieldRequired');?>
"
                        >
                            <option></option>
                            <?php echo smarty_function_html_options(array('options'=>$_smarty_tpl->tpl_vars['cataobj']->value['institucion'],'selected'=>$_smarty_tpl->tpl_vars['item']->value['institution_id']),$_smarty_tpl);?>

                        </select>
                    </div>
                    <span class="form-text text-black-50"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_GroupMsg_institution_id');?>
</span>
                </div>
                <div class="col-lg-4" id="institution_code_s">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_institucion_code');?>
:</label>
                    <div class="input-group">
                        <input type="text" class="form-control"
                               name="item[institution_code]"
                               id="institution_code"
                               value="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['item']->value['institution_code'], ENT_QUOTES, 'UTF-8', true);?>
"

                                                                                        >
                        <div class="input-group-append"><span class="input-group-text field_info"><i class="fas flaticon-layer"></i></span></div>
                    </div>
                    <span class="form-text text-black-50"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_msg_institution_code');?>
</span>
                </div>
            </div>
        </div>

        <div class="card-body pt-5 pb-0 ">
            <div class="form-group row">
                <div class="col-lg-4">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_collection_code');?>
:</label>
                    <div class="input-group">
                        <input type="text" class="form-control"
                               name="item[collection_code]" value="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['item']->value['collection_code'], ENT_QUOTES, 'UTF-8', true);?>
"
                        >
                        <div class="input-group-append"><span class="input-group-text field_info"><i class="fab fa-centercode"></i></span></div>
                    </div>
                    <span class="form-text text-muted"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_msg_collection_code');?>
</span>
                </div>
                <div class="col-lg-4">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_collection_id');?>
:</label>
                    <div class="input-group">
                        <input type="text" class="form-control"
                               name="item[collection_id]" value="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['item']->value['collection_id'], ENT_QUOTES, 'UTF-8', true);?>
"
                        >
                        <div class="input-group-append"><span class="input-group-text field_info"><i class="fas fa-key"></i></span></div>
                    </div>
                    <span class="form-text text-muted"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_msg_collection_id');?>
</span>
                </div>
                <div class="col-lg-4">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_catalog_number');?>
:</label>
                    <div class="input-group">
                        <input type="text" class="form-control number_integer2"
                               name="item[catalog_number]" value="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['item']->value['catalog_number'], ENT_QUOTES, 'UTF-8', true);?>
"
                        >
                        <div class="input-group-append"><span class="input-group-text field_info" ><i class="fab fa-centercode"></i></span></div>
                    </div>
                    <span class="form-text text-muted"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_msg_catalog_number');?>
</span>
                </div>
                <div class="col-lg-6">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_language_id');?>
: </label>
                    <div class="input-group">
                        <select class="form-control m-select2 select2_general"
                                name="item[language_id]" id="language_id"
                                data-placeholder="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_Holder_language_id');?>
" <?php echo $_smarty_tpl->tpl_vars['privFace']->value['input'];?>

                        >
                            <option></option>
                            <?php echo smarty_function_html_options(array('options'=>$_smarty_tpl->tpl_vars['cataobj']->value['language'],'selected'=>$_smarty_tpl->tpl_vars['item']->value['language_id']),$_smarty_tpl);?>

                        </select>
                    </div>
                    <span class="form-text text-black-50"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_GroupMsg_language_id');?>
</span>
                </div>
                <div class="col-lg-6">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_license_id');?>
: </label>
                    <div class="input-group">
                        <select class="form-control m-select2 select2_general"
                                name="item[license_id]" id="license_id"
                                data-placeholder="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_Holder_license_id');?>
" <?php echo $_smarty_tpl->tpl_vars['privFace']->value['input'];?>

                        >
                            <option></option>
                            <?php echo smarty_function_html_options(array('options'=>$_smarty_tpl->tpl_vars['cataobj']->value['license'],'selected'=>$_smarty_tpl->tpl_vars['item']->value['license_id']),$_smarty_tpl);?>

                        </select>
                    </div>
                    <span class="form-text text-black-50"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_GroupMsg_license_id');?>
</span>
                </div>
                <div class="col-lg-5">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_rights_holder');?>
  <span class="text-danger bold">*</span> :</label>
                    <div class="input-group">
                        <input type="text" class="form-control"
                               name="item[rights_holder]" value="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['item']->value['rights_holder'], ENT_QUOTES, 'UTF-8', true);?>
"
                               required
                               data-fv-not-empty___message="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glFieldRequired');?>
"
                               minlength="3"
                               data-fv-string-length___message="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_length_rights_holder');?>
"
                        >
                        <div class="input-group-append"><span class="input-group-text field_info"><i class="far fa-user-circle"></i></span></div>
                    </div>
                    <span class="form-text text-black-50"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_msg_rights_holder');?>
</span>
                </div>
                <div class="col-lg-7">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_access_rights');?>
  <span class="text-danger bold">*</span> :</label>
                    <div class="input-group">
                        <input type="text" class="form-control"
                               name="item[access_rights]" value="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['item']->value['access_rights'], ENT_QUOTES, 'UTF-8', true);?>
"
                               required
                               data-fv-not-empty___message="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glFieldRequired');?>
"
                               minlength="3"
                               data-fv-string-length___message="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_length_access_rights');?>
"
                        >
                        <div class="input-group-append"><span class="input-group-text field_info"><i class="fas fa-lock"></i></span></div>
                    </div>
                    <span class="form-text text-black-50"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_msg_access_rights');?>
</span>
                </div>
                <div class="col-lg-12">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_information_withheld');?>
 :</label>
                    <div class="input-group">
                        <input type="text" class="form-control"
                               name="item[information_withheld]" value="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['item']->value['information_withheld'], ENT_QUOTES, 'UTF-8', true);?>
"
                               minlength="3"
                               data-fv-string-length___message="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_length_information_withheld');?>
"
                        >
                        <div class="input-group-append"><span class="input-group-text field_info"><i class="fas fa-clipboard-list"></i></span></div>
                    </div>
                    <span class="form-text text-black-50"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_msg_information_withheld');?>
</span>
                </div>
                <div class="col-lg-6">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_recorded_by');?>
  <span class="text-danger bold">*</span> :</label>
                    <div class="input-group">
                        <input type="text" class="form-control"
                               name="item[recorded_by]" value="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['item']->value['recorded_by'], ENT_QUOTES, 'UTF-8', true);?>
"
                               required
                               data-fv-not-empty___message="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glFieldRequired');?>
"
                               minlength="3"
                               data-fv-string-length___message="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_length_recorded_by');?>
"
                        >
                        <div class="input-group-append"><span class="input-group-text field_info"><i class="far fa-user-circle"></i></span></div>
                    </div>
                    <span class="form-text text-black-50"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_msg_recorded_by');?>
</span>
                </div>
                <div class="col-lg-3">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_individual_count');?>
:</label>
                    <div class="input-group">
                        <input type="text" class="form-control number_integer2"
                               name="item[individual_count]" value="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['item']->value['individual_count'], ENT_QUOTES, 'UTF-8', true);?>
"
                        >
                        <div class="input-group-append"><span class="input-group-text field_info"><i class="fas fa-key"></i></span></div>
                    </div>
                    <span class="form-text text-muted"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_msg_individual_count');?>
</span>
                </div>
                <div class="col-lg-3">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_sex_id');?>
: </label>
                    <div class="input-group">
                        <select class="form-control m-select2 select2_general"
                                name="item[sex_id]" id="sex_id"
                                data-placeholder="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_Holder_sex_id');?>
" <?php echo $_smarty_tpl->tpl_vars['privFace']->value['input'];?>

                        >
                            <option></option>
                            <?php echo smarty_function_html_options(array('options'=>$_smarty_tpl->tpl_vars['cataobj']->value['sex'],'selected'=>$_smarty_tpl->tpl_vars['item']->value['sex_id']),$_smarty_tpl);?>

                        </select>
                    </div>
                    <span class="form-text text-black-50"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_GroupMsg_sex_id');?>
</span>
                </div>
                <div class="col-lg-4">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_life_stage_id');?>
: </label>
                    <div class="input-group">
                        <select class="form-control m-select2 select2_general"
                                name="item[life_stage_id]" id="type_select_estado"
                                data-placeholder="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_Holder_life_stage_id');?>
" <?php echo $_smarty_tpl->tpl_vars['privFace']->value['input'];?>

                        >
                            <option></option>
                            <?php echo smarty_function_html_options(array('options'=>$_smarty_tpl->tpl_vars['cataobj']->value['life_stage'],'selected'=>$_smarty_tpl->tpl_vars['item']->value['life_stage_id']),$_smarty_tpl);?>

                        </select>
                    </div>
                    <span class="form-text text-black-50"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_GroupMsg_life_stage_id');?>
</span>
                </div>
                <div class="col-lg-4">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_occurrence_status_id');?>
: </label>
                    <div class="input-group">
                        <select class="form-control m-select2 select2_general"
                                name="item[occurrence_status_id]" id="occurrence_status_id"
                                data-placeholder="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_Holder_occurrence_status_id');?>
" <?php echo $_smarty_tpl->tpl_vars['privFace']->value['input'];?>

                        >
                            <option></option>
                            <?php echo smarty_function_html_options(array('options'=>$_smarty_tpl->tpl_vars['cataobj']->value['occurrence_status'],'selected'=>$_smarty_tpl->tpl_vars['item']->value['occurrence_status_id']),$_smarty_tpl);?>

                        </select>
                    </div>
                    <span class="form-text text-black-50"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_GroupMsg_occurrence_status_id');?>
</span>
                </div>
                <div class="col-lg-4">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_preparations_id');?>
: </label>
                    <div class="input-group">
                        <select class="form-control m-select2 select2_general"
                                name="item[preparations_id]" id="preparations_id"
                                data-placeholder="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_Holder_preparations_id');?>
" <?php echo $_smarty_tpl->tpl_vars['privFace']->value['input'];?>

                        >
                            <option></option>
                            <?php echo smarty_function_html_options(array('options'=>$_smarty_tpl->tpl_vars['cataobj']->value['preparations'],'selected'=>$_smarty_tpl->tpl_vars['item']->value['preparations_id']),$_smarty_tpl);?>

                        </select>
                    </div>
                    <span class="form-text text-black-50"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_GroupMsg_preparations_id');?>
</span>
                </div>
                <div class="col-lg-5">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_disposition');?>
 :</label>
                    <div class="input-group">
                        <input type="text" class="form-control"
                               name="item[disposition]" value="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['item']->value['disposition'], ENT_QUOTES, 'UTF-8', true);?>
"
                               minlength="3"
                               data-fv-string-length___message="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_length_disposition');?>
"
                        >
                        <div class="input-group-append"><span class="input-group-text field_info"><i class="fas fa-folder-plus"></i></span></div>
                    </div>
                    <span class="form-text text-black-50"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_msg_disposition');?>
</span>
                </div>
                <div class="col-lg-3">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_event_id');?>
 :</label>
                    <div class="input-group">
                        <input type="text" class="form-control"
                               name="item[event_id]" value="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['item']->value['event_id'], ENT_QUOTES, 'UTF-8', true);?>
"
                        >
                        <div class="input-group-append"><span class="input-group-text field_info"><i class="fab fa-orcid"></i></span></div>
                    </div>
                    <span class="form-text text-black-50"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_msg_event_id');?>
</span>
                </div>
                <div class="col-lg-4">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_sampling_protocol');?>
 :</label>
                    <div class="input-group">
                        <input type="text" class="form-control"
                               name="item[sampling_protocol]" value="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['item']->value['sampling_protocol'], ENT_QUOTES, 'UTF-8', true);?>
"
                        >
                        <div class="input-group-append"><span class="input-group-text field_info"><i class="    fas fa-scroll"></i></span></div>
                    </div>
                    <span class="form-text text-black-50"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_msg_sampling_protocol');?>
</span>
                </div>
                <div class="col-lg-12">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_occurrence_remarks');?>
 </label>
                    <div class="m-input-icon m-input-icon--right">
                        <div class="summernote" id="occurrence_remarks"><?php echo $_smarty_tpl->tpl_vars['item']->value['occurrence_remarks'];?>
</div>
                        <input class="form-control m-input" type="hidden" name="item[occurrence_remarks]" id="occurrence_remarks_input" <?php echo $_smarty_tpl->tpl_vars['privFace']->value['input'];?>
>
                    </div>
                </div>
            </div>
        </div>


        <div class="card-footer">
            <?php if ($_smarty_tpl->tpl_vars['privFace']->value['edit'] == 1) {?>
                <button type="reset" class="btn btn-primary mr-2" id="general_submit">
                    <i class="la la-save"></i>
                    <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glBtnSaveChanges');?>
</button>
            <?php }?>
            <a href="<?php echo $_smarty_tpl->tpl_vars['path_url']->value;?>
" class="btn btn-light-primary ">
                <i class="la la-angle-double-left"></i><?php if ($_smarty_tpl->tpl_vars['type']->value == "new") {?> <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glBtnCancel');?>
 <?php } else { ?> <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glBtnBackToList');
}?>
            </a>
        </div>

    </form>
    <!--end::Form-->
</div>

<?php $_smarty_tpl->_subTemplateRender("file:index.js.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
