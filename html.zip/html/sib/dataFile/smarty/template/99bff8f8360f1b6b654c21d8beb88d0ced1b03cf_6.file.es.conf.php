<?php /* Smarty version 4.2.1, created on 2022-11-09 17:48:36
         compiled from '/var/www/html/sib/webapp/app/sib/module/user/snippet/general/language/es.conf' */ ?>
<?php
/* Smarty version 4.2.1, created on 2022-11-09 17:48:36
  from '/var/www/html/sib/webapp/app/sib/module/user/snippet/general/language/es.conf' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_636c2034e8ba93_12963180',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '99bff8f8360f1b6b654c21d8beb88d0ced1b03cf' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/user/snippet/general/language/es.conf',
      1 => 1668028010,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_636c2034e8ba93_12963180 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigVars($_smarty_tpl, array (
  'sections' => 
  array (
    'general' => 
    array (
      'vars' => 
      array (
        'title' => 'Géstion de Usuarios',
        'message' => 'Podrás realizar el registro y configuración de usuario del sistema',
        'fieldName' => 'Nombres',
        'fieldNameLength' => 'Tiene que ser mayor o igual a 3 caracteres',
        'fieldNameMsg' => 'Ingrese el nombre de la persona',
        'fieldLastName' => 'Apellidos',
        'fieldLastNameLength' => 'Tiene que ser mayor o igual a 3 caracteres',
        'fieldLastNameMsg' => 'Ingrese los apellidos de la persona',
        'fieldPhone' => 'Número de teléfono',
        'fieldPhoneLength' => 'Tiene que ser mayor o igual a 3 caracteres',
        'fieldPhoneMsg' => 'Ingrese el número de teléfono fijo de la persona',
        'fieldMobile' => 'Número de celular',
        'fieldMobileLength' => 'Tiene que ser mayor o igual a 3 caracteres',
        'fieldMobileMsg' => 'Ingrese el número de celular de la persona',
        'fieldType' => 'Tipo de usuario',
        'field_Holder_type' => 'Seleccione una opción',
        'field_GroupMsg_type' => 'Seleccione el tipo de usuario',
        'field_distribuidora' => 'Empresa distribuidora',
        'field_Holder_distribuidora' => 'Seleccione una opción',
        'field_GroupMsg_distribuidora' => 'Seleccione la empresa distribuidora',
        'fieldDescription' => 'Descripción del usuario',
        'fieldDescriptionMsg' => 'Ingrese la descripción del usuario',
        'fieldActiveName' => 'Estado del usuario',
        'fieldActiveMsg' => 'Activo/Inactivo',
        'fieldUserName' => 'Nombre de usuario',
        'fieldUserNameMsg' => 'Ingrese el nombre de usuario de la persona',
        'fieldPass' => 'Contraseña',
        'fieldPassLength' => 'Tiene que ser mayor o igual a 3 caracteres',
        'fieldPassMsg' => 'Ingrese la contraseña del usuario',
        'fieldPassUpdateMsg' => 'Ingrese una nueva contraseña <span class="text-danger bold"> SOLO SI DESEA CAMBIARLA</span>',
        'opt_typeuser_1' => 'Administrador',
        'opt_typeuser_2' => 'Técnico',
        'opt_typeuser_3' => 'Distribuidora',
      ),
    ),
    'form' => 
    array (
      'vars' => 
      array (
        'title' => 'Usuarios',
      ),
    ),
  ),
  'vars' => 
  array (
  ),
));
}
}
