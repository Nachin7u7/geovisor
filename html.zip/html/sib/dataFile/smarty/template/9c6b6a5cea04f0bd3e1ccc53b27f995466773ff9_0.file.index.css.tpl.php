<?php
/* Smarty version 4.2.1, created on 2023-03-02 08:42:22
  from '/var/www/html/sib/webapp/app/sib/module/zoologia_ictiologia/snippet/datoscolecta/view/index.css.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_640099ae1d1535_82670812',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '9c6b6a5cea04f0bd3e1ccc53b27f995466773ff9' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/zoologia_ictiologia/snippet/datoscolecta/view/index.css.tpl',
      1 => 1677671930,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_640099ae1d1535_82670812 (Smarty_Internal_Template $_smarty_tpl) {
?>
    <style>
        .select2-results__group{
            background: #e7f1f6;
            border-bottom: 2px solid #006ba2;
        }

    </style>
<?php }
}
