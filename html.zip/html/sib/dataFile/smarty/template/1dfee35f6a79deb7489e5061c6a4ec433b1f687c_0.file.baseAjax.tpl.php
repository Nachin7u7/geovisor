<?php
/* Smarty version 4.2.1, created on 2023-01-10 11:32:32
  from '/var/www/html/sib/webapp/app/core/template/base/baseAjax.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_63bd8510e574b7_68743695',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '1dfee35f6a79deb7489e5061c6a4ec433b1f687c' => 
    array (
      0 => '/var/www/html/sib/webapp/app/core/template/base/baseAjax.tpl',
      1 => 1668028010,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_63bd8510e574b7_68743695 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender(((string)$_smarty_tpl->tpl_vars['subpage']->value), $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, true);
}
}
