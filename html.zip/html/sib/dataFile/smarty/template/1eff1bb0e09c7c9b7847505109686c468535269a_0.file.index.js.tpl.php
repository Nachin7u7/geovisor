<?php
/* Smarty version 4.2.1, created on 2022-11-10 08:41:18
  from '/var/www/html/sib/webapp/app/web/module/singin/snippet/index/view/index.js.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_636cf16ecb3e31_11777393',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '1eff1bb0e09c7c9b7847505109686c468535269a' => 
    array (
      0 => '/var/www/html/sib/webapp/app/web/module/singin/snippet/index/view/index.js.tpl',
      1 => 1668084031,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_636cf16ecb3e31_11777393 (Smarty_Internal_Template $_smarty_tpl) {
echo '<script'; ?>
 type="text/javascript" src="/js/md5.js"><?php echo '</script'; ?>
>

<?php echo '<script'; ?>
>

var snippet_general_form = function() {
        "use strict";
        /**
         * Datos del formulario y el boton
         */
        var form = $('#general_form');
        var btn_submit = $('#general_submit');

        var formv;

        /**
         * Antes de enviar el formulario se ejecuta la siguiente funcion
         */
         var showRequest= function(formData, jqForm, op)  {
            btn_submit.addClass('spinner spinner-white spinner-right').attr('disabled', true);
            return true;
        };


        var showResponse = function (res, statusText) {
            //
            if(res.res ==1){
                Swal.fire({
                    icon: 'success',
                    title: 'Se registro al usuario con exito!!!',
                    showConfirmButton: false,
                    html: 'Se envio un correo a tu correo electrónico,<strong> sigue las instrucciones para terminar tu registro </string>',
                    timer: 2500,
                    willClose: () => {
                        location = "/login";
                    }
                });
            }else{
                btn_submit.removeClass('spinner spinner-white spinner-right').attr('disabled', false);
                var errorname = "<strong>El Usuario ya se encuentra registrado</strong><br>";
                Swal.fire({icon: "error", title: 'No se puede registrar al usuario', html:errorname,
                    showClass: {popup: 'animate__animated animate__wobble'},
                });
            }
        };
        /**
         * Opciones para generar el objeto del formulario
         */
        var options = {
            beforeSubmit:showRequest
            , dataType: 'json'
            , success:  showResponse
            , data: {type:'<?php echo $_smarty_tpl->tpl_vars['type']->value;?>
'}
        };

        /**
         * Se da las propiedades de ajaxform al formulario
         */
        var handle_form_submit=function(){
            form.ajaxForm(options);
            formv = FormValidation.formValidation(
                document.getElementById('general_form'),
                {
                    plugins: {
                        declarative: new FormValidation.plugins.Declarative({html5Input: true,}),
                        trigger: new FormValidation.plugins.Trigger(),
                        bootstrap: new FormValidation.plugins.Bootstrap(),
                        submitButton: new FormValidation.plugins.SubmitButton(),
                    }
                }
            );

        };


        //== Private Functions
        
        var showResponse2 = function (responseText, statusText) {
            general_btn_submit.removeClass('m-loader m-loader--right m-loader--light').attr('disabled', false);
            if(responseText.res ==1){

                    swal({type: 'success'
                        ,title: 'Se registro al usuario con exito!!!'
                        ,showConfirmButton: false
                        ,timer: 2000
                        ,onClose: () => {
                            //$('#especie_tab').trigger('click');
                            location = "/ingreso";
                        }
                    });


            }else{
                //msg_error = '<strong>Ocurrio error al registrar</strong><br>'+responseText.msg;
                msg_error = '<strong>El Usuario ya se encuentra registrado</strong><br>';
                if (responseText.msgdb !== undefined){
                    //msg_error += '<br><br><div class="m-alert m-alert--outline alert alert-danger alert-dismissible fade show" role="alert">';
                    //msg_error += '<strong>Dato Técnico: </strong>'+responseText.msgdb+'</div>';
                }
                swal({position: 'top-center'
                    ,html: msg_error
                    ,type: 'error'
                    ,title: 'No se puede registrar al usuario'});
            }
        };

        /**
         * Se da las funcionalidades al boton enviar
         */
        var handle_btn_submit = function() {
            btn_submit.click(function(e) {
                e.preventDefault();
                /**
                 * Copiamos los datos de summerNote a una variable
                 */
                formv.validate().then(function(status) {
                    if(status === 'Valid'){
                        form.submit();
                    }else{
                        Swal.fire({icon: 'error',title: 'No se puede realizar el registro', text: "Ingrese todos los campos requeridos para poder realizar el registro"});
                    }
                });

            });
        };

        /**
         * Iniciamos los componentes necesarios como , summernote, select2 entre otros
         */
         var handle_components = function(){
            coreUyuni.setComponents();
        };


        //== Public Functions
        return {
            // public functions
            init: function() {
                handle_form_submit();
                handle_btn_submit();
                handle_components();
            }
            
            <?php if ($_smarty_tpl->tpl_vars['item']->value['itemId'] == '' && $_smarty_tpl->tpl_vars['type']->value == "update") {?>
            
            msg_error();
        
        <?php }?>
        
    };
    }();

    //== Class Initialization
    jQuery(document).ready(function() {
        snippet_general_form.init();
    });

<?php echo '</script'; ?>
>
<?php }
}
