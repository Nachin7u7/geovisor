<?php /* Smarty version 4.2.1, created on 2023-02-06 16:01:59
         compiled from '/var/www/html/sib/webapp/app/sib/module/catalogoTaxonomia/snippet/index/language/es.conf' */ ?>
<?php
/* Smarty version 4.2.1, created on 2023-02-06 16:01:59
  from '/var/www/html/sib/webapp/app/sib/module/catalogoTaxonomia/snippet/index/language/es.conf' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_63e15cb74e9850_37471033',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '3179a23deddd810c47da1da8f18f57eeaa96a450' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/catalogoTaxonomia/snippet/index/language/es.conf',
      1 => 1675456623,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_63e15cb74e9850_37471033 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigVars($_smarty_tpl, array (
  'sections' => 
  array (
    'index' => 
    array (
      'vars' => 
      array (
        'title' => 'Gestión de Catalogos de Taxonomias',
        'title_filter' => 'Filtro',
        'btnNew' => 'Nueva Taxonomia',
        'filterName' => 'Buscar por nombre de la',
        'filterHolderName' => 'Escribir el nombre institución',
        'filterorma' => 'Buscar por norma',
        'filterNormaSelectAll' => 'Todas las normas',
        'filterStatus' => 'Estado',
        'filterStatusSelectAll' => 'Todos los estados',
        'dataTableExportTitle' => 'Lista de INSTITUCIONES CIENTIFICAS AUTORIZADAS',
      ),
    ),
    'tableIndex' => 
    array (
      'vars' => 
      array (
        'table_nombre_cientifico' => 'Nombre cientifico',
        'table_nombre' => 'Nombre Institución',
        'table_direccion' => 'Dirección',
        'table_telefono' => 'Telefono',
        'table_fax' => 'Fax',
        'table_celular' => 'Celular',
        'table_email' => 'Email',
        'table_responsable' => 'Responsable',
        'table_responsable_operativo' => 'Responsable Operativo',
      ),
    ),
    'item' => 
    array (
      'vars' => 
      array (
        'title' => 'Gestión de Catalogos Taxonomicos',
      ),
    ),
    'tabItem' => 
    array (
      'vars' => 
      array (
        'tabGeneral' => 'General',
        'tab_foto' => 'Fotografias',
      ),
    ),
  ),
  'vars' => 
  array (
  ),
));
}
}
