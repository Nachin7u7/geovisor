<?php
/* Smarty version 4.2.1, created on 2022-11-10 11:22:34
  from '/var/www/html/sib/webapp/app/setting/module/app/snippet/index/view/index.search.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_636d173a3529d3_14242725',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '20e4897fff00d5c9c2ff625beaa98ddd1b8075d8' => 
    array (
      0 => '/var/www/html/sib/webapp/app/setting/module/app/snippet/index/view/index.search.tpl',
      1 => 1668028010,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_636d173a3529d3_14242725 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="row alert alert-custom alert-light-primary fade show mb-5" role="alert" >
    <div class="col-lg-4 alert-text">
        <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'filterName');?>
:</label>
        <input type="text" class="filtro-buscar-text form-control m-input" placeholder="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'filterNameHolder');?>
" data-col-index="2">
    </div>
    <div class="col-lg-4 alert-text">
        <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'filterFolderName');?>
:</label>
        <input type="text" class="filtro-buscar-text form-control m-input" placeholder="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'filterFolderNameHolder');?>
" data-col-index="8">
    </div>

    </div>

<?php }
}
