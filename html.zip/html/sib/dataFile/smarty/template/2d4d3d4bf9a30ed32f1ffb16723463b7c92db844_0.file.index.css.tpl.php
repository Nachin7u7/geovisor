<?php
/* Smarty version 4.2.1, created on 2023-02-06 16:01:59
  from '/var/www/html/sib/webapp/app/sib/module/catalogoTaxonomia/snippet/index/view/index.css.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_63e15cb7593c91_98206079',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '2d4d3d4bf9a30ed32f1ffb16723463b7c92db844' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/catalogoTaxonomia/snippet/index/view/index.css.tpl',
      1 => 1675456623,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_63e15cb7593c91_98206079 (Smarty_Internal_Template $_smarty_tpl) {
?>
    <style>
        .dtrg-level-0 td{
            /* background: #e7f2fe!important;
             border-top: 4px solid #9bbbde;*/
            background: #fafbfc !important;
            border-top: 2px solid #c0d8e6;
            padding: 5px 5px 5px 5px !important;

        }
        .dtrg-level-0 td::before {
            font-family: "Font Awesome 5 Free";
            font-weight: 900;
            content: "\f107";
            margin-right: 5px;
        }

        .dtrg-level-1 td{
            background: #f2f8ff !important;
            padding: 5px 5px 5px 10px !important;
            color: #3699ff !important;
        }
        .dtrg-level-1 td::before {
            font-family: "Font Awesome 5 Free";
            font-weight: 900;
            content: "\f107";
            margin-right: 5px;
        }
    </style>
<?php }
}
