<?php
/* Smarty version 4.2.1, created on 2022-11-11 01:40:00
  from '/var/www/html/sib/webapp/app/sib/module/botanica/snippet/foto/view/form/form.css.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_636de03006a205_81746697',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '732058038c09a7a21aea4b0b66c3536135aee19c' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/botanica/snippet/foto/view/form/form.css.tpl',
      1 => 1668144867,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_636de03006a205_81746697 (Smarty_Internal_Template $_smarty_tpl) {
?>
    <style>
        .custom-file-label::after {
            content: "<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'gl_search_file');?>
" !important;
        }
    </style>
<?php }
}
