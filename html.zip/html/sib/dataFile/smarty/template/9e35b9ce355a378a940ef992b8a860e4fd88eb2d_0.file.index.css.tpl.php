<?php
/* Smarty version 4.2.1, created on 2023-02-06 08:50:42
  from '/var/www/html/sib/webapp/app/sib/module/taxonomia_botanica/snippet/index/view/item/index.css.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_63e0f7a2e80fe7_89061030',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '9e35b9ce355a378a940ef992b8a860e4fd88eb2d' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/taxonomia_botanica/snippet/index/view/item/index.css.tpl',
      1 => 1675456623,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_63e0f7a2e80fe7_89061030 (Smarty_Internal_Template $_smarty_tpl) {
?><link rel="stylesheet" type="text/css" href="/js/geo/leaflet.1.7.1/leaflet.css"  />
<link rel="stylesheet" type="text/css" href="/js/geo/leaflet.fullscreen/Control.FullScreen.css" />
<link rel="stylesheet" type="text/css" href="/js/geo/leaflet.groupedlayercontrol/dist/leaflet.groupedlayercontrol.min.css" />

    <style>
    </style>
<?php }
}
