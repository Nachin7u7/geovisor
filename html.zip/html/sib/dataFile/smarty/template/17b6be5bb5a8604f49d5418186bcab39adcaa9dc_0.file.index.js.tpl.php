<?php
/* Smarty version 4.2.1, created on 2023-01-10 11:32:32
  from '/var/www/html/sib/webapp/app/setting/module/app/snippet/module/view/index.js.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_63bd8510f030e8_33460634',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '17b6be5bb5a8604f49d5418186bcab39adcaa9dc' => 
    array (
      0 => '/var/www/html/sib/webapp/app/setting/module/app/snippet/module/view/index.js.tpl',
      1 => 1668028010,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_63bd8510f030e8_33460634 (Smarty_Internal_Template $_smarty_tpl) {
echo '<script'; ?>
>
    var table_list;
    var snippet_list = function() {
        "use strict";
        var urlsys = '<?php echo $_smarty_tpl->tpl_vars['path_url']->value;?>
/<?php echo $_smarty_tpl->tpl_vars['subcontrol']->value;?>
_/<?php echo $_smarty_tpl->tpl_vars['id']->value;?>
';
        var initTable = function() {
            let table_list_var = $('#tabla_<?php echo $_smarty_tpl->tpl_vars['subcontrol']->value;?>
');
            let export_title = "<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'dataTableExportTitle');?>
";
            let noExport = tableSetting.noExport;
            table_list = table_list_var.DataTable({
                initComplete: function(settings, json) {
                    table_list_var.removeClass('d-none');
                },
                keys: {
                    columns: noExport,
                    clipboard: false,
                },
                dom: tableSetting.dom,
                buttons: [
                    /*
                    {extend:'colvis',text:lngUyuni.dataTableWatch
                        ,columnText: function ( dt, idx, title ) {
                            return (idx+1)+': '+title;
                        }
                    },
                    */
                    {extend:'excelHtml5'
                        ,exportOptions: {columns: noExport}
                        , title: export_title
                    },
                    {extend:'pdfHtml5'
                        ,exportOptions: {columns: noExport}
                        , title: export_title
                        , download: 'open'
                        , pageSize: 'LETTER'
                        ,customize: function(doc) {
                            doc.styles.tableHeader.fontSize = 7;
                            doc.defaultStyle.fontSize = 7;
                            doc.pageMargins= [ 20, 20];
                        }
                    },
                    {extend:'print'
                        ,exportOptions: {columns: noExport}
                        ,text: lngUyuni.dataTablePrint
                    }

                ],
                colReorder: true,
                responsive: true,
                language: {"url": "/language/js/datatable."+lng+".json"},
                lengthMenu: [[10, 25, 50,-1], [10, 25, 50, lngUyuni.dataTableAll]],
                pageLength: 25,
                //order: [[ 0, "asc" ]], // Por que campo ordenara al momento de desplegar
                InfoFiltered: false,
                searchDelay: 500,
                processing: true,
                serverSide: true,
                ajax: {
                    url: urlsys+'/list',
                    type: 'POST',
                    data: {},
                },
                columns: [
                    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['gridItem']->value, 'row', false, 'idx');
$_smarty_tpl->tpl_vars['row']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['idx']->value => $_smarty_tpl->tpl_vars['row']->value) {
$_smarty_tpl->tpl_vars['row']->do_else = false;
?>
                    <?php if ($_smarty_tpl->tpl_vars['idx']->value != 0) {?>,<?php }?>{data: '<?php if ($_smarty_tpl->tpl_vars['row']->value['as']) {
echo $_smarty_tpl->tpl_vars['row']->value['as'];
} else {
echo $_smarty_tpl->tpl_vars['row']->value['field'];
}?>'<?php if ($_smarty_tpl->tpl_vars['row']->value['responsive']) {?>, responsivePriority: -1<?php }?>}
                    <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                ],

                rowGroup: {
                    dataSrc: ['groupname']
                },

                columnDefs: [
                    {
                        targets: -1,
                        width: "90px",
                        className: 'noExport',
                        orderable: false,
                        searchable: false,
                        render: function(data, type, full, meta) {
                            var boton = '<div class="btn-group btn-group-sm " role="group" aria-label="Accion">';
                            var lbEdit = <?php if ($_smarty_tpl->tpl_vars['privFace']->value['edit'] == 1) {?>lngUyuni.btnEdit<?php } else { ?>lngUyuni.btnViewData<?php }?>;
                            boton += '<a href="javascript:snippet_list.update(\''+data+'\');" class="btn btn-success btn-sm" title="'+lbEdit+'">'+lbEdit+'</a>';
                            <?php if ($_smarty_tpl->tpl_vars['privFace']->value['edit'] == 1 && $_smarty_tpl->tpl_vars['privFace']->value['delete'] == 1) {?>
                            boton += '<a href="javascript:snippet_list.delete(\''+data+'\');" class="btn btn-icon btn-light-danger btn-sm" title="'+lngUyuni.btnDelete+'"><i class="flaticon-delete-1"></i></a>';
                            <?php }?>
                            boton += '<div>';
                            return boton;
                        },
                    },
                    {
                        targets: [0],
                        visible:false
                    },
                    {
                        targets: [2,3,5,10],
                        searchable: false,
                    },
                    {
                        targets: [1],
                        orderData: [ 0, 1 ],
                        render: function(data,type,full,meta){
                            return '<span class="font-weight-bold text-primary">' + data + '</span>';
                        },
                    },
                    { targets: [2], orderData: [ 0, 2 ]},
                    { targets: [3], orderData: [ 0, 3 ]},
                    {
                        targets: [4],
                        orderData: [ 0, 4 ],
                        render: function(data,type,full,meta){
                            let icono;
                            if (data!=""){
                                icono = '<a href="#" class="btn btn-icon btn-primary btn-lg mr-4"><i class="'+data+' m--font-success icono_lista"></i></a>';
                            }else{
                                icono = '';
                            }
                            return icono;
                        },

                    },
                    {
                        targets: [5],
                        orderData: [0,7],
                        width: '60px',
                        className: 'text-center',
                        render: function(data, type, full, meta) {
                            var status = {
                                'false': { 'state': 'metal'},
                                'true': { 'state': 'success'}
                            };
                            if (typeof status[data] === 'undefined') {
                                return data;
                            }
                            return '<i class="fa fa-check-double text-' + status[data].state + '"></i>';
                        },
                    },
                    {
                        targets: 6,
                        orderData: [ 0, 6 ],
                        render: function(data, type, full, meta) {
                            var status = {
                                'module': {'title': 'FOLDER', 'class': ' label-light-warning'},
                                'url': {'title': 'URL', 'class': ' label-light-success'},
                            };
                            if (typeof status[data] === 'undefined') {
                                return data;
                            }
                            return '<span class="label label-lg font-weight-bold' + status[data].class + ' label-inline">' + status[data].title + '</span>';
                        },
                    },
                    {
                        targets: [7],
                        orderData: [ 0, 7 ],
                        render: function(data,type,full,meta){
                            if (data == null){
                                var carpeta = "";
                            }else{
                                var carpeta = '<span class="label label-lg font-weight-bold label-info label-inline"><i class="text-white fas fa-folder-open mr-2"></i>' + data + '</span>';
                            }
                            return carpeta;
                        },
                    },
                    { targets: [8], orderData: [ 0, 8 ]},
                    { targets: [9], orderData: [ 0, 9 ]},
                    {
                        targets: [10],
                        orderData: [0,10],
                        width: '60px',
                        className: 'text-center',
                        render: function(data, type, full, meta) {
                            var status = {
                                'false': { 'state': 'metal'},
                                'true': { 'state': 'success'}
                            };
                            if (typeof status[data] === 'undefined') {
                                return data;
                            }
                            return '<i class="fa fa-check-double text-' + status[data].state + '"></i>';
                        },
                    },
                ],
            });
        };
        /**
         * New and Update
         */
        var btn_update = $('#btn_form_<?php echo $_smarty_tpl->tpl_vars['subcontrol']->value;?>
');
        var handle_button_update = function(){
            btn_update.click(function(e){
                e.preventDefault();
                item_update("","new");
            });
        };

        var item_update = function(id,type){
            var subcontrol = "<?php echo $_smarty_tpl->tpl_vars['subcontrol']->value;?>
";
            coreUyuni.itemUpdateTabs(id,type,urlsys,subcontrol);
        };

        /**
         * Delete
         */
        var  item_delete = function(id){
            var url = urlsys+"/"+id+"/delete";
            coreUyuni.itemDelete(id,url,table_list);
        };
        /**
         * Inicializar componentes
         */
        var handle_components = function(){
            coreUyuni.setComponents();
        };
        /**
         * Filtros
         */
        var handle_filtro = function () {
            coreUyuni.tableFilter();
        };

        return {
            //main function to initiate the module
            init: function() {
                handle_button_update();
                initTable();
                handle_components();
                handle_filtro();
            },
            update: function(id,type){
                item_update(id,"update");
            },
            delete: function(id){
                item_delete(id);
            },
        };
    }();

    jQuery(document).ready(function() {
        snippet_list.init();
    });
<?php echo '</script'; ?>
>


<?php }
}
