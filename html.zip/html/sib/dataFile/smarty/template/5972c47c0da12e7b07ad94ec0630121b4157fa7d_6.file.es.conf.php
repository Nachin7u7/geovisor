<?php /* Smarty version 4.2.1, created on 2023-04-13 16:30:03
         compiled from '/var/www/html/sib/webapp/app/sib/module/taxonomia_reptiles/snippet/index/language/es.conf' */ ?>
<?php
/* Smarty version 4.2.1, created on 2023-04-13 16:30:03
  from '/var/www/html/sib/webapp/app/sib/module/taxonomia_reptiles/snippet/index/language/es.conf' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_6438664b030b38_77864782',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '5972c47c0da12e7b07ad94ec0630121b4157fa7d' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/taxonomia_reptiles/snippet/index/language/es.conf',
      1 => 1678278586,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6438664b030b38_77864782 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigVars($_smarty_tpl, array (
  'sections' => 
  array (
    'index' => 
    array (
      'vars' => 
      array (
        'title' => 'Gestión de Catalogos de Taxonomias',
        'title_filter' => 'Filtro',
        'btnNew' => 'Nueva Taxonomia',
        'filterName' => 'Buscar por nombre de la',
        'filterHolderName' => 'Escribir el nombre institución',
        'filterorma' => 'Buscar por norma',
        'filterNormaSelectAll' => 'Todas las normas',
        'filterStatus' => 'Estado',
        'filterStatusSelectAll' => 'Todos los estados',
        'dataTableExportTitle' => 'Lista de INSTITUCIONES CIENTIFICAS AUTORIZADAS',
      ),
    ),
    'tableIndex' => 
    array (
      'vars' => 
      array (
        'table_scientific_name' => 'Nombre Científico',
        'table_kingdom' => 'Reino',
        'table_class' => 'Clase',
        'table_order' => 'Orden',
        'table_family' => 'Familia',
        'table_genus' => 'Género',
      ),
    ),
    'item' => 
    array (
      'vars' => 
      array (
        'title' => 'Gestión de Catalogos Taxonomicos',
      ),
    ),
    'tabItem' => 
    array (
      'vars' => 
      array (
        'tabGeneral' => 'General',
        'tab_foto' => 'Fotografias',
      ),
    ),
  ),
  'vars' => 
  array (
  ),
));
}
}
