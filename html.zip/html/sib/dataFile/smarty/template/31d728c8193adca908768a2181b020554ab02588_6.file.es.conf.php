<?php /* Smarty version 4.2.1, created on 2022-11-09 17:25:50
         compiled from '/var/www/html/sib/webapp/app/sib/language/es.conf' */ ?>
<?php
/* Smarty version 4.2.1, created on 2022-11-09 17:25:50
  from '/var/www/html/sib/webapp/app/sib/language/es.conf' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_636c1ade9b0930_46002333',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '31d728c8193adca908768a2181b020554ab02588' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/language/es.conf',
      1 => 1668028010,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_636c1ade9b0930_46002333 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigVars($_smarty_tpl, array (
  'sections' => 
  array (
  ),
  'vars' => 
  array (
    'sbmBtnHome' => 'SIB',
    'sbmBtnMain' => 'Volver',
    'sbmTitleMenu' => 'Sistema',
    'sbmTitle' => 'SIB',
  ),
));
}
}
