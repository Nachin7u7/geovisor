<?php /* Smarty version 4.2.1, created on 2024-05-27 11:52:10
         compiled from '/var/www/html/sib/webapp/app/sib/module/zoologia_mastozoologia/snippet/lugarcolecta/language/es.conf' */ ?>
<?php
/* Smarty version 4.2.1, created on 2024-05-27 11:52:10
  from '/var/www/html/sib/webapp/app/sib/module/zoologia_mastozoologia/snippet/lugarcolecta/language/es.conf' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_6654ac2adaaaf1_39215094',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '917a924d0b16f5abd8b29001c250c4ed8d9f6864' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/zoologia_mastozoologia/snippet/lugarcolecta/language/es.conf',
      1 => 1688391178,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6654ac2adaaaf1_39215094 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigVars($_smarty_tpl, array (
  'sections' => 
  array (
    'index' => 
    array (
      'vars' => 
      array (
        'title' => 'Ubicación Administrativa',
        'message' => '<strong>Adicionar datos de ubicación administrativa</strong><br> Haga clic en el boton <strong>"Adicionar ubicación"</strong> para añadir un registro.',
        'btnNew' => 'Adicionar ubicación',
        'dataTableExportTitle' => 'Lista de ubicaciones',
        'title_datos' => 'Ubicación',
        'fiel_location_latitude_decimal' => 'Latitude Decimal',
        'field_msg_location_latitude_decimal' => 'Ingrese la Latitud',
        'fiel_location_longitude_decimal' => 'Longitude Decimal',
        'field_msg_location_longitude_decimal' => 'Ingrese la Longitud',
        'field_utm_latitude' => 'UTM Este (X)',
        'field_msg_utm_latitude' => 'Ingrese UTM Este (X)',
        'field_utm_longitude' => 'UTM Norte (Y)',
        'field_msg_utm_longitude' => 'Ingrese UTM Norte (Y)',
        'field_verbatim_latitude' => 'Latitude Original',
        'field_msg_verbatim_latitude' => 'Ingrese la Latitud',
        'field_verbatim_longitude' => 'Longitude Original',
        'field_msg_verbatim_longitude' => 'Ingrese la Longitud',
        'field_departamento_id' => 'Departamento',
        'field_Holder_departamento_id' => 'Seleccione una opción',
        'field_GroupMsg_departamento_id' => 'Seleccione el departamento',
        'field_municipio_id' => 'Municipio',
        'field_Holder_municipio_id' => 'Seleccione una opción',
        'field_GroupMsg_municipio_id' => 'Seleccione el municipio',
        'field_zona' => 'Zona',
        'field_msg_zona' => 'Ingrese la zona',
        'field_hemisferio' => 'Hemisferio',
        'field_Holder_hemisferio' => 'Seleccione una opción',
        'field_GroupMsg_hemisferio' => 'Seleccione el Hemisferio',
        'field_locality' => 'Localidad',
        'field_msg_locality' => 'Ingrese la localidad',
        'field_continent' => 'Continente',
        'field_pais' => 'Pais',
      ),
    ),
  ),
  'vars' => 
  array (
  ),
));
}
}
