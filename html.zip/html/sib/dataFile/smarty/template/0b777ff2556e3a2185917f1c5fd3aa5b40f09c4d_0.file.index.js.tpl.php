<?php
/* Smarty version 4.2.1, created on 2022-11-09 17:25:45
  from '/var/www/html/sib/webapp/app/core/module/index/snippet/index/view/index.js.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_636c1ad9c9ec32_69122080',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '0b777ff2556e3a2185917f1c5fd3aa5b40f09c4d' => 
    array (
      0 => '/var/www/html/sib/webapp/app/core/module/index/snippet/index/view/index.js.tpl',
      1 => 1668028010,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_636c1ad9c9ec32_69122080 (Smarty_Internal_Template $_smarty_tpl) {
}
}
