<?php
/* Smarty version 4.2.1, created on 2023-03-08 08:33:03
  from '/var/www/html/sib/webapp/app/sib/module/zoologia_anfibios/snippet/index/view/item/index.css.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_6408807f7a5286_03625174',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '70d08f85119184a38abe4449e83b3ef4921bd44d' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/zoologia_anfibios/snippet/index/view/item/index.css.tpl',
      1 => 1678278586,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6408807f7a5286_03625174 (Smarty_Internal_Template $_smarty_tpl) {
?><link rel="stylesheet" type="text/css" href="/js/geo/leaflet.1.7.1/leaflet.css"  />
<link rel="stylesheet" type="text/css" href="/js/geo/leaflet.fullscreen/Control.FullScreen.css" />
<link rel="stylesheet" type="text/css" href="/js/geo/leaflet.groupedlayercontrol/dist/leaflet.groupedlayercontrol.min.css" />

    <style>
    </style>
<?php }
}
