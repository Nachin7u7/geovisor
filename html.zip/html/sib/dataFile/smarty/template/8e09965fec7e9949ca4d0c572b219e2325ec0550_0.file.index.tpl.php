<?php
/* Smarty version 4.2.1, created on 2022-11-10 10:58:21
  from '/var/www/html/sib/webapp/app/sib/module/geovisor/snippet/index/view/index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_636d118d654ab0_40478425',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '8e09965fec7e9949ca4d0c572b219e2325ec0550' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/geovisor/snippet/index/view/index.tpl',
      1 => 1668028010,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:index.css.tpl' => 1,
    'file:bar/op01.tpl' => 1,
  ),
),false)) {
function content_636d118d654ab0_40478425 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:index.css.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>



<div id="sidebar" class="leaflet-sidebar collapsed" style="z-index: 10 !important">
    <!-- Nav tabs -->
    <div class="leaflet-sidebar-tabs menuizq">
        <ul role="tablist">
            <li><a href="#home" role="tab"><i class="text-primary fa fa-search"></i></a></li>
            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['menu_tab']->value, 'row', false, 'idx');
$_smarty_tpl->tpl_vars['row']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['idx']->value => $_smarty_tpl->tpl_vars['row']->value) {
$_smarty_tpl->tpl_vars['row']->do_else = false;
?>
                <li><a href="#<?php echo $_smarty_tpl->tpl_vars['row']->value['id_name'];?>
" role="tab"
                       data-toggle="tabajax"
                       data-target="<?php echo $_smarty_tpl->tpl_vars['row']->value['id_name'];?>
"
                                              data-href="<?php echo $_smarty_tpl->tpl_vars['path_url']->value;?>
/<?php echo $_smarty_tpl->tpl_vars['row']->value['id_name'];?>
_/<?php echo $_smarty_tpl->tpl_vars['id']->value;?>
"
                    ><i class="text-primary <?php echo $_smarty_tpl->tpl_vars['row']->value['icon'];?>
"></i></a></li>
            <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
        </ul>

        <ul role="tablist">
            <li><a href="#settings" role="tab"><i class="fa fa-laptop-code"></i></a></li>
        </ul>
    </div>

    <!-- Tab panes -->
    <div class="leaflet-sidebar-content menuizq">
        <div class="leaflet-sidebar-pane" id="home">
            <h1 class="leaflet-sidebar-header">Filtros <span class="leaflet-sidebar-close"><i class="text-white ki ki-bold-arrow-back"></i></span></h1>
            <?php $_smarty_tpl->_subTemplateRender("file:bar/op01.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
        </div>

        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['menu_tab']->value, 'row', false, 'idx');
$_smarty_tpl->tpl_vars['row']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['idx']->value => $_smarty_tpl->tpl_vars['row']->value) {
$_smarty_tpl->tpl_vars['row']->do_else = false;
?>
            <div class="leaflet-sidebar-pane" id="<?php echo $_smarty_tpl->tpl_vars['row']->value['id_name'];?>
">
                <h1 class="leaflet-sidebar-header"><?php echo $_smarty_tpl->tpl_vars['row']->value['label'];?>
 <span class="leaflet-sidebar-close"><i class="text-white ki ki-bold-arrow-back"></i></span></h1>
                <div id="<?php echo $_smarty_tpl->tpl_vars['row']->value['id_name'];?>
_pane"></div>
            </div>
        <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>

        <div class="leaflet-sidebar-pane" id="settings">
            <h1 class="leaflet-sidebar-header">Configuración <span class="leaflet-sidebar-close"><i class="text-white ki ki-bold-arrow-back"></i></span></h1>
        </div>
    </div>
</div>
<div id="map" class=""></div>


<!-- begin::panel menú -->
<!-- end::panel menú -->


<?php }
}
