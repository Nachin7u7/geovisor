<?php
/* Smarty version 4.2.1, created on 2022-11-09 17:25:45
  from '/var/www/html/sib/webapp/app/core/module/index/snippet/index/view/index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_636c1ad9c7ff08_48133357',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '18e18d9ce08a44d13945b6d6ea2986cd7044e4e0' => 
    array (
      0 => '/var/www/html/sib/webapp/app/core/module/index/snippet/index/view/index.tpl',
      1 => 1668028010,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:index.css.tpl' => 1,
  ),
),false)) {
function content_636c1ad9c7ff08_48133357 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="row mb-7">
    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['menu_modulo_principal']->value, 'row', false, 'idx');
$_smarty_tpl->tpl_vars['row']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['idx']->value => $_smarty_tpl->tpl_vars['row']->value) {
$_smarty_tpl->tpl_vars['row']->do_else = false;
?>
        <?php if (count($_smarty_tpl->tpl_vars['row']->value['submenu']) > 0) {?>

            <div class="col-lg-6">
                <!--begin::Card-->
                <div class="card card-custom gutter-b">

                    <div class="card-body p-2" >

                        <!--begin::Top-->
                        <div class="d-flex align-items-center" >
                            <!--begin::Symbol-->
                            <div class="symbol symbol-40  mr-5" >
                                <span class="symbol-label"><i class="<?php echo $_smarty_tpl->tpl_vars['row']->value['class'];?>
 text-primary"></i></span>
                            </div>
                            <!--end::Symbol-->
                            <!--begin::Info-->
                            <div class="d-flex flex-column flex-grow-1">
                                <span class=" text-primary mb-1 font-size-lg font-weight-bolder"><?php echo $_smarty_tpl->tpl_vars['row']->value['name'];?>
</span>
                                                                                            </div>
                            <!--end::Info-->
                        </div>
                        <!--end::Top-->

                        <div class="pt-2">
                            <!--begin::Image-->
                            <div class="bgi-no-repeat bgi-size-cover rounded min-h-165px" rel="color_<?php echo $_smarty_tpl->tpl_vars['idx']->value;?>
"
                                 style="background-image: url(/app/core/template/images/home/<?php echo $_smarty_tpl->tpl_vars['row']->value['id'];?>
.jpg)"></div>
                            <!--end::Image-->
                            <!--begin::Text-->
                            <?php if ($_smarty_tpl->tpl_vars['row']->value['description'] != '') {?>
                                <p class="text-dark-75 font-size-lg font-weight-normal pt-5 mb-2">
                                    <?php echo $_smarty_tpl->tpl_vars['row']->value['description'];?>

                                </p>
                            <?php }?>
                            <!--end::Text-->
                        </div>


                        <div class="separator separator-solid mt-0 mb-2"></div>

                        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['row']->value['submenu'], 'submenu', false, 'sidx');
$_smarty_tpl->tpl_vars['submenu']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['sidx']->value => $_smarty_tpl->tpl_vars['submenu']->value) {
$_smarty_tpl->tpl_vars['submenu']->do_else = false;
?>
                            <!--begin::Item-->
                            <div class="d-flex align-items-center mb-0">
                                <!--begin::Symbol-->
                                <div class="symbol symbol-40 symbol-light-success mr-5">
                                    <span class="symbol-label"><i class="<?php echo $_smarty_tpl->tpl_vars['submenu']->value['class'];?>
 text-success"></i></span>
                                </div>
                                <!--end::Symbol-->

                                <!--begin::Text-->
                                <div class="d-flex flex-column font-weight-bold">
                                    <a class="text-dark text-hover-primary mb-1 font-size-lg"
                                            <?php if ($_smarty_tpl->tpl_vars['submenu']->value['type'] == 'app') {?>
                                                href="/<?php echo $_smarty_tpl->tpl_vars['submenu']->value['folder'];?>
"
                                            <?php } elseif ($_smarty_tpl->tpl_vars['submenu']->value['type'] == 'url') {?>
                                                href="<?php echo $_smarty_tpl->tpl_vars['submenu']->value['url'];?>
"
                                            <?php }?>
                                            <?php if ($_smarty_tpl->tpl_vars['submenu']->value['target']) {?>target="_blank"<?php }?>
                                    ><?php echo $_smarty_tpl->tpl_vars['submenu']->value['name'];?>
</a>
                                    <span class="text-muted"><?php echo $_smarty_tpl->tpl_vars['submenu']->value['description'];?>
</span>
                                </div>
                                <!--end::Text-->
                            </div>
                            <!--end::Item-->
                            <div class="separator separator-solid mt-0 mb-2"></div>
                        <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                    </div>
                </div>
                <!--end::Card-->
            </div>
        <?php }?>
    <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
</div>

<?php $_smarty_tpl->_subTemplateRender("file:index.css.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
