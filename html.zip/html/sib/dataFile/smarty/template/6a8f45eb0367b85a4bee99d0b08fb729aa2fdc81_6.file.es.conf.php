<?php /* Smarty version 4.2.1, created on 2023-09-20 09:13:39
         compiled from '/var/www/html/sib/webapp/app/sib/module/zoologia_ictiologia/snippet/datoscolecta/language/es.conf' */ ?>
<?php
/* Smarty version 4.2.1, created on 2023-09-20 09:13:39
  from '/var/www/html/sib/webapp/app/sib/module/zoologia_ictiologia/snippet/datoscolecta/language/es.conf' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_650af003981f47_61259108',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6a8f45eb0367b85a4bee99d0b08fb729aa2fdc81' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/zoologia_ictiologia/snippet/datoscolecta/language/es.conf',
      1 => 1688391178,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_650af003981f47_61259108 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigVars($_smarty_tpl, array (
  'sections' => 
  array (
    'general' => 
    array (
      'vars' => 
      array (
        'title' => 'CARACTERISTICAS DE LOS DATOS DE COLECTA',
        'message' => 'Se podrá realizar el registro los datos de colecta',
        'field_date' => 'Fecha del evento',
        'field_msg_date' => 'Ingrese la fecha del evento',
        'field_verbatimEventDate' => 'Fecha original del evento',
        'field_msg_verbatimEventDate' => 'Ingrese la fecha original del evento',
        'field_eventTime' => 'Hora del evento',
        'field_msg_eventTime' => 'Ingrese la hora del evento',
        'field_fieldNumber' => 'Número de campo',
        'field_msg_fieldNumber' => 'Ingrese el número de campo',
        'field_cupos_utilizado' => 'Cupos utilizado',
        'field_msg_cupos_utilizado' => 'Ingrese el cupo utilizado',
        'field_eventRemarks' => 'Comentarios del evento',
        'field_length_eventRemarks' => 'Tiene que ser mayor o igual a 3 caracteres',
        'field_msg_eventRemarks' => 'Ingrese los comentarios del evento',
        'field_colector_principal' => 'Colector Principal',
        'field_length_colector_principal' => 'Tiene que ser mayor o igual a 3 caracteres',
        'field_msg_colector_principal' => 'Ingrese el colector principal',
        'fieldDescription' => 'Descripción',
      ),
    ),
    'form' => 
    array (
      'vars' => 
      array (
        'title1' => 'INFORMACIÓN GENERAL DE LA TAXONOMIA BOTANICA',
      ),
    ),
  ),
  'vars' => 
  array (
  ),
));
}
}
