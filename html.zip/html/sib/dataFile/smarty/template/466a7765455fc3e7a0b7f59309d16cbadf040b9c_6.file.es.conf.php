<?php /* Smarty version 4.2.1, created on 2022-11-10 11:06:21
         compiled from '/var/www/html/sib/webapp/app/setting/language/es.conf' */ ?>
<?php
/* Smarty version 4.2.1, created on 2022-11-10 11:06:21
  from '/var/www/html/sib/webapp/app/setting/language/es.conf' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_636d136d09a9b0_28937021',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '466a7765455fc3e7a0b7f59309d16cbadf040b9c' => 
    array (
      0 => '/var/www/html/sib/webapp/app/setting/language/es.conf',
      1 => 1668028010,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_636d136d09a9b0_28937021 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigVars($_smarty_tpl, array (
  'sections' => 
  array (
  ),
  'vars' => 
  array (
    'sbmBtnHome' => 'Inicio Configuración',
    'sbmBtnMain' => 'Inicio',
    'sbmTitleMenu' => 'Configuración',
    'sbmTitle' => 'Configuración',
  ),
));
}
}
