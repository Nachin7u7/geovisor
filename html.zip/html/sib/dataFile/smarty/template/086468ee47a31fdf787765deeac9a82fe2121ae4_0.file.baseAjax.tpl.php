<?php
/* Smarty version 4.2.1, created on 2024-05-27 11:52:07
  from '/var/www/html/sib/webapp/app/core/template/base/baseAjax.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_6654ac271da375_34069948',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '086468ee47a31fdf787765deeac9a82fe2121ae4' => 
    array (
      0 => '/var/www/html/sib/webapp/app/core/template/base/baseAjax.tpl',
      1 => 1668028010,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6654ac271da375_34069948 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender(((string)$_smarty_tpl->tpl_vars['subpage']->value), $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, true);
}
}
