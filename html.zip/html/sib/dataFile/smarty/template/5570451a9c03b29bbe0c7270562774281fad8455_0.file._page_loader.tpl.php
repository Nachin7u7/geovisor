<?php
/* Smarty version 4.2.1, created on 2022-11-09 17:25:45
  from '/var/www/html/sib/webapp/app/core/template/frontend_core_72/_page_loader.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_636c1ad9becbb0_49903326',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '5570451a9c03b29bbe0c7270562774281fad8455' => 
    array (
      0 => '/var/www/html/sib/webapp/app/core/template/frontend_core_72/_page_loader.tpl',
      1 => 1668028010,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_636c1ad9becbb0_49903326 (Smarty_Internal_Template $_smarty_tpl) {
?><!--begin::Page loader-->
<div class="page-loader page-loader-base">
    <div class="blockui">
        <span>Cargando Uyuni...</span>
        <span><div class="spinner spinner-primary"></div></span>
    </div>
</div>
<!--end::Page Loader--><?php }
}
