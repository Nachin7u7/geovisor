<?php
/* Smarty version 4.2.1, created on 2023-02-03 16:45:54
  from '/var/www/html/sib/webapp/app/sib/module/botanica/snippet/lugarcolecta/view/index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_63dd7282905458_67134962',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a20274e4dbafb8f0ed5bb5065ca3717508eb0b37' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/botanica/snippet/lugarcolecta/view/index.tpl',
      1 => 1675456623,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:formprincipal/index.tpl' => 1,
  ),
),false)) {
function content_63dd7282905458_67134962 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:formprincipal/index.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
