<?php /* Smarty version 4.2.1, created on 2022-11-09 17:25:07
         compiled from '/var/www/html/sib/webapp/app/web/module/geovisor/snippet/index/language/es.conf' */ ?>
<?php
/* Smarty version 4.2.1, created on 2022-11-09 17:25:07
  from '/var/www/html/sib/webapp/app/web/module/geovisor/snippet/index/language/es.conf' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_636c1ab3135c43_91493937',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '58def1613fdc6aca9da8879fda37d2118e003b68' => 
    array (
      0 => '/var/www/html/sib/webapp/app/web/module/geovisor/snippet/index/language/es.conf',
      1 => 1668028010,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_636c1ab3135c43_91493937 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigVars($_smarty_tpl, array (
  'sections' => 
  array (
    'index' => 
    array (
      'vars' => 
      array (
        'title' => 'Empresas distribuidoras',
        'btnNew' => 'Nueva empresa',
        'filter' => 'Nombre',
        'filterCiae' => 'Buscar por CIAE',
        'filterCompanyName' => 'Buscar por nombre de la empresa',
        'dataTableExportTitle' => 'Lista de Aplicaciones',
      ),
    ),
    'tableIndex' => 
    array (
      'vars' => 
      array (
        'table_ciae' => 'CIAE',
        'table_name_company' => 'Nombre de la Empresa',
        'table_sigla' => 'Sigla',
        'table_license' => 'Licencia',
        'table_activity' => 'Actividad',
        'table_status' => 'Estado',
      ),
    ),
    'item' => 
    array (
      'vars' => 
      array (
        'fieldActive' => 'Activo',
        'title' => 'Gestión de Empresas Distribuidoras',
      ),
    ),
    'tabItem' => 
    array (
      'vars' => 
      array (
        'tabGeneral' => 'General',
        'tabGroups' => 'Grupos',
        'tabModules' => 'Módulos',
      ),
    ),
  ),
  'vars' => 
  array (
  ),
));
}
}
