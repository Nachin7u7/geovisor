<?php
/* Smarty version 4.2.1, created on 2023-06-29 09:30:34
  from '/var/www/html/sib/webapp/app/sib/template/frontend/menu_aside.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_649d877ae99893_92805261',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '3095164c81d4f7e849306d1a4e1dd972203c5201' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/template/frontend/menu_aside.tpl',
      1 => 1668028010,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_649d877ae99893_92805261 (Smarty_Internal_Template $_smarty_tpl) {
?><div id="kt_aside_menu" class="aside-menu my-4" data-menu-vertical="1" data-menu-scroll="1" data-menu-dropdown-timeout="500">
    <!--begin::Menu Nav-->
    <ul class="menu-nav">

                <li class="menu-item menu-item-active" aria-haspopup="true">
            <a href="/<?php echo $_smarty_tpl->tpl_vars['app']->value;?>
" class="menu-link">
                <span class="menu-icon "><i class="fa fa-home text-primary"></i></span>
                <span class="menu-text"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'sbmBtnHome');?>
</span>
            </a>
        </li>

        <li class="menu-section" style="border-bottom: 1px solid #387ec9; margin: 0px;">
            <h4 class="menu-text"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'sbmTitleMenu');?>
</h4>
            <i class="menu-icon ki ki-bold-more-hor icon-md"></i>
        </li>

        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['menu_modulo_principal']->value, 'row', false, 'idx');
$_smarty_tpl->tpl_vars['row']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['idx']->value => $_smarty_tpl->tpl_vars['row']->value) {
$_smarty_tpl->tpl_vars['row']->do_else = false;
?>

            <li class="menu-item menu-item-submenu <?php if ($_smarty_tpl->tpl_vars['miga']->value['appGroupData']['id'] == $_smarty_tpl->tpl_vars['row']->value['id']) {?>menu-item-open menu-item-here<?php }?>" aria-haspopup="true" data-menu-toggle="hover">
                <a href="javascript:;" class="menu-link menu-toggle">
                    <i class="menu-icon <?php echo $_smarty_tpl->tpl_vars['row']->value['class'];?>
"></i>
                    <span class="menu-text"><?php echo $_smarty_tpl->tpl_vars['row']->value['name'];?>
</span>
                    <i class="menu-arrow"></i>
                </a>

                <div class="menu-submenu">
                    <i class="menu-arrow"></i>
                    <ul class="menu-subnav">
                        <li class="menu-item menu-item-parent" aria-haspopup="true">
                            <span class="menu-link"><span class="menu-text"><?php echo $_smarty_tpl->tpl_vars['row']->value['name'];?>
</span></span>
                        </li>
                        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['row']->value['submenu'], 'submenu', false, 'sidx');
$_smarty_tpl->tpl_vars['submenu']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['sidx']->value => $_smarty_tpl->tpl_vars['submenu']->value) {
$_smarty_tpl->tpl_vars['submenu']->do_else = false;
?>
                            <li class="menu-item <?php if ($_smarty_tpl->tpl_vars['miga']->value['appModuleData']['folder'] == $_smarty_tpl->tpl_vars['submenu']->value['folder']) {?>menu-item-active<?php }?>" aria-haspopup="true">
                                <a class="menu-link"
                                        <?php if ($_smarty_tpl->tpl_vars['submenu']->value['type'] == 'module') {?>
                                            href="/<?php echo $_smarty_tpl->tpl_vars['app']->value;?>
/<?php echo $_smarty_tpl->tpl_vars['submenu']->value['folder'];?>
"
                                            <?php if ($_smarty_tpl->tpl_vars['submenu']->value['target']) {?>target="_blank"<?php }?>
                                        <?php } elseif ($_smarty_tpl->tpl_vars['submenu']->value['type'] == 'url') {?>
                                            href="<?php echo $_smarty_tpl->tpl_vars['submenu']->value['url'];?>
"
                                            <?php if ($_smarty_tpl->tpl_vars['submenu']->value['target']) {?>target="_blank"<?php }?>
                                        <?php }?>
                                >
                                    <i class="menu-bullet menu-bullet-dot">
                                        <span></span>
                                    </i>
                                    <span class="menu-text"><?php echo $_smarty_tpl->tpl_vars['submenu']->value['name'];?>
</span>
                                </a>
                            </li>
                        <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                    </ul>
                </div>
            </li>
        <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
    </ul>
    <!--end::Menu Nav-->
</div><?php }
}
