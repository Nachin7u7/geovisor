<?php
/* Smarty version 4.2.1, created on 2022-11-09 17:48:35
  from '/var/www/html/sib/webapp/app/sib/module/user/snippet/index/view/item/index.css.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_636c2033eb7ce3_89399961',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6d6781c70f0c8644ff9c38466ca7f58cb70f3674' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/user/snippet/index/view/item/index.css.tpl',
      1 => 1668028010,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_636c2033eb7ce3_89399961 (Smarty_Internal_Template $_smarty_tpl) {
?>
    <style>
    </style>
<?php }
}
