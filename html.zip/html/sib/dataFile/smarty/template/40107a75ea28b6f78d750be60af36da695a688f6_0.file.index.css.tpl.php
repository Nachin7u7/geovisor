<?php
/* Smarty version 4.2.1, created on 2023-11-06 08:28:22
  from '/var/www/html/sib/webapp/app/sib/module/taxonomia_p_invertebrado/snippet/index/view/index.css.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_6548dbe6c57801_60888586',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '40107a75ea28b6f78d750be60af36da695a688f6' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/taxonomia_p_invertebrado/snippet/index/view/index.css.tpl',
      1 => 1694087965,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6548dbe6c57801_60888586 (Smarty_Internal_Template $_smarty_tpl) {
?>
    <style>
        .dtrg-level-0 td{
            /* background: #e7f2fe!important;
             border-top: 4px solid #9bbbde;*/
            background: #fafbfc !important;
            border-top: 2px solid #c0d8e6;
            padding: 5px 5px 5px 5px !important;

        }
        .dtrg-level-0 td::before {
            font-family: "Font Awesome 5 Free";
            font-weight: 900;
            content: "\f107";
            margin-right: 5px;
        }

        .dtrg-level-1 td{
            background: #f2f8ff !important;
            padding: 5px 5px 5px 10px !important;
            color: #3699ff !important;
        }
        .dtrg-level-1 td::before {
            font-family: "Font Awesome 5 Free";
            font-weight: 900;
            content: "\f107";
            margin-right: 5px;
        }
    </style>
<?php }
}
