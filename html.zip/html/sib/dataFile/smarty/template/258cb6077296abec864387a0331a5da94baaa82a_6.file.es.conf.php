<?php /* Smarty version 4.2.1, created on 2022-11-09 17:25:06
         compiled from '/var/www/html/sib/webapp/language/es.conf' */ ?>
<?php
/* Smarty version 4.2.1, created on 2022-11-09 17:25:06
  from '/var/www/html/sib/webapp/language/es.conf' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_636c1ab2907b70_17613630',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '258cb6077296abec864387a0331a5da94baaa82a' => 
    array (
      0 => '/var/www/html/sib/webapp/language/es.conf',
      1 => 1668028010,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_636c1ab2907b70_17613630 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigVars($_smarty_tpl, array (
  'sections' => 
  array (
  ),
  'vars' => 
  array (
    'glFieldRequired' => 'Campo requerido',
    'glBtnSaveChanges' => 'Guardar Cambios',
    'glBtnBackToList' => 'Volver a la lista',
    'glBtnCancel' => 'Cancelar',
    'glBtnCloce' => 'Cerrar',
    'glBtnSave' => 'Guardar',
    'glBtnBack' => 'Volver',
    'glOptActive' => 'Activo',
    'glOptInactive' => 'Inactivo',
    'gltableAction' => 'Acción',
    'glnew' => 'Nuevo',
    'glupdate' => 'Editar',
    'gl_search_file' => 'Buscar Archivo',
    'gl_home' => 'Inicio',
    'gl_table_created_at' => 'Sistema - Fecha creación',
    'gl_table_updated_at' => 'Sistema - Fecha Actualización',
  ),
));
}
}
