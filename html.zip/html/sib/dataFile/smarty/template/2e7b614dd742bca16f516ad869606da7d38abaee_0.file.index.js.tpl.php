<?php
/* Smarty version 4.2.1, created on 2023-04-13 16:37:17
  from '/var/www/html/sib/webapp/app/sib/module/zoologia_reptiles/snippet/index/view/item/index.js.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_643867fd772ac9_33645988',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '2e7b614dd742bca16f516ad869606da7d38abaee' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/zoologia_reptiles/snippet/index/view/item/index.js.tpl',
      1 => 1678278586,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_643867fd772ac9_33645988 (Smarty_Internal_Template $_smarty_tpl) {
echo '<script'; ?>
>
    var snippet_tab_item = function () {
        "use strict";
        var handler_tab_build = function(){
            coreUyuni.setTabs();
        };
        return {
            init: function() {
                handler_tab_build();
            }
        };
    }();

    jQuery(document).ready(function() {
        $('#btn_back').removeClass('d-none');
        snippet_tab_item.init();
        $('#<?php echo $_smarty_tpl->tpl_vars['menu_tab_active']->value;?>
_tab').trigger('click');
    });
<?php echo '</script'; ?>
>


<?php echo '<script'; ?>
 src="https://maps.googleapis.com/maps/api/js?key=<?php echo $_smarty_tpl->tpl_vars['google_map_key']->value;?>
"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="/js/geo/leaflet.1.7.1/leaflet.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="/js/geo/leaflet.fullscreen/Control.FullScreen.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="/js/geo/Leaflet.GoogleMutant.js"><?php echo '</script'; ?>
>

<?php echo '<script'; ?>
 src="/js/geo/leaflet.ajax/dist/leaflet.ajax.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="/js/geo/leaflet.ajax/example/spin.js"><?php echo '</script'; ?>
>

<?php echo '<script'; ?>
 src="/js/geo/leaflet.groupedlayercontrol/dist/leaflet.groupedlayercontrol.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="/js/geo/leaflet.wms/dist/leaflet.wms.js"><?php echo '</script'; ?>
>


<?php }
}
