<?php
/* Smarty version 4.2.1, created on 2023-03-01 11:10:36
  from '/var/www/html/sib/webapp/app/sib/module/zoologia_ictiologia/snippet/index/view/index.css.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_63ff6aeca3ed96_00332129',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '0498cd6abb50030a6b6229ac616d0533145e6b10' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/zoologia_ictiologia/snippet/index/view/index.css.tpl',
      1 => 1677671930,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_63ff6aeca3ed96_00332129 (Smarty_Internal_Template $_smarty_tpl) {
?>
    <style>
        .dtrg-level-0 td{
            /* background: #e7f2fe!important;
             border-top: 4px solid #9bbbde;*/
            background: #fafbfc !important;
            border-top: 2px solid #c0d8e6;
            padding: 5px 5px 5px 5px !important;

        }
        .dtrg-level-0 td::before {
            font-family: "Font Awesome 5 Free";
            font-weight: 900;
            content: "\f107";
            margin-right: 5px;
        }

        .dtrg-level-1 td{
            background: #f2f8ff !important;
            padding: 5px 5px 5px 10px !important;
            color: #3699ff !important;
        }
        .dtrg-level-1 td::before {
            font-family: "Font Awesome 5 Free";
            font-weight: 900;
            content: "\f107";
            margin-right: 5px;
        }
    </style>
<?php }
}
