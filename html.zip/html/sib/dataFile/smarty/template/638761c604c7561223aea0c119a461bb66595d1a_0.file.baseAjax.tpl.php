<?php
/* Smarty version 4.2.1, created on 2023-07-03 09:34:39
  from '/var/www/html/sib/webapp/app/core/template/base/baseAjax.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_64a2ce6f3d2351_78567426',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '638761c604c7561223aea0c119a461bb66595d1a' => 
    array (
      0 => '/var/www/html/sib/webapp/app/core/template/base/baseAjax.tpl',
      1 => 1668028010,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_64a2ce6f3d2351_78567426 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender(((string)$_smarty_tpl->tpl_vars['subpage']->value), $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, true);
}
}
