<?php
/* Smarty version 4.2.1, created on 2023-06-29 09:30:16
  from '/var/www/html/sib/webapp/app/sib/module/taxonomia_invertebrados/snippet/general/view/index.css.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_649d87685d09e1_92150931',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '5343b8fedc63438b8fef9e54469d5d344344c6e3' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/taxonomia_invertebrados/snippet/general/view/index.css.tpl',
      1 => 1686678877,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_649d87685d09e1_92150931 (Smarty_Internal_Template $_smarty_tpl) {
?>
    <style>
        .select2-results__group{
            background: #e7f1f6;
            border-bottom: 2px solid #006ba2;
        }

    </style>
<?php }
}
