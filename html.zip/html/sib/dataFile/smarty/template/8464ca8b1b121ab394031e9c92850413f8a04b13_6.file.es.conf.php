<?php /* Smarty version 4.2.1, created on 2022-11-10 08:41:18
         compiled from '/var/www/html/sib/webapp/app/web/module/singin/snippet/index/language/es.conf' */ ?>
<?php
/* Smarty version 4.2.1, created on 2022-11-10 08:41:18
  from '/var/www/html/sib/webapp/app/web/module/singin/snippet/index/language/es.conf' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_636cf16ebf2782_71696825',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '8464ca8b1b121ab394031e9c92850413f8a04b13' => 
    array (
      0 => '/var/www/html/sib/webapp/app/web/module/singin/snippet/index/language/es.conf',
      1 => 1668084031,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_636cf16ebf2782_71696825 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigVars($_smarty_tpl, array (
  'sections' => 
  array (
    'index' => 
    array (
      'vars' => 
      array (
        'title' => 'Gestión de Hojas de ruta',
        'title_filter' => 'Filtro',
        'btnNew' => 'Nueva Hoja de Ruta',
        'filterName' => 'Buscar por nombre de la hoja de ruta',
        'filterHolderName' => 'Escribir el nombre',
        'filterorma' => 'Buscar por norma',
        'filterNormaSelectAll' => 'Todas las normas',
        'filterStatus' => 'Estado',
        'filterStatusSelectAll' => 'Todos los estados',
        'dataTableExportTitle' => 'Lista de Hojas de Ruta',
      ),
    ),
    'tableIndex' => 
    array (
      'vars' => 
      array (
        'table_procedencia' => 'Procedencia',
        'table_destinatario' => 'Destinatario',
        'table_asunto' => 'Asunto',
        'table_fojas' => 'Fojas',
        'table_fecha' => 'Fecha',
        'table_tipo_correspondenica' => 'Tipo Correspondencia',
      ),
    ),
    'item' => 
    array (
      'vars' => 
      array (
        'title' => 'Gestión de Hojas de ruta',
      ),
    ),
    'tabItem' => 
    array (
      'vars' => 
      array (
        'tabGeneral' => 'Hoja de Ruta',
        'tab_adjunto' => 'Documentos Adjuntos',
        'tab_destinatario' => 'Destinatario',
        'tab_enmienda' => 'Enmiendas',
      ),
    ),
  ),
  'vars' => 
  array (
  ),
));
}
}
