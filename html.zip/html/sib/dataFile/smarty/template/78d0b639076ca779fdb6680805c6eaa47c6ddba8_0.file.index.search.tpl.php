<?php
/* Smarty version 4.2.1, created on 2022-11-09 17:48:29
  from '/var/www/html/sib/webapp/app/sib/module/user/snippet/index/view/index.search.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_636c202df03b82_36149678',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '78d0b639076ca779fdb6680805c6eaa47c6ddba8' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/user/snippet/index/view/index.search.tpl',
      1 => 1668028010,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_636c202df03b82_36149678 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_checkPlugins(array(0=>array('file'=>'/var/www/html/sib/vendor/smarty/smarty/libs/plugins/function.html_options.php','function'=>'smarty_function_html_options',),));
?>
<div class="row">
    <div class="col-lg-12 alert-text">
        <label class="text-dark-25"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'filterName');?>
:</label>
        <input type="text" class="filtro-buscar-text form-control" placeholder="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'filterName');?>
" data-col-index="0">
    </div>
    <div class="col-lg-12 alert-text">
        <label class="text-dark-25"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'filterLastName');?>
:</label>
        <input type="text" class="filtro-buscar-text form-control" placeholder="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'filterLastName');?>
" data-col-index="1">
    </div>


    <div class="col-lg-12 alert-text">
        <label class="text-dark-25"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'filter_type');?>
:</label>
        <select class="form-control select2_filter1 filter_select" id="filter_type">
            <option value="no"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'filter_all_type');?>
</option>
            <?php echo smarty_function_html_options(array('options'=>$_smarty_tpl->tpl_vars['cataobj']->value['tipo']),$_smarty_tpl);?>

        </select>
    </div>

</div>

<?php }
}
