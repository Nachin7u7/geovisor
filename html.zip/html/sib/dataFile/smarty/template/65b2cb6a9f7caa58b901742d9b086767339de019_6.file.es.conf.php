<?php /* Smarty version 4.2.1, created on 2023-04-13 16:37:09
         compiled from '/var/www/html/sib/webapp/app/sib/module/zoologia_reptiles/snippet/index/language/es.conf' */ ?>
<?php
/* Smarty version 4.2.1, created on 2023-04-13 16:37:09
  from '/var/www/html/sib/webapp/app/sib/module/zoologia_reptiles/snippet/index/language/es.conf' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_643867f5b4ae73_57346757',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '65b2cb6a9f7caa58b901742d9b086767339de019' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/zoologia_reptiles/snippet/index/language/es.conf',
      1 => 1678278586,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_643867f5b4ae73_57346757 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigVars($_smarty_tpl, array (
  'sections' => 
  array (
    'index' => 
    array (
      'vars' => 
      array (
        'title' => 'Gestión del espécimen',
        'title_filter' => 'Filtro',
        'btnNew' => 'Nuevo Espécimen',
        'filterName' => 'Buscar por nombre de la',
        'filterHolderName' => 'Escribir el nombre institución',
        'filterorma' => 'Buscar por norma',
        'filterNormaSelectAll' => 'Todas las normas',
        'filterStatus' => 'Estado',
        'filterStatusSelectAll' => 'Todos los estados',
        'dataTableExportTitle' => 'Lista de Espécimenes',
      ),
    ),
    'tableIndex' => 
    array (
      'vars' => 
      array (
        'table_basis_of_record' => 'Base del registro',
        'table_type' => 'Tipo',
        'table_collection_code' => 'Código de la colección',
        'table_catalog_number' => 'Número de catálogo CBF',
        'table_rights_holder' => 'Titular de los derechos',
        'table_access_rights' => 'Derechos de acceso',
        'table_recorded_by' => 'Registrado por',
        'table_class' => 'Clase',
        'table_order' => 'Orden',
        'table_family' => 'familia',
        'table_genus' => 'Género el momento de la identificación',
        'table_sex' => 'Sexo',
        'table_occurrence_status' => 'Estado de muestra',
      ),
    ),
    'item' => 
    array (
      'vars' => 
      array (
        'title' => 'Gestión de Instituciones Cientificas Autorizadas',
      ),
    ),
    'tabItem' => 
    array (
      'vars' => 
      array (
        'tabGeneral' => 'Datos de los especimenes',
        'tab_especimenes' => 'Especimenes',
        'tab_datoscolecta' => 'Datos Colecta',
        'tab_lugarcolecta' => 'Lugar Colecta',
        'tab_colectorsecundario' => 'Colectores Secundarios',
        'tab_preparador' => 'Preparador',
        'tab_taxonomia' => 'Taxonomía',
        'tab_foto' => 'Fotografias',
      ),
    ),
  ),
  'vars' => 
  array (
  ),
));
}
}
