<?php
/* Smarty version 4.2.1, created on 2022-11-10 08:41:50
  from '/var/www/html/sib/webapp/app/web/module/singin/snippet/index/view/email/email_verifica.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_636cf18ecfcb12_11718538',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '35176b92eb492934cb3e1a5702e620be1506b8ab' => 
    array (
      0 => '/var/www/html/sib/webapp/app/web/module/singin/snippet/index/view/email/email_verifica.tpl',
      1 => 1668084031,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_636cf18ecfcb12_11718538 (Smarty_Internal_Template $_smarty_tpl) {
?><div
style="
font-size: 13px;
margin-bottom: 19px;
width: 100%;
text-align: center;
font-family:'Roboto', Tahoma, Verdana, Segoe, sans-serif;
"

>
    <div style="margin-right: 40px; margin-left: 40px; margin-top: 10px;">

    <h2 style="margin: 0px;">Verificaci&oacute;n de correo electr&oacute;nico</h2>
    <br>
        Realizaste la solicitud para la creaci&oacute;n de usuario dentro del sistema SIB-MNHN.
<br><br>
        Para poder activar tu cuenta, haz click en el siguiente boton.
        <br><br>
        <a href="<?php echo $_smarty_tpl->tpl_vars['url_dominio']->value;?>
/web/singin/verifica/?c=<?php echo $_smarty_tpl->tpl_vars['check_code']->value;?>
&e=<?php echo $_smarty_tpl->tpl_vars['email_user']->value;?>
" style="-webkit-text-size-adjust: none; text-decoration: none; display: inline-block;
color: #ffffff; background-color: #53ba3e; border-radius: 50px; -webkit-border-radius: 50px;
-moz-border-radius: 50px; width: auto; width: auto; border-top: 1px solid #53ba3e; border-right:
1px solid #53ba3e; border-bottom: 1px solid #53ba3e; border-left: 1px solid #53ba3e; padding-top:
 5px; padding-bottom: 5px; font-family: Open Sans, Helvetica Neue, Helvetica, Arial, sans-serif;
 text-align: center; mso-border-alt: none; word-break: keep-all;"
           target="_blank"><span style="padding-left:50px;padding-right:50px;font-size:16px;
 display:inline-block;"><span style="font-size: 16px; line-height: 2; word-break: break-word;
 mso-line-height-alt: 32px;"><strong>Activar</strong></span></span></a>

    </div>
</div><?php }
}
