<?php
/* Smarty version 4.2.1, created on 2023-03-29 17:24:59
  from '/var/www/html/sib/webapp/app/sib/module/taxonomia_botanica/snippet/general/view/addorder/form.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_6424acab815a14_79036423',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '67fa0ca1d8455c8d55b458ea0fc93ff509ffaf90' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/taxonomia_botanica/snippet/general/view/addorder/form.tpl',
      1 => 1680015874,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:addorder/form.css.tpl' => 1,
    'file:addorder/form.js.tpl' => 1,
  ),
),false)) {
function content_6424acab815a14_79036423 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:addorder/form.css.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
<form method="POST"
      action="<?php echo $_smarty_tpl->tpl_vars['path_url']->value;?>
/<?php echo $_smarty_tpl->tpl_vars['subcontrol']->value;?>
_//saveaddorder/"
      id="form_<?php echo $_smarty_tpl->tpl_vars['subcontrol']->value;?>
_peque">

    <div class="modal-body p-2">
        <div class="alert alert-success" role="alert">
            <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glnew');?>
 <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'title');?>

        </div>

        <div class="form-group row mb-0">
            <div class="col-lg-12">
                <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_nombre');?>
   <span class="text-danger bold">*</span>:</label>
                <input type="text" class="form-control"
                       name="item[nombre]"
                       value="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['item']->value['nombre'], ENT_QUOTES, 'UTF-8', true);?>
"
                       required <?php echo $_smarty_tpl->tpl_vars['privFace']->value['input'];?>

                       data-fv-not-empty___message="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glFieldRequired');?>
"
                >
                <span class="form-text text-black-50"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_msg_nombre');?>
</span>
            </div>


        </div>
    </div>

    <div class="modal-footer p-2">
        <?php if ($_smarty_tpl->tpl_vars['privFace']->value['edit'] == 1) {?>
            <button type="button" class="btn btn-success font-weight-bold" id="form_submit_<?php echo $_smarty_tpl->tpl_vars['subcontrol']->value;?>
_peque">
                <i class="la la-save"></i><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glBtnSave');?>
</button>
        <?php }?>
        <button type="button" class="btn btn-light-success" id="form_close_<?php echo $_smarty_tpl->tpl_vars['subcontrol']->value;?>
_peque" data-dismiss="modal">
            <i class="la la-angle-double-left"></i><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glBtnCloce');?>
</button>
    </div>
</form>

<?php $_smarty_tpl->_subTemplateRender("file:addorder/form.js.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
