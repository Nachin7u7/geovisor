<?php
/* Smarty version 4.2.1, created on 2023-01-10 11:32:32
  from '/var/www/html/sib/webapp/app/setting/module/app/snippet/module/view/index.css.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_63bd8510ea35b6_73356375',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '80867cc7063485d1fe73d407f801defedef4d4e5' => 
    array (
      0 => '/var/www/html/sib/webapp/app/setting/module/app/snippet/module/view/index.css.tpl',
      1 => 1668028010,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_63bd8510ea35b6_73356375 (Smarty_Internal_Template $_smarty_tpl) {
?>
<style>
    .dtrg-start td{
       /* background: #e7f2fe!important;
        border-top: 4px solid #9bbbde;*/
        background: #f2f8ff !important;
        border-top: 4px solid #c0d8e6;
    }
</style>
<?php }
}
