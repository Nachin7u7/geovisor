<?php
/* Smarty version 4.2.1, created on 2022-11-11 01:39:58
  from '/var/www/html/sib/webapp/app/sib/module/botanica/snippet/foto/view/index.js.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_636de02e694ad7_29212384',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '564ddbd29773afee4569385b82621f3aa09167a2' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/botanica/snippet/foto/view/index.js.tpl',
      1 => 1668144867,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_636de02e694ad7_29212384 (Smarty_Internal_Template $_smarty_tpl) {
echo '<script'; ?>
>
    var table_list;
    var snippet_list = function() {
        "use strict";
        var urlsys = '<?php echo $_smarty_tpl->tpl_vars['path_url']->value;?>
/<?php echo $_smarty_tpl->tpl_vars['subcontrol']->value;?>
_/<?php echo $_smarty_tpl->tpl_vars['id']->value;?>
';
        var initTable = function() {
            let table_list_var = $('#tabla_<?php echo $_smarty_tpl->tpl_vars['subcontrol']->value;?>
');
            let export_title = "<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'dataTableExportTitle');?>
";
            let noExport = tableSetting.noExport;
            table_list = table_list_var.DataTable({
                initComplete: function(settings, json) {
                    table_list_var.removeClass('d-none');
                },
                keys: {
                    columns: noExport,
                    clipboard: false,
                },
                //dom: tableSetting.dom,
                dom:
                    `<'row'<'col-sm-12 col-md-12 dataTables_pager'lp>>
                <'row'<'col-sm-12'tr>>
                <'row'<'col-sm-12 col-md-5'i>>`,
                buttons: [
                    {extend:'colvis',text:lngUyuni.dataTableWatch
                        ,columnText: function ( dt, idx, title ) {
                            return (idx+1)+': '+title;
                        }
                    },
                    {extend:'excelHtml5'
                        ,exportOptions: {columns: noExport}
                        , title: export_title
                    },
                    {extend:'pdfHtml5'
                        ,exportOptions: {columns: noExport}
                        , title: export_title
                        , download: 'open'

                        , pageSize: 'LETTER'
                        ,customize: function(doc) {
                            doc.styles.tableHeader.fontSize = 7;
                            doc.defaultStyle.fontSize = 7;
                            doc.pageMargins= [ 20, 20];
                        }
                    },
                    {extend:'print'
                        ,exportOptions: {columns: noExport}
                        ,text: lngUyuni.dataTablePrint
                    }

                ],
                colReorder: true,
                responsive: true,
                language: {"url": "/language/js/datatable."+lng+".json"},
                lengthMenu: [[10, 25, 50,-1], [10, 25, 50, lngUyuni.dataTableAll]],
                pageLength: 25,
                order: [[ 0, "asc" ]], // Por que campo ordenara al momento de desplegar
                InfoFiltered: false,
                searchDelay: 500,
                processing: true,
                serverSide: true,
                ajax: {
                    url: urlsys+'/list',
                    type: 'POST',
                    data: {},
                },
                columns: [
                    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['gridItem']->value, 'row', false, 'idx');
$_smarty_tpl->tpl_vars['row']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['idx']->value => $_smarty_tpl->tpl_vars['row']->value) {
$_smarty_tpl->tpl_vars['row']->do_else = false;
?>
                    <?php if ($_smarty_tpl->tpl_vars['idx']->value != 0) {?>,<?php }?>{data: '<?php if ($_smarty_tpl->tpl_vars['row']->value['as']) {
echo $_smarty_tpl->tpl_vars['row']->value['as'];
} else {
echo $_smarty_tpl->tpl_vars['row']->value['field'];
}?>'<?php if ($_smarty_tpl->tpl_vars['row']->value['responsive']) {?>, responsivePriority: -1<?php }?>}
                    <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                ],
                columnDefs: [
                    {
                        targets: -1,
                        width: "90px",
                        className: 'noExport',
                        orderable: false,
                        searchable: false,
                        render: function(data, type, full, meta) {
                            var boton = '<div class="btn-group btn-group-sm " role="group" aria-label="Accion">';
                            var lbEdit = <?php if ($_smarty_tpl->tpl_vars['privFace']->value['edit'] == 1) {?>lngUyuni.btnEdit<?php } else { ?>lngUyuni.btnViewData<?php }?>;
                            boton += '<a href="javascript:snippet_list.update(\''+data+'\');" class="btn btn-success btn-sm" title="'+lbEdit+'">'+lbEdit+'</a>';
                            <?php if ($_smarty_tpl->tpl_vars['privFace']->value['edit'] == 1 && $_smarty_tpl->tpl_vars['privFace']->value['delete'] == 1) {?>
                            boton += '<a href="javascript:snippet_list.delete(\''+data+'\');" class="btn btn-icon btn-light-danger btn-sm" title="'+lngUyuni.btnDelete+'"><i class="flaticon-delete-1"></i></a>';
                            <?php }?>
                            boton += '<div>';
                            return boton;
                        },
                    },

                    {
                        targets: [0],
                        render: function(data,type,full,meta){
                            return '<span class="text-primary">' + data+ '</span>';
                        },
                    },

                    /*
                    {
                        targets: [0],
                        searchable: false,
                    },
                    {
                        targets: [2],
                        render: function(data,type,full,meta){
                            return '<span style="color: #7708bd;">' + new Intl.NumberFormat('en-US',{ minimumFractionDigits: 0 }).format(data) + ' </span>';
                        },
                    },

                    {
                        targets: [1],
                        render: function(data,type,full,meta){
                            return '<span style="color: #27780f;">' + new Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format(data) + ' </span>';
                        },
                    },

                     */

                    {
                        targets: [2],
                        className:"text-right",
                    },

                    {
                        targets: [1],
                        render: function(data,type,full,meta){
                            let download = "";
                            let urlimg = urlsys+"/"+full.actions+"/view?r="+Math.floor(Math.random() * 100);
                            if(data) {
                                download = '<div class="d-flex align-items-center">'+
                                            '<div class="symbol symbol-50 flex-shrink-0"><img src="'+urlimg+'" title="'+data+'"></div>'+
                                            '<div class="ml-3">'+
                                                '<a href="javascript:snippet_list.download(\''+full.actions+'\');" title="Descargar:'+data+'" ' +
                                                'class="btn btn-icon btn-circle btn-s btn-light-success">' +
                                                '<i class="fas fa-cloud-download-alt"></i></a>'
                                            '</div>'+
                                            '</div>';
                            }
                            return download;
                        },
                    },

                    {
                        targets: [2],
                        render: function(data,type,full,meta){
                            //return '<span style="color: #7708bd;">' + new Intl.NumberFormat('en-US',{ minimumFractionDigits: 0 }).format(data) + ' </span>';
                            var size_file = "";
                            if(data) {
                                var size = parseInt(data);
                                size =  (size / (1024*1024)).toFixed(2);
                                size_file = '<span style="color: #517e03;" class="font-size-xs">' + size+' Mb.</span>';
                            }
                            return size_file;
                        },
                    },

                    {
                        targets: [-2,-3],
                        searchable: false,
                    },
                    {
                        targets: [-2,-3],
                        className: "none"
                    },
                    {
                        targets: [-2,-3],
                        render: function(data,type,full,meta){
                            if (data == null){ data = "";}
                            return '<span class="text-primary font-size-xs">' + data+ '</span>';
                        },
                    },


                ],
            });

        };
        /**
         * Download File
         */
        function download(id){
            var url = urlsys+"/"+id+"/download";
            window.open(url, '_blank');
        }

        /**
         * New and Update
         */
        var btn_update = $('#btn_form_<?php echo $_smarty_tpl->tpl_vars['subcontrol']->value;?>
');
        var handle_button_update = function(){
            btn_update.click(function(e){
                e.preventDefault();
                item_update("","new");
            });
        };

        var item_update = function(id,type){
            var subcontrol = "<?php echo $_smarty_tpl->tpl_vars['subcontrol']->value;?>
";
            coreUyuni.itemUpdateTabs(id,type,urlsys,subcontrol);
        };
        /**
         * Delete
         */
        var  item_delete = function(id){
            var url = urlsys+"/"+id+"/delete";
            coreUyuni.itemDelete(id,url,table_list);
        };
        /**
         * Inicializar componentes
         */
        var handle_components = function(){
            coreUyuni.setComponents();
        };
        /**
         * Filtros
         */
        var handle_filtro = function () {
            coreUyuni.tableFilter();
        };

        return {
            //main function to initiate the module
            init: function() {
                handle_button_update();
                initTable();
                handle_components();
                handle_filtro();
            },
            update: function(id,type){
                item_update(id,"update");
            },
            delete: function(id){
                item_delete(id);
            },
            download: function (id) {
                download(id);
            },
        };
    }();

    jQuery(document).ready(function() {
        snippet_list.init();
    });
<?php echo '</script'; ?>
>


<?php }
}
