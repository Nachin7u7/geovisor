<?php
/* Smarty version 4.2.1, created on 2022-11-11 01:39:43
  from '/var/www/html/sib/webapp/app/sib/module/botanica/snippet/index/view/item/index.css.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_636de01fda1aa4_16828747',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '2045a21f3ac84976024532c06e9b3c6def0d56ab' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/botanica/snippet/index/view/item/index.css.tpl',
      1 => 1668144867,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_636de01fda1aa4_16828747 (Smarty_Internal_Template $_smarty_tpl) {
?><link rel="stylesheet" type="text/css" href="/js/geo/leaflet.1.7.1/leaflet.css"  />
<link rel="stylesheet" type="text/css" href="/js/geo/leaflet.fullscreen/Control.FullScreen.css" />
<link rel="stylesheet" type="text/css" href="/js/geo/leaflet.groupedlayercontrol/dist/leaflet.groupedlayercontrol.min.css" />

    <style>
    </style>
<?php }
}
