<?php
/* Smarty version 4.2.1, created on 2023-04-13 16:37:38
  from '/var/www/html/sib/webapp/app/sib/module/zoologia_reptiles/snippet/lugarcolecta/view/index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_64386812114a67_13850949',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '7d240f6a50137c69051afa242b31997c0ed44325' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/zoologia_reptiles/snippet/lugarcolecta/view/index.tpl',
      1 => 1678278586,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:formprincipal/index.tpl' => 1,
  ),
),false)) {
function content_64386812114a67_13850949 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:formprincipal/index.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
