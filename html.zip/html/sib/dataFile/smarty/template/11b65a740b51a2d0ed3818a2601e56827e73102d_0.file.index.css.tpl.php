<?php
/* Smarty version 4.2.1, created on 2023-06-29 09:30:15
  from '/var/www/html/sib/webapp/app/sib/module/taxonomia_invertebrados/snippet/index/view/item/index.css.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_649d87677f83b1_93760227',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '11b65a740b51a2d0ed3818a2601e56827e73102d' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/taxonomia_invertebrados/snippet/index/view/item/index.css.tpl',
      1 => 1686678877,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_649d87677f83b1_93760227 (Smarty_Internal_Template $_smarty_tpl) {
?><link rel="stylesheet" type="text/css" href="/js/geo/leaflet.1.7.1/leaflet.css"  />
<link rel="stylesheet" type="text/css" href="/js/geo/leaflet.fullscreen/Control.FullScreen.css" />
<link rel="stylesheet" type="text/css" href="/js/geo/leaflet.groupedlayercontrol/dist/leaflet.groupedlayercontrol.min.css" />

    <style>
    </style>
<?php }
}
