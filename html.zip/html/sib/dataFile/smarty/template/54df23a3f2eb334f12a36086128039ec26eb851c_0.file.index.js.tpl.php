<?php
/* Smarty version 4.2.1, created on 2025-01-30 22:45:34
  from '/var/www/html/sib/webapp/app/sib/module/geovisor/snippet/index/view/index.js.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_679c394ed9d7f9_46516839',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '54df23a3f2eb334f12a36086128039ec26eb851c' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/geovisor/snippet/index/view/index.js.tpl',
      1 => 1738098016,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_679c394ed9d7f9_46516839 (Smarty_Internal_Template $_smarty_tpl) {
echo '<script'; ?>
 src="https://maps.googleapis.com/maps/api/js?key=<?php echo $_smarty_tpl->tpl_vars['google_map_key']->value;?>
"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="/js/geo/leaflet.1.7.1/leaflet.js"><?php echo '</script'; ?>
>


<?php echo '<script'; ?>
 src="/js/geo/leaflet.spin/example/spin/dist/spin.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="/js/geo/leaflet.spin/leaflet.spin.min.js"><?php echo '</script'; ?>
>

<?php echo '<script'; ?>
 src="/js/geo/leaflet.sidebar-v2/js/leaflet-sidebar.js"><?php echo '</script'; ?>
>


<?php echo '<script'; ?>
 src="/js/geo/leaflet.extramarkers/dist/js/leaflet.extra-markers.js">

<?php echo '<script'; ?>
 src="/js/geo/leaflet.fullscreen/Control.FullScreen.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="/js/geo/Leaflet.GoogleMutant.js"><?php echo '</script'; ?>
>

<?php echo '<script'; ?>
 src="/js/geo/leaflet.ajax/dist/leaflet.ajax.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="/js/geo/leaflet.ajax/example/spin.js"><?php echo '</script'; ?>
>

<!--script src="/js/geo/leaflet.groupedlayercontrol/dist/leaflet.groupedlayercontrol.min.js"><?php echo '</script'; ?>
-->
<?php echo '<script'; ?>
 src="/js/geo/leaflet.panel-layers/dist/leaflet-panel-layers.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="/js/geo/leaflet.wms/dist/leaflet.wms.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="/js/geo/leaflet.minimap/dist/Control.MiniMap.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="/js/geo/leaflet.control.custom/Leaflet.Control.Custom.js"><?php echo '</script'; ?>
>


<?php echo '<script'; ?>
 src="/js/geo/leaflet.wms-legend/leaflet.wmslegend.js"><?php echo '</script'; ?>
>


<?php echo '<script'; ?>
 src="/js/geo/leaflet.gibs/src/GIBSMetadata.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="/js/geo/leaflet.gibs/src/GIBSLayer.js"><?php echo '</script'; ?>
>

<?php echo '<script'; ?>
 src="/js/chart.js/Chart.min.js"><?php echo '</script'; ?>
>



<?php echo '<script'; ?>
>
    var filtro_var="";
    var filtro_departamento, filtro_programa;
    var filtro_estado,filtro_gd_tipo_fuente_generacion;
    var urlsys = '<?php echo $_smarty_tpl->tpl_vars['path_url']->value;?>
';
    var urljson = urlsys+'/get.point';

    var json_layer;
    var recargar;
    let workspaces = "sib:";


    var snippet_tab_item = function () {
        var borra_contenido_tabs = function () {
            
            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['menu_tab']->value, 'row', false, 'idx');
$_smarty_tpl->tpl_vars['row']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['idx']->value => $_smarty_tpl->tpl_vars['row']->value) {
$_smarty_tpl->tpl_vars['row']->do_else = false;
?>
            $("#<?php echo $_smarty_tpl->tpl_vars['row']->value['id_name'];?>
_pane").html("");
            <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
            
            reset_estado();
        };
        var handler_tab_build = function(){
            $('[data-toggle="tabajax"]').click(function(e) {
                e.preventDefault();
                var $this = $(this),
                    loadurl = $this.attr('data-href') + filtro_var,
                    targ = $this.attr('data-target');
                id_name =targ;
                targ = "#"+targ+"_pane";
                //Vaciamos el tab
                recargar = 0;
                switch(id_name) {
                
                <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['menu_tab']->value, 'row', false, 'idx');
$_smarty_tpl->tpl_vars['row']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['idx']->value => $_smarty_tpl->tpl_vars['row']->value) {
$_smarty_tpl->tpl_vars['row']->do_else = false;
?>
                    case '<?php echo $_smarty_tpl->tpl_vars['row']->value['id_name'];?>
':
                        if (<?php echo $_smarty_tpl->tpl_vars['row']->value['id_name'];?>
_var ==0){
                            <?php echo $_smarty_tpl->tpl_vars['row']->value['id_name'];?>
_var =1;
                            recargar = 1;
                        }
                        break;
                <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                
                }

                if(recargar==1){
                    borra_contenido_tabs();
                    cargando = "<div style='text-align: center;padding-top: 50px;'>Cargando datos...</div>";
                    $(targ).html(cargando);
                    $.get(loadurl, function(data) {
                        $(targ).html(data);
                    });

                    switch(id_name) {
                    
                    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['menu_tab']->value, 'row', false, 'idx');
$_smarty_tpl->tpl_vars['row']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['idx']->value => $_smarty_tpl->tpl_vars['row']->value) {
$_smarty_tpl->tpl_vars['row']->do_else = false;
?>
                        case '<?php echo $_smarty_tpl->tpl_vars['row']->value['id_name'];?>
':
                            <?php echo $_smarty_tpl->tpl_vars['row']->value['id_name'];?>
_var =1;
                            break;
                    <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                    
                    }
                }

                return false;
            });
        };


        
        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['menu_tab']->value, 'row', false, 'idx');
$_smarty_tpl->tpl_vars['row']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['idx']->value => $_smarty_tpl->tpl_vars['row']->value) {
$_smarty_tpl->tpl_vars['row']->do_else = false;
?>
        var <?php echo $_smarty_tpl->tpl_vars['row']->value['id_name'];?>
_var;
        <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
        


        var reset_estado = function(){
            
            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['menu_tab']->value, 'row', false, 'idx');
$_smarty_tpl->tpl_vars['row']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['idx']->value => $_smarty_tpl->tpl_vars['row']->value) {
$_smarty_tpl->tpl_vars['row']->do_else = false;
?>
            <?php echo $_smarty_tpl->tpl_vars['row']->value['id_name'];?>
_var = 0;
            <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
            
        };

        return {
            init: function() {
                handler_tab_build();
                reset_estado();
            },
            reset_estado: function () {
                reset_estado();
            }
        };
    }();



    var map;
    var snippet_geovisor = function () {

        var map_default_center = [-17.403918, -64.354500];
        var map_default_zoom= 6;
        var geoserver_mmaya = '/geoserver/wms';
        var geoserver_sig01 = 'https://sig01.mmaya.gob.bo/geoserver/wms';
        var layer_departamento,layer_municipio;
        var uh_nivel1,uh_nivel2,uh_nivel3,uh_nivel4,uh_nivel5, macroregion,cuencas_operativas;

        var getGroupedOverlays = function(){

            /**
             * Grupos restantes
             */
            var overLayers = [
                {
                    group: "Administrativos",
                    collapsed: true,
                    layers: [
                        {
                            active: true,
                            name: "Departamento",
                            icon: '<i class="fa fa-map-marked-alt icon-sm"></i>',
                            layer: layer_departamento
                        },
                        {
                            name: "Municipio",
                            icon: '<i class="fa fa-map-marked-alt icon-sm"></i>',
                            layer: layer_municipio
                        }

                    ]
                },
                {
                    group: "Unidad Hidrográfica",
                    collapsed: true,
                    layers: [
                        {
                            active: false,
                            name: "UH Nivel5",
                            icon: '<i class="fa fa-map-marked-alt icon-sm"></i>',
                            layer: uh_nivel5
                        },
                        ...
                    ]
                },
                ...
            ];
            return overLayers;
        };

        var initialiseMap = function(){
            var mapOptions = {
                center: map_default_center//punto
                , zoom: map_default_zoom
                ,fullscreenControl: true
                ,scrollWheelZoom: true
            };
            var m = L.map('map',mapOptions);
            L.control.scale({metric: true, imperial: false}).addTo(m);
            return m;
        };

        var createMap = function(){
            map = initialiseMap();
            var controlLayers = new L.Control.PanelLayers(getBaseLayers(), getGroupedOverlays(), options);
            map.addControl(controlLayers);
        };

        return {
            init: function() {
                createMap();
            },
        };

    }();

    jQuery(document).ready(function() {
        snippet_geovisor.init();
        snippet_tab_item.init();
    });

<?php echo '</script'; ?>
>

<?php }
}
