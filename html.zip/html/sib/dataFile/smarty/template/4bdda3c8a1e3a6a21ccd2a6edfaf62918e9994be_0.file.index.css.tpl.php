<?php
/* Smarty version 4.2.1, created on 2023-09-20 09:13:25
  from '/var/www/html/sib/webapp/app/sib/module/zoologia_ormitologia/snippet/taxonomia/view/index.css.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_650aeff5a99723_42871722',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4bdda3c8a1e3a6a21ccd2a6edfaf62918e9994be' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/zoologia_ormitologia/snippet/taxonomia/view/index.css.tpl',
      1 => 1678278586,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_650aeff5a99723_42871722 (Smarty_Internal_Template $_smarty_tpl) {
?>
    <style>
        .select2-results__group{
            background: #e7f1f6;
            border-bottom: 2px solid #006ba2;
        }

    </style>
<?php }
}
