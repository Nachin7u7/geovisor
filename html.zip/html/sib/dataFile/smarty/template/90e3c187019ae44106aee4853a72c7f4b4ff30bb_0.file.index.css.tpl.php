<?php
/* Smarty version 4.2.1, created on 2024-05-27 11:52:07
  from '/var/www/html/sib/webapp/app/sib/module/zoologia_mastozoologia/snippet/datoscolecta/view/index.css.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_6654ac27249533_47963940',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '90e3c187019ae44106aee4853a72c7f4b4ff30bb' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/zoologia_mastozoologia/snippet/datoscolecta/view/index.css.tpl',
      1 => 1678278586,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6654ac27249533_47963940 (Smarty_Internal_Template $_smarty_tpl) {
?>
    <style>
        .select2-results__group{
            background: #e7f1f6;
            border-bottom: 2px solid #006ba2;
        }

    </style>
<?php }
}
