<?php
/* Smarty version 4.2.1, created on 2023-03-01 14:01:36
  from '/var/www/html/sib/webapp/app/core/template/base/base.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_63ff9300296623_60467004',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '530af47eb04a43a063352e0f0839351a4dddb75f' => 
    array (
      0 => '/var/www/html/sib/webapp/app/core/template/base/base.tpl',
      1 => 1668028010,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_63ff9300296623_60467004 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="en">
<!--begin::Head-->
<head>    <meta charset="utf-8" />
    <title><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'sbmTitle');?>
 <?php if ($_smarty_tpl->tpl_vars['miga']->value['appModuleData']['folder'] != '') {?>| <?php echo $_smarty_tpl->tpl_vars['miga']->value['appModuleData']['name'];
}?></title>
    <meta name="description" content="UYUNI - <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'sbmTitle');?>
" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta http-equiv="Cache-control" content="public">
    <!--begin::Fonts-->

    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" />

        <!--end::Fonts-->

    <!--begin::Page Vendors Styles(used by this page)-->
    <link href="/themes/metro72/assets/plugins/custom/datatables/datatables.bundle.css" rel="stylesheet" type="text/css" />
    <!--end::Page Vendors Styles-->
    <!--begin::Global Theme Styles(used by all pages)-->
    <link href="/themes/metro72/assets/plugins/global/plugins.bundle.css" rel="stylesheet" type="text/css" />
    <link href="/themes/metro72/assets/plugins/custom/prismjs/prismjs.bundle.css" rel="stylesheet" type="text/css" />
    <link href="/themes/metro72/assets/css/style.bundle.css" rel="stylesheet" type="text/css" />
    <!--end::Global Theme Styles-->
    <!--begin::Layout Themes(used by all pages)-->
    <link href="/themes/metro72/assets/css/themes/layout/header/base/light.css" rel="stylesheet" type="text/css" />
    <link href="/themes/metro72/assets/css/themes/layout/header/menu/light.css" rel="stylesheet" type="text/css" />
    <link href="/themes/metro72/assets/css/themes/layout/brand/dark.css" rel="stylesheet" type="text/css" />
    <link href="/themes/metro72/assets/css/themes/layout/aside/dark.css" rel="stylesheet" type="text/css" />

    <link href="/js/uyuni/core.css" rel="stylesheet" type="text/css" />
    <!--end::Layout Themes-->
    <link rel="apple-touch-icon" sizes="180x180" href="/favicon/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/favicon/favicon-16x16.png">
    <link rel="manifest" href="/favicon/site.webmanifest">
    <link rel="mask-icon" href="/favicon/safari-pinned-tab.svg" color="#5bbad5">
    <link rel="shortcut icon" href="/favicon/favicon.ico">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="msapplication-config" content="/favicon/browserconfig.xml">
    <meta name="theme-color" content="#ffffff">


    <!-- Global site tag (gtag.js) - Google Analytics -->
    <?php echo '<script'; ?>
 async src="https://www.googletagmanager.com/gtag/js?id=G-Q2ET7BVBY2"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());

        gtag('config', 'G-G533H9V4HE');
    <?php echo '</script'; ?>
>


</head>
<!--end::Head-->
<!--begin::Body-->
<body id="kt_body"
      class="header-fixed header-mobile-fixed subheader-enabled
      subheader-fixed aside-enabled aside-fixed
      aside-minimize-hoverable       page-loading">

<?php $_smarty_tpl->_subTemplateRender($_smarty_tpl->tpl_vars['frontend']->value['_page_loader'], $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, true);
?>

<!--begin::Main-->
<?php $_smarty_tpl->_subTemplateRender($_smarty_tpl->tpl_vars['frontend']->value['_header_mobile'], $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, true);
?>

<div class="d-flex flex-column flex-root">
    <!--begin::Page-->
    <div class="d-flex flex-row flex-column-fluid page">
        <?php $_smarty_tpl->_subTemplateRender($_smarty_tpl->tpl_vars['frontend_app']->value['left_aside'], $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, true);
?>
        <!--begin::Wrapper-->
        <div class="d-flex flex-column flex-row-fluid wrapper" id="kt_wrapper">
            <?php $_smarty_tpl->_subTemplateRender($_smarty_tpl->tpl_vars['frontend']->value['_header'], $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, true);
?>

            <!--begin::Content-->
            <div class="content d-flex flex-column flex-column-fluid" id="kt_content">
                <?php $_smarty_tpl->_subTemplateRender($_smarty_tpl->tpl_vars['frontend']->value['_subheader_v1'], $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, true);
?>

                <!--begin::Entry-->
                <div class="d-flex flex-column-fluid">
                    <!--begin::Container-->
                    <div class="container-fluid">
                        <!--begin::Dashboard-->
                        <?php $_smarty_tpl->_subTemplateRender(((string)$_smarty_tpl->tpl_vars['subpage']->value), $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, true);
?>
                        <!--end::Dashboard-->
                    </div>
                    <!--end::Container-->
                </div>
                <!--end::Entry-->
            </div>
            <!--end::Content-->
            <?php $_smarty_tpl->_subTemplateRender($_smarty_tpl->tpl_vars['frontend']->value['_footer'], $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, true);
?>
        </div>
        <!--end::Wrapper-->
    </div>
    <!--end::Page-->
</div>
<!--end::Main-->

<?php $_smarty_tpl->_subTemplateRender($_smarty_tpl->tpl_vars['frontend']->value['_quick_user'], $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, true);
$_smarty_tpl->_subTemplateRender($_smarty_tpl->tpl_vars['frontend']->value['_quick_panel'], $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, true);
$_smarty_tpl->_subTemplateRender($_smarty_tpl->tpl_vars['frontend']->value['_scrolltop'], $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, true);
?>

<!--begin::Global Theme Bundle(used by all pages)-->
<?php echo '<script'; ?>
 src="/themes/metro72/assets/plugins/global/plugins.bundle.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="/themes/metro72/assets/plugins/custom/prismjs/prismjs.bundle.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
>
    var lng = "<?php echo $_smarty_tpl->tpl_vars['lng']->value;?>
";
<?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="/language/js/uyuni.<?php echo $_smarty_tpl->tpl_vars['lng']->value;?>
.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="/js/uyuni/core.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="/themes/metro72/assets/js/scripts.bundle.js"><?php echo '</script'; ?>
>
<!--end::Global Theme Bundle-->



<!--begin::Page Vendors(used by this page)-->
<?php echo '<script'; ?>
 src="/themes/metro72/assets/plugins/custom/datatables/datatables.bundle.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="/language/js/datepicker.spanish.js" type="text/javascript"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="/js/jquery.number/jquery.number.min.js" type="text/javascript"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="/js/jquery.form/jquery.form.min.js" type="text/javascript"><?php echo '</script'; ?>
>




<!--end::Page Vendors-->

<!--begin::Page Scripts(used by this page)-->
<!--end::Page Scripts-->


<!--begin::jsPrincipal -->
<?php $_smarty_tpl->_subTemplateRender(((string)$_smarty_tpl->tpl_vars['subpage_js']->value), $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, true);
?>
<!--end::jsPrincipal -->


</body>
<!--end::Body-->
</html><?php }
}
