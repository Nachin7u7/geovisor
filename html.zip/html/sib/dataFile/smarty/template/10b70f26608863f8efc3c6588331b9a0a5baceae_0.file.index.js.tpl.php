<?php
/* Smarty version 4.2.1, created on 2022-11-10 11:06:21
  from '/var/www/html/sib/webapp/app/setting/module/index/snippet/index/view/index.js.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_636d136d2582c7_85776073',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '10b70f26608863f8efc3c6588331b9a0a5baceae' => 
    array (
      0 => '/var/www/html/sib/webapp/app/setting/module/index/snippet/index/view/index.js.tpl',
      1 => 1668028010,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_636d136d2582c7_85776073 (Smarty_Internal_Template $_smarty_tpl) {
}
}
