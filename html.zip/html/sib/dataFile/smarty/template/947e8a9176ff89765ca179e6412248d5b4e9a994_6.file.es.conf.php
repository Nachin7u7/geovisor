<?php /* Smarty version 4.2.1, created on 2023-01-10 11:32:32
         compiled from '/var/www/html/sib/webapp/app/setting/module/app/snippet/module/language/es.conf' */ ?>
<?php
/* Smarty version 4.2.1, created on 2023-01-10 11:32:32
  from '/var/www/html/sib/webapp/app/setting/module/app/snippet/module/language/es.conf' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_63bd8510dc9355_57034673',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '947e8a9176ff89765ca179e6412248d5b4e9a994' => 
    array (
      0 => '/var/www/html/sib/webapp/app/setting/module/app/snippet/module/language/es.conf',
      1 => 1668028010,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_63bd8510dc9355_57034673 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigVars($_smarty_tpl, array (
  'sections' => 
  array (
    'index' => 
    array (
      'vars' => 
      array (
        'title' => 'Lista de módulos de la aplicación',
        'btnNew' => 'Nuevo módulo',
        'filterName' => 'Nombre',
        'filterNameHolder' => 'Buscar por nombre de aplicación',
        'filterAppStatus' => 'Estado de la aplicación',
        'filterAppStatusSelectAll' => 'Todos los estados',
        'dataTableExportTitle' => 'Lista de grupos de la aplicación',
      ),
    ),
    'tableIndex' => 
    array (
      'vars' => 
      array (
        'tableGroupname' => 'Grupo',
        'tableName' => 'Nombre',
        'tableId' => 'Id',
        'tableOrder' => 'Orden',
        'tableClass' => 'Icon',
        'tableTarget' => 'Nueva Ventana',
        'tableType' => 'Tipo',
        'tableFolder' => 'Carpeta',
        'tableDescription' => 'Descripcion',
        'tableStatus' => 'Estado',
      ),
    ),
    'formItem' => 
    array (
      'vars' => 
      array (
        'title' => 'Módulo',
        'message' => 'Podrás realizar el registro y configuración de una aplicación para el FrameWork Uyuni',
        'fieldGroup' => 'Grupo',
        'fieldGroupHolder' => 'Elija Submódulo',
        'fieldGroupMsg' => 'Seleccione el grúpo al que pertenece',
        'fieldName' => 'Nombre del Módulo',
        'fieldNameLength' => 'Tiene que ser mayor o igual a 3 caracteres',
        'fieldNameMsg' => 'Ingrese el nombre del Módulo',
        'fielClass' => 'Icono - Class',
        'fielClassMsg' => 'Ingrese la "clase" del ícono (CSS)',
        'fieldActive' => 'Activo',
        'fieldActiveMsg' => 'Para poder activar o desactivar el módulo para ver',
        'fieldTarget' => 'Abrir en nueva ventana',
        'fieldTargetMsg' => 'Permite abrir el módulo o url en otra ventana',
        'fielOrder' => 'Orden',
        'fielOrderMsg' => 'Ingrese el número de posición',
        'fielType' => 'Tipo',
        'fielTypeHolder' => 'Elija un tipo',
        'fielFolder' => 'Carpeta',
        'fielFolderMsg' => 'Ingrese la Carpeta que alojará el código',
        'fieldDescription' => 'Descripción',
      ),
    ),
  ),
  'vars' => 
  array (
  ),
));
}
}
