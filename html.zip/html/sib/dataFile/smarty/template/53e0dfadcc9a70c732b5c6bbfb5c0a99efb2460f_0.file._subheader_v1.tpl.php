<?php
/* Smarty version 4.2.1, created on 2022-11-09 17:25:50
  from '/var/www/html/sib/webapp/app/core/template/frontend_core_72/_subheader_v1.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_636c1adea3fe97_26509731',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '53e0dfadcc9a70c732b5c6bbfb5c0a99efb2460f' => 
    array (
      0 => '/var/www/html/sib/webapp/app/core/template/frontend_core_72/_subheader_v1.tpl',
      1 => 1668028010,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_636c1adea3fe97_26509731 (Smarty_Internal_Template $_smarty_tpl) {
?><!--begin::Subheader-->
<div class="subheader py-2 py-lg-4 subheader-solid" id="kt_subheader">
    <div class="container-fluid d-flex align-items-center justify-content-between flex-wrap flex-sm-nowrap">
        <!--begin::Info-->
        <div class="d-flex align-items-center flex-wrap mr-2">

            <?php if ($_smarty_tpl->tpl_vars['miga']->value['appModuleData']['folder'] != 'index') {?>
                <a href="/<?php echo $_smarty_tpl->tpl_vars['miga']->value['appData']['folder'];?>
" class="btn btn-light-facebook font-weight-bolder btn-sm mr-2">
                    <i class="la la-home"></i><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'gl_home');?>
</a>
                <div class="subheader-separator subheader-separator-ver mt-2 mb-2 mr-2 bg-gray-200"></div>
                <span class="text-muted font-weight-bold "><?php if ($_smarty_tpl->tpl_vars['miga']->value['appModuleData']['folder'] != '') {
echo $_smarty_tpl->tpl_vars['miga']->value['appGroupData']['name'];
} else {
echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'sbmTitleMenu');
}?></span>
                <?php if ($_smarty_tpl->tpl_vars['miga']->value['appModuleData']['folder'] != '') {?>
                    <div class="subheader-separator subheader-separator-ver mt-2 mb-2 mr-2 ml-2 bg-gray-200"></div>
                    <span class="text-muted font-weight-bold ">
                                        <?php echo $_smarty_tpl->tpl_vars['miga']->value['appModuleData']['name'];?>

                                            </span>
                <?php }?>
            <?php } else { ?>
                <!--begin::Page Title-->
                <h5 class="text-dark font-weight-bold mt-2 mb-2 mr-5">
                    <i class="la la-home mr-2"></i>
                    <?php echo $_smarty_tpl->tpl_vars['module_conf']->value['dashboard_titulo'];?>

                </h5>
                <!--end::Page Title-->
            <?php }?>

            <!--begin::Actions-->
            <!--end::Actions-->
        </div>
        <!--end::Info-->

        <!--begin::Toolbar-->
        <div class="d-flex align-items-center">
            <a href="<?php echo $_smarty_tpl->tpl_vars['path_url']->value;?>
" class="btn btn-primary d-none btn-sm" id="btn_back"><i class="ki ki-double-arrow-back"></i><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glBtnBack');?>
</a>
            <a href="#"           class="btn btn-success d-none btn-sm" id="btn_new" rel="new"><i class="fa fa-plus"></i><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'btnNew');?>
</a>
        </div>
        <!--end::Toolbar-->

    </div>
</div>
<!--end::Subheader--><?php }
}
