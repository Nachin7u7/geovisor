<?php
/* Smarty version 4.2.1, created on 2024-05-27 12:01:35
  from '/var/www/html/sib/webapp/app/sib/module/taxonomia_mastozoologia/snippet/index/view/item/index.js.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_6654ae5fae2fd4_00926804',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a69c1c88fd57c958a6455cf7f88ebda8e1dff3bd' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/taxonomia_mastozoologia/snippet/index/view/item/index.js.tpl',
      1 => 1686678877,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6654ae5fae2fd4_00926804 (Smarty_Internal_Template $_smarty_tpl) {
echo '<script'; ?>
>
    var snippet_tab_item = function () {
        "use strict";
        var handler_tab_build = function(){
            coreUyuni.setTabs();
        };
        return {
            init: function() {
                handler_tab_build();
            }
        };
    }();

    jQuery(document).ready(function() {
        $('#btn_back').removeClass('d-none');
        snippet_tab_item.init();
        $('#<?php echo $_smarty_tpl->tpl_vars['menu_tab_active']->value;?>
_tab').trigger('click');
    });
<?php echo '</script'; ?>
>



<?php }
}
