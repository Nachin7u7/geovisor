<?php
/* Smarty version 4.2.1, created on 2023-01-10 11:32:52
  from '/var/www/html/sib/webapp/app/setting/module/app/snippet/module/view/form/form.css.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_63bd8524998258_36062306',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '37252f800769c6a4ac0fdde89f8e7f14c2651225' => 
    array (
      0 => '/var/www/html/sib/webapp/app/setting/module/app/snippet/module/view/form/form.css.tpl',
      1 => 1668028010,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_63bd8524998258_36062306 (Smarty_Internal_Template $_smarty_tpl) {
?>
<style>
    .archivo{color:green !important; background:#f6fff4;}
    .custom-file-label::after {
        content: "Buscar Archivo" !important;
    }
    input[type=number]::-webkit-inner-spin-button,
    input[type=number]::-webkit-outer-spin-button {
        -webkit-appearance: none;
        margin: 0;
    }

    .input-mini{
        -moz-appearance:textfield;}

    .form-control-feedback{
        color: red!important;
    }

</style>
<?php }
}
