<?php
/* Smarty version 4.2.1, created on 2023-03-29 17:37:47
  from '/var/www/html/sib/webapp/app/core/template/frontend_core_72/_page_loader.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_6424afab43ade4_44351303',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '072033f4327263ba6026493845143fb29f4be8ff' => 
    array (
      0 => '/var/www/html/sib/webapp/app/core/template/frontend_core_72/_page_loader.tpl',
      1 => 1668028010,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6424afab43ade4_44351303 (Smarty_Internal_Template $_smarty_tpl) {
?><!--begin::Page loader-->
<div class="page-loader page-loader-base">
    <div class="blockui">
        <span>Cargando Uyuni...</span>
        <span><div class="spinner spinner-primary"></div></span>
    </div>
</div>
<!--end::Page Loader--><?php }
}
