<?php
/* Smarty version 4.2.1, created on 2023-03-29 08:21:33
  from '/var/www/html/sib/webapp/app/sib/module/taxonomia_botanica/snippet/general/view/addclass/form.css.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_64242d4d41d040_14012117',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a4c5cdb76464c7dab5cd3761ee64743141bf1225' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/taxonomia_botanica/snippet/general/view/addclass/form.css.tpl',
      1 => 1680015874,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_64242d4d41d040_14012117 (Smarty_Internal_Template $_smarty_tpl) {
?>
    <style>

    </style>
<?php }
}
