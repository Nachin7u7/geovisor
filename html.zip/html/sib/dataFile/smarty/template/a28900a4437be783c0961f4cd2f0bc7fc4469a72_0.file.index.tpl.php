<?php
/* Smarty version 4.2.1, created on 2023-02-06 08:50:42
  from '/var/www/html/sib/webapp/app/sib/module/taxonomia_botanica/snippet/index/view/item/index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_63e0f7a2e7b827_87438845',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a28900a4437be783c0961f4cd2f0bc7fc4469a72' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/taxonomia_botanica/snippet/index/view/item/index.tpl',
      1 => 1675456623,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:item/index.css.tpl' => 1,
  ),
),false)) {
function content_63e0f7a2e7b827_87438845 (Smarty_Internal_Template $_smarty_tpl) {
if (($_smarty_tpl->tpl_vars['item']->value['id'] != 0 && $_smarty_tpl->tpl_vars['item']->value['id'] != '' && $_smarty_tpl->tpl_vars['type']->value == "update") || $_smarty_tpl->tpl_vars['type']->value == "new") {?>
    <?php $_smarty_tpl->_subTemplateRender("file:item/index.css.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
    <div class="d-flex flex-column flex-md-row">
        <div class="flex-md-row-fluid ">
            <div class="card card-custom gutter-b">
                <div class="card-header card-header-tabs-line">
                    <div class="card-toolbar">
                        <ul class="nav nav-tabs nav-tabs-space-lg nav-tabs-line nav-tabs-bold nav-tabs-line-3x" id="myTab" role="tablist">
                            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['menu_tab']->value, 'row', false, 'idx');
$_smarty_tpl->tpl_vars['row']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['idx']->value => $_smarty_tpl->tpl_vars['row']->value) {
$_smarty_tpl->tpl_vars['row']->do_else = false;
?>
                                <li class="nav-item">
                                    <a class="nav-link"
                                       role="tab"
                                       data-toggle="tabajax"
                                       data-target="#<?php echo $_smarty_tpl->tpl_vars['row']->value['id_name'];?>
_pane"
                                       id = "<?php echo $_smarty_tpl->tpl_vars['row']->value['id_name'];?>
_tab"
                                            <?php if ($_smarty_tpl->tpl_vars['type']->value == 'update') {?>
                                                href="<?php echo $_smarty_tpl->tpl_vars['path_url']->value;?>
/<?php echo $_smarty_tpl->tpl_vars['row']->value['id_name'];?>
_/<?php echo $_smarty_tpl->tpl_vars['id']->value;?>
"
                                            <?php } else { ?>
                                                href="<?php echo $_smarty_tpl->tpl_vars['path_url']->value;?>
/<?php echo $_smarty_tpl->tpl_vars['row']->value['id_name'];?>
_/new/"
                                            <?php }?>
                                    >
                                        <span class="nav-icon"><i class="<?php echo $_smarty_tpl->tpl_vars['row']->value['icon'];?>
"></i></span>
                                        <span class="nav-text"><?php echo $_smarty_tpl->tpl_vars['row']->value['label'];?>
</span>
                                    </a>
                                </li>
                            <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>

                        </ul>
                    </div>
                </div>
                <div class="card-body p-0" >
                    <div class="tab-content mt-5" >
                        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['menu_tab']->value, 'row', false, 'idx');
$_smarty_tpl->tpl_vars['row']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['idx']->value => $_smarty_tpl->tpl_vars['row']->value) {
$_smarty_tpl->tpl_vars['row']->do_else = false;
?>
                            <div class="tab-pane fade" id="<?php echo $_smarty_tpl->tpl_vars['row']->value['id_name'];?>
_pane" role="tabpanel" aria-labelledby="<?php echo $_smarty_tpl->tpl_vars['row']->value['id_name'];?>
-tab"></div>
                        <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                    </div>
                </div>
            </div>
        </div>

            </div>

<?php } else { ?>
    <?php $_smarty_tpl->_subTemplateRender($_smarty_tpl->tpl_vars['frontend']->value['error_01'], $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, true);
}?>

<?php }
}
