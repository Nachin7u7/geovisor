<?php
/* Smarty version 4.2.1, created on 2023-03-08 08:33:08
  from '/var/www/html/sib/webapp/app/sib/module/zoologia_anfibios/snippet/lugarcolecta/view/formprincipal/index.css.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_64088084b7da29_40962559',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a3f87ae318bcb7c2e5c9b853fb1fad9feac693c7' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/zoologia_anfibios/snippet/lugarcolecta/view/formprincipal/index.css.tpl',
      1 => 1678278586,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_64088084b7da29_40962559 (Smarty_Internal_Template $_smarty_tpl) {
?>
    <style>
        .select2-results__group{
            background: #e7f1f6;
            border-bottom: 2px solid #006ba2;
        }
    </style>
<?php }
}
