<?php
/* Smarty version 4.2.1, created on 2023-06-29 09:30:09
  from '/var/www/html/sib/webapp/app/sib/module/taxonomia_invertebrados/snippet/index/view/index.css.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_649d8761601e71_24001703',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a25617554b4fe1096702c1236ca7f5bc8f798b7f' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/taxonomia_invertebrados/snippet/index/view/index.css.tpl',
      1 => 1686678877,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_649d8761601e71_24001703 (Smarty_Internal_Template $_smarty_tpl) {
?>
    <style>
        .dtrg-level-0 td{
            /* background: #e7f2fe!important;
             border-top: 4px solid #9bbbde;*/
            background: #fafbfc !important;
            border-top: 2px solid #c0d8e6;
            padding: 5px 5px 5px 5px !important;

        }
        .dtrg-level-0 td::before {
            font-family: "Font Awesome 5 Free";
            font-weight: 900;
            content: "\f107";
            margin-right: 5px;
        }

        .dtrg-level-1 td{
            background: #f2f8ff !important;
            padding: 5px 5px 5px 10px !important;
            color: #3699ff !important;
        }
        .dtrg-level-1 td::before {
            font-family: "Font Awesome 5 Free";
            font-weight: 900;
            content: "\f107";
            margin-right: 5px;
        }
    </style>
<?php }
}
