<?php
/* Smarty version 4.2.1, created on 2023-03-08 08:33:04
  from '/var/www/html/sib/webapp/app/sib/module/zoologia_anfibios/snippet/general/view/index.css.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_6408808089b6b5_87002511',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '71a66f95b4bc263800955e03b71fb3cc119f75b5' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/zoologia_anfibios/snippet/general/view/index.css.tpl',
      1 => 1678278586,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6408808089b6b5_87002511 (Smarty_Internal_Template $_smarty_tpl) {
?>
    <style>
        .select2-results__group{
            background: #e7f1f6;
            border-bottom: 2px solid #006ba2;
        }

        .proyecto{
            background: #c0deed;
            border-bottom: 1px solid #dfeff7;
            border-top: 1px solid #dfeff7;
        }
        .proyecto label{
            color: #059ded;
        }

    </style>
<?php }
}
