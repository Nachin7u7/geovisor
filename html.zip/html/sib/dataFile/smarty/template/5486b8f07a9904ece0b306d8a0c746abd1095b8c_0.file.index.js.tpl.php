<?php
/* Smarty version 4.2.1, created on 2022-11-09 19:22:56
  from '/var/www/html/sib/webapp/app/web/module/index/snippet/index/view/index.js.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_636c3650b6cdd6_55347847',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '5486b8f07a9904ece0b306d8a0c746abd1095b8c' => 
    array (
      0 => '/var/www/html/sib/webapp/app/web/module/index/snippet/index/view/index.js.tpl',
      1 => 1668028010,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_636c3650b6cdd6_55347847 (Smarty_Internal_Template $_smarty_tpl) {
}
}
