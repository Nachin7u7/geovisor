<?php /* Smarty version 4.2.1, created on 2022-11-10 10:58:21
         compiled from '/var/www/html/sib/webapp/app/sib/module/geovisor/snippet/index/language/es.conf' */ ?>
<?php
/* Smarty version 4.2.1, created on 2022-11-10 10:58:21
  from '/var/www/html/sib/webapp/app/sib/module/geovisor/snippet/index/language/es.conf' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_636d118d5a7ee1_85227301',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '9b27b787dbab8feadd3148743eea455f8a2588f1' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/geovisor/snippet/index/language/es.conf',
      1 => 1668028010,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_636d118d5a7ee1_85227301 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigVars($_smarty_tpl, array (
  'sections' => 
  array (
    'index' => 
    array (
      'vars' => 
      array (
        'title' => 'Empresas distribuidoras',
        'btnNew' => 'Nueva empresa',
        'filter' => 'Nombre',
        'filterCiae' => 'Buscar por CIAE',
        'filterCompanyName' => 'Buscar por nombre de la empresa',
        'dataTableExportTitle' => 'Lista de Aplicaciones',
      ),
    ),
    'tableIndex' => 
    array (
      'vars' => 
      array (
        'table_ciae' => 'CIAE',
        'table_name_company' => 'Nombre de la Empresa',
        'table_sigla' => 'Sigla',
        'table_license' => 'Licencia',
        'table_activity' => 'Actividad',
        'table_status' => 'Estado',
      ),
    ),
    'item' => 
    array (
      'vars' => 
      array (
        'fieldActive' => 'Activo',
        'title' => 'Gestión de Empresas Distribuidoras',
      ),
    ),
    'tabItem' => 
    array (
      'vars' => 
      array (
        'tabGeneral' => 'General',
        'tabGroups' => 'Grupos',
        'tabModules' => 'Módulos',
      ),
    ),
  ),
  'vars' => 
  array (
  ),
));
}
}
