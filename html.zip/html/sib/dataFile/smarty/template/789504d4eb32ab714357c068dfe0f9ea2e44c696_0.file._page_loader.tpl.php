<?php
/* Smarty version 4.2.1, created on 2023-02-06 16:01:59
  from '/var/www/html/sib/webapp/app/core/template/frontend_core_72/_page_loader.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_63e15cb751e795_60672979',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '789504d4eb32ab714357c068dfe0f9ea2e44c696' => 
    array (
      0 => '/var/www/html/sib/webapp/app/core/template/frontend_core_72/_page_loader.tpl',
      1 => 1668028010,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_63e15cb751e795_60672979 (Smarty_Internal_Template $_smarty_tpl) {
?><!--begin::Page loader-->
<div class="page-loader page-loader-base">
    <div class="blockui">
        <span>Cargando Uyuni...</span>
        <span><div class="spinner spinner-primary"></div></span>
    </div>
</div>
<!--end::Page Loader--><?php }
}
