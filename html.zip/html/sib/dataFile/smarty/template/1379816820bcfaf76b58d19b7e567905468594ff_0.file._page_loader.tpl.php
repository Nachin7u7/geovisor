<?php
/* Smarty version 4.2.1, created on 2022-11-10 08:41:18
  from '/var/www/html/sib/webapp/app/core/template/frontend_core_72/_page_loader.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_636cf16ec27285_95803970',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '1379816820bcfaf76b58d19b7e567905468594ff' => 
    array (
      0 => '/var/www/html/sib/webapp/app/core/template/frontend_core_72/_page_loader.tpl',
      1 => 1668028010,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_636cf16ec27285_95803970 (Smarty_Internal_Template $_smarty_tpl) {
?><!--begin::Page loader-->
<div class="page-loader page-loader-base">
    <div class="blockui">
        <span>Cargando Uyuni...</span>
        <span><div class="spinner spinner-primary"></div></span>
    </div>
</div>
<!--end::Page Loader--><?php }
}
