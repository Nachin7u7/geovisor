<?php
/* Smarty version 4.2.1, created on 2022-11-09 17:48:35
  from '/var/www/html/sib/webapp/app/sib/module/user/snippet/index/view/item/index.js.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_636c2033ebfbf4_96654111',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '67db9c080c16eed5471725ae74775f85b6e07ce1' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/user/snippet/index/view/item/index.js.tpl',
      1 => 1668028010,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_636c2033ebfbf4_96654111 (Smarty_Internal_Template $_smarty_tpl) {
echo '<script'; ?>
>
    var snippet_tab_item = function () {
        "use strict";
        var handler_tab_build = function(){
            coreUyuni.setTabs();
        };
        return {
            init: function() {
                handler_tab_build();
            }
        };
    }();

    jQuery(document).ready(function() {
        snippet_tab_item.init();
        $('#<?php echo $_smarty_tpl->tpl_vars['menu_tab_active']->value;?>
_tab').trigger('click');
    });
<?php echo '</script'; ?>
>

<?php }
}
