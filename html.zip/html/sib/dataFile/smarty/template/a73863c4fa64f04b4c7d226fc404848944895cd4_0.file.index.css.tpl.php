<?php
/* Smarty version 4.2.1, created on 2024-05-27 11:50:52
  from '/var/www/html/sib/webapp/app/sib/module/zoologia_invertebrado/snippet/datoscolecta/view/index.css.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_6654abdc08ba99_51239802',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a73863c4fa64f04b4c7d226fc404848944895cd4' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/zoologia_invertebrado/snippet/datoscolecta/view/index.css.tpl',
      1 => 1678278586,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6654abdc08ba99_51239802 (Smarty_Internal_Template $_smarty_tpl) {
?>
    <style>
        .select2-results__group{
            background: #e7f1f6;
            border-bottom: 2px solid #006ba2;
        }

    </style>
<?php }
}
