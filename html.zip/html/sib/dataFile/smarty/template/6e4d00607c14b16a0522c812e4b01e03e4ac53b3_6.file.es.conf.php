<?php /* Smarty version 4.2.1, created on 2023-03-02 08:42:23
         compiled from '/var/www/html/sib/webapp/app/sib/module/zoologia_ictiologia/snippet/colectorsecundario/language/es.conf' */ ?>
<?php
/* Smarty version 4.2.1, created on 2023-03-02 08:42:23
  from '/var/www/html/sib/webapp/app/sib/module/zoologia_ictiologia/snippet/colectorsecundario/language/es.conf' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_640099af60a749_79702637',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6e4d00607c14b16a0522c812e4b01e03e4ac53b3' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/zoologia_ictiologia/snippet/colectorsecundario/language/es.conf',
      1 => 1677671930,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_640099af60a749_79702637 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigVars($_smarty_tpl, array (
  'sections' => 
  array (
    'index' => 
    array (
      'vars' => 
      array (
        'title' => 'Colectores Secundarios',
        'message' => '<strong>Adicionar colector secundario</strong><br> Haga clic en el boton <strong>"Adicionar colector secundario"</strong> para registrar.',
        'btnNew' => 'Adicionar colector secundario',
        'dataTableExportTitle' => 'Colectores secundarios',
      ),
    ),
    'tableIndex' => 
    array (
      'vars' => 
      array (
        'table_nombre' => 'Nombres y apellidos',
      ),
    ),
    'formItem' => 
    array (
      'vars' => 
      array (
        'title' => 'Registrar Colector Secundario',
        'message' => 'Podrás registrar el colector secundario',
        'field_nombre' => 'Nombres y apellidos',
        'field_length_nombre' => 'Tiene que ser mayor o igual a 3 caracteres',
        'field_msg_nombre' => 'Ingrese los nombres y apellidos',
      ),
    ),
  ),
  'vars' => 
  array (
  ),
));
}
}
