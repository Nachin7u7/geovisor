<?php
/* Smarty version 4.2.1, created on 2022-11-11 01:40:00
  from '/var/www/html/sib/webapp/app/sib/module/botanica/snippet/foto/view/form/form.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_636de030062fc3_55595769',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '610f679aab6b22341dbd16b39c70f47933771c69' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/botanica/snippet/foto/view/form/form.tpl',
      1 => 1668144867,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:form/form.css.tpl' => 1,
    'file:form/form.js.tpl' => 1,
  ),
),false)) {
function content_636de030062fc3_55595769 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:form/form.css.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
<form method="POST"
      action="<?php echo $_smarty_tpl->tpl_vars['path_url']->value;?>
/<?php echo $_smarty_tpl->tpl_vars['subcontrol']->value;?>
_/<?php echo $_smarty_tpl->tpl_vars['item_id']->value;?>
/<?php if ($_smarty_tpl->tpl_vars['type']->value == "update") {
echo $_smarty_tpl->tpl_vars['id']->value;?>
/<?php }?>save/"
      id="form_<?php echo $_smarty_tpl->tpl_vars['subcontrol']->value;?>
">
    <?php if ($_smarty_tpl->tpl_vars['item']->value['id'] != '' || $_smarty_tpl->tpl_vars['type']->value == 'new') {?>
        <div class="modal-body">
            <div class="alert alert-primary" role="alert">
                <?php if ($_smarty_tpl->tpl_vars['type']->value == 'new') {
echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glnew');
} else {
echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glupdate');
}?> - <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'title');?>

            </div>

            <div class="form-group row">

                <div class="col-lg-12">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_descripcion');?>
 <span class="text-danger bold">*</span> :</label>
                    <input type="text" class="form-control"
                           name="item[descripcion]"
                           value="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['item']->value['descripcion'], ENT_QUOTES, 'UTF-8', true);?>
"
                           placeholder=""
                           required
                           data-fv-not-empty___message="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glFieldRequired');?>
"
                           minlength="3"
                           data-fv-string-length___message="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_length_descripcion');?>
"
                    >
                    <span class="form-text text-black-50"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_msg_descripcion');?>
</span>
                </div>
            </div>

            <div class="form-group row">
                <div class="col-lg-12">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_file');?>
 </label>
                    <div class="custom-file">
                        <input type="file" class="form-control custom-file-input"
                               placeholder="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_holder_file');?>
"
                               name="input_file" id="input_file"
                               accept="image/jpeg"
                                <?php if ($_smarty_tpl->tpl_vars['type']->value == 'new') {?>required<?php }?>
                               data-fv-not-empty___message="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glFieldRequired');?>
"
                        >
                        <label class="custom-file-label file-name" id="input_file_name" for="input_file"></label>
                    </div>

                        <span class="form-text text-black-50"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_msg_file');?>
</span>

                    <?php if ($_smarty_tpl->tpl_vars['item']->value['attached_name'] != '') {?>
                        <?php if ($_smarty_tpl->tpl_vars['type']->value == 'update') {?>
                            <strong>Archivo:</strong> <span class="m--font-success"><?php echo $_smarty_tpl->tpl_vars['item']->value['attached_name'];?>
</span>
                        <?php }?>
                    <?php }?>
                    </span>
                </div>

            </div>
        </div>

        <div class="modal-footer">
            <button type="button" class="btn btn-light-primary" id="form_close_<?php echo $_smarty_tpl->tpl_vars['subcontrol']->value;?>
" data-dismiss="modal"><i class="la la-angle-double-left"></i><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glBtnCloce');?>
</button>
            <button type="button" class="btn btn-primary font-weight-bold" id="form_submit_<?php echo $_smarty_tpl->tpl_vars['subcontrol']->value;?>
"><i class="la la-save"></i><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glBtnSave');?>
</button>
        </div>

    <?php } else { ?>
        <div class="modal-body">
            No existe el registro
        </div>

        <div class="modal-footer">
            <button type="button" class="btn btn-light-primary" id="form_close_<?php echo $_smarty_tpl->tpl_vars['subcontrol']->value;?>
" data-dismiss="modal"><i class="la la-angle-double-left"></i>Cerrar</button>
        </div>
    <?php }?>

</form>

<?php $_smarty_tpl->_subTemplateRender("file:form/form.js.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
