<?php
/* Smarty version 4.2.1, created on 2023-02-06 08:50:42
  from '/var/www/html/sib/webapp/app/sib/module/taxonomia_botanica/snippet/index/view/item/index.js.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_63e0f7a2e87597_19075914',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4bdfe7c19b78eeebf6604dde4e6270b949914603' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/taxonomia_botanica/snippet/index/view/item/index.js.tpl',
      1 => 1675456623,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_63e0f7a2e87597_19075914 (Smarty_Internal_Template $_smarty_tpl) {
echo '<script'; ?>
>
    var snippet_tab_item = function () {
        "use strict";
        var handler_tab_build = function(){
            coreUyuni.setTabs();
        };
        return {
            init: function() {
                handler_tab_build();
            }
        };
    }();

    jQuery(document).ready(function() {
        $('#btn_back').removeClass('d-none');
        snippet_tab_item.init();
        $('#<?php echo $_smarty_tpl->tpl_vars['menu_tab_active']->value;?>
_tab').trigger('click');
    });
<?php echo '</script'; ?>
>



<?php }
}
