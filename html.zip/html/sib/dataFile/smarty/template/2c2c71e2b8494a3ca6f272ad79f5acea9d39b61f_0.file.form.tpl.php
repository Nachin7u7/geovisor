<?php
/* Smarty version 4.2.1, created on 2023-01-20 09:04:51
  from '/var/www/html/sib/webapp/app/setting/module/app/snippet/group/view/form/form.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_63ca91735a78e4_07175914',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '2c2c71e2b8494a3ca6f272ad79f5acea9d39b61f' => 
    array (
      0 => '/var/www/html/sib/webapp/app/setting/module/app/snippet/group/view/form/form.tpl',
      1 => 1668028010,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:form/form.js.tpl' => 1,
  ),
),false)) {
function content_63ca91735a78e4_07175914 (Smarty_Internal_Template $_smarty_tpl) {
?><form method="POST"
      action="<?php echo $_smarty_tpl->tpl_vars['path_url']->value;?>
/<?php echo $_smarty_tpl->tpl_vars['subcontrol']->value;?>
_/<?php echo $_smarty_tpl->tpl_vars['item_id']->value;?>
/<?php if ($_smarty_tpl->tpl_vars['type']->value == "update") {
echo $_smarty_tpl->tpl_vars['id']->value;?>
/<?php }?>save/"
      id="form_<?php echo $_smarty_tpl->tpl_vars['subcontrol']->value;?>
">
    <?php if ($_smarty_tpl->tpl_vars['item']->value['id'] != '' || $_smarty_tpl->tpl_vars['type']->value == 'new') {?>
        <div class="modal-body">
            <div class="alert alert-primary" role="alert">
                <?php if ($_smarty_tpl->tpl_vars['type']->value == 'new') {
echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glnew');
} else {
echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glupdate');
}?> - <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'title');?>

            </div>

            <div class="form-group row">
                <div class="col-lg-7">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'fieldName');?>
 <span class="text-danger bold">*</span> :</label>
                    <div class="col-lg-12 ">
                        <input type="text" class="form-control"
                               name="item[name]"
                               value="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['item']->value['name'], ENT_QUOTES, 'UTF-8', true);?>
"
                               placeholder=""
                               required
                               data-fv-not-empty___message="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glFieldRequired');?>
"
                               minlength="3"
                               data-fv-string-length___message="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'fieldNameLength');?>
"
                        >
                        <span class="form-text text-black-50"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'fieldNameMsg');?>
</span>
                    </div>
                </div>

                <div class="col-lg-5">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'fielClass');?>
 :</label>
                    <div class="col-lg-12 ">
                        <div class="input-group">
                            <input type="text" class="form-control"
                                   name="item[class]" value="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['item']->value['class'], ENT_QUOTES, 'UTF-8', true);?>
"
                                   placeholder=""
                            >
                            <div class="input-group-prepend"><span class="input-group-text"><i class="fas fa-images text-primary"></i></span></div>
                        </div>
                        <span class="form-text text-black-50"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'fielClassMsg');?>
</span>
                    </div>
                </div>

                <div class="col-lg-3">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'fielOrder');?>
 <span class="text-danger bold">*</span>:</label>
                    <div class="col-lg-12 ">
                        <div class="input-group">
                            <input type="text" class="form-control number_integer"
                                   name="item[order]" value="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['item']->value['order'], ENT_QUOTES, 'UTF-8', true);?>
"
                                   required
                                   placeholder=""
                                   data-fv-not-empty___message="Required field"
                            >
                            <div class="input-group-prepend"><span class="input-group-text"><i class="ki ki-double-arrow-back text-primary"></i></span></div>
                        </div>
                        <span class="form-text text-black-50"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'fielOrderMsg');?>
</span>
                    </div>
                </div>

                <div class="col-lg-4">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'fieldActive');?>
:</label>
                    <div class="input-group">
                    <span class="switch switch-icon">
                        <label><input type="checkbox" <?php if ($_smarty_tpl->tpl_vars['item']->value['active'] == 1) {?>checked="checked"<?php }?> name="item[active]" value="1" id="active"><span></span></label>
                    </span>
                    </div>
                    <span class="form-text text-muted"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'fieldActiveMsg');?>
</span>
                </div>



                <div class="col-lg-12">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'fieldDescription');?>
 </label>
                    <div class="m-input-icon m-input-icon--right">
                        <div class="summernote" id="description"><?php echo $_smarty_tpl->tpl_vars['item']->value['description'];?>
</div>
                        <input class="form-control m-input" type="hidden" name="item[description]" id="description_input" <?php echo $_smarty_tpl->tpl_vars['privFace']->value['input'];?>
>
                    </div>
                </div>

            </div>
        </div>

        <div class="modal-footer">
            <button type="button" class="btn btn-light-primary" id="form_close_<?php echo $_smarty_tpl->tpl_vars['subcontrol']->value;?>
" data-dismiss="modal"><i class="la la-angle-double-left"></i><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glBtnCloce');?>
</button>
            <button type="button" class="btn btn-primary font-weight-bold" id="form_submit_<?php echo $_smarty_tpl->tpl_vars['subcontrol']->value;?>
"><i class="la la-save"></i><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glBtnSave');?>
</button>
        </div>

    <?php } else { ?>
        <div class="modal-body">
            No existe el registro
        </div>

        <div class="modal-footer">
            <button type="button" class="btn btn-light-primary" id="form_close_<?php echo $_smarty_tpl->tpl_vars['subcontrol']->value;?>
" data-dismiss="modal"><i class="la la-angle-double-left"></i>Cerrar</button>
        </div>
    <?php }?>

</form>

<?php $_smarty_tpl->_subTemplateRender("file:form/form.js.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
