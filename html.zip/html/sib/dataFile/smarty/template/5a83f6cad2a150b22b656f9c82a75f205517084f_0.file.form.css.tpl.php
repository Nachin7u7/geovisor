<?php
/* Smarty version 4.2.1, created on 2023-03-29 17:24:59
  from '/var/www/html/sib/webapp/app/sib/module/taxonomia_botanica/snippet/general/view/addorder/form.css.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_6424acab81c141_94882274',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '5a83f6cad2a150b22b656f9c82a75f205517084f' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/taxonomia_botanica/snippet/general/view/addorder/form.css.tpl',
      1 => 1680015874,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6424acab81c141_94882274 (Smarty_Internal_Template $_smarty_tpl) {
?>
    <style>

    </style>
<?php }
}
