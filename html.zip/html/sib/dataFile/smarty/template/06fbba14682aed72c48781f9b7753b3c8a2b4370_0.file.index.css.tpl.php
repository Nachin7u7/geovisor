<?php
/* Smarty version 4.2.1, created on 2023-09-20 09:13:09
  from '/var/www/html/sib/webapp/app/sib/module/zoologia_ormitologia/snippet/general/view/index.css.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_650aefe5bf9f82_48671226',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '06fbba14682aed72c48781f9b7753b3c8a2b4370' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/zoologia_ormitologia/snippet/general/view/index.css.tpl',
      1 => 1678278586,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_650aefe5bf9f82_48671226 (Smarty_Internal_Template $_smarty_tpl) {
?>
    <style>
        .select2-results__group{
            background: #e7f1f6;
            border-bottom: 2px solid #006ba2;
        }

        .proyecto{
            background: #c0deed;
            border-bottom: 1px solid #dfeff7;
            border-top: 1px solid #dfeff7;
        }
        .proyecto label{
            color: #059ded;
        }

    </style>
<?php }
}
