<?php
/* Smarty version 4.2.1, created on 2023-03-28 11:26:56
  from '/var/www/html/sib/webapp/app/sib/module/taxonomia_botanica/snippet/general/view/index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_642307406342e5_42590499',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '124923dac5f16a0edc8d8fa66febaa5f71a61d61' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/taxonomia_botanica/snippet/general/view/index.tpl',
      1 => 1680015874,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:index.css.tpl' => 1,
    'file:index.js.tpl' => 1,
  ),
),false)) {
function content_642307406342e5_42590499 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_checkPlugins(array(0=>array('file'=>'/var/www/html/sib/vendor/smarty/smarty/libs/plugins/function.html_options.php','function'=>'smarty_function_html_options',),));
$_smarty_tpl->_subTemplateRender("file:index.css.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
<div class="card card-custom gutter-b example example-compact">
    <div class="card-body pt-0 pb-0 pl-5 pr-5">
        <div class="alert alert-custom fade show pt-1 pb-1 pl-5 pr-5 ayuda" role="alert">
            <div class="alert-icon"><i class="flaticon-notes"></i></div>
            <div class="alert-text text-justify text-dark-65" ><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'message');?>
</div>
        </div>
    </div>

    <div class="card-header py-3">
        <div class="card-title">
            <span class="card-icon"><i class="flaticon2-next text-dark-25"></i></span>
            <h3 class="card-label text-dark-50"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'title');?>
</h3>
        </div>
    </div>
    <!--begin::Form-->
    <form method="POST"
          action="<?php echo $_smarty_tpl->tpl_vars['path_url']->value;?>
/<?php echo $_smarty_tpl->tpl_vars['subcontrol']->value;?>
_/<?php if ($_smarty_tpl->tpl_vars['type']->value == "update") {
echo $_smarty_tpl->tpl_vars['id']->value;?>
/<?php }?>save/"
          id="general_form">

        <div class="card-body">
            <div class="form-group row">
                <div class="col-lg-4">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_reino_id');?>
 <span class="text-danger bold">*</span> : </label>
                    <div class="input-group">
                        <select class="form-control m-select2 select2_general d-none"
                                name="item[kingdom_id]" id="kingdom_id"
                                data-placeholder="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_Holder_reino_id');?>
" <?php echo $_smarty_tpl->tpl_vars['privFace']->value['input'];?>

                                required
                                data-fv-not-empty___message="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glFieldRequired');?>
"
                        >
                            <option value=""></option>
                            <?php echo smarty_function_html_options(array('options'=>$_smarty_tpl->tpl_vars['cataobj']->value['kingdom'],'selected'=>1),$_smarty_tpl);?>

                        </select>
                    </div>
                    <span class="form-text text-black-50"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_GroupMsg_reino_id');?>
</span>
                </div>
                <div class="col-lg-4">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_division_id');?>
: </label>
                    <div class="input-group">
                        <select class="form-control m-select2 select2_general_phylum"
                                name="item[phylum_id]" id="phylum_id"
                                data-placeholder="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_Holder_filo_id');?>
" <?php echo $_smarty_tpl->tpl_vars['privFace']->value['input'];?>

                        >
                            <option value=""></option>
                            <?php echo smarty_function_html_options(array('options'=>$_smarty_tpl->tpl_vars['cataobj']->value['phylum'],'selected'=>$_smarty_tpl->tpl_vars['item']->value['phylum_id']),$_smarty_tpl);?>

                        </select>
                        <div class="input-group-append">
                            <button class="btn btn-success" id="phylum_btn" type="button">+</button>
                        </div>
                    </div>
                    <span class="form-text text-black-50"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_GroupMsg_division_id');?>
</span>
                </div>
                <div class="col-lg-4">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_clase_id');?>
 : </label>
                    <div class="input-group">
                        <select class="form-control m-select2 select2_general_class"
                                name="item[class_id]" id="class_id"
                                data-placeholder="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_Holder_clase_id');?>
" <?php echo $_smarty_tpl->tpl_vars['privFace']->value['input'];?>

                        >
                            <option></option>
                            <?php echo smarty_function_html_options(array('options'=>$_smarty_tpl->tpl_vars['cataobj']->value['class'],'selected'=>$_smarty_tpl->tpl_vars['item']->value['class_id']),$_smarty_tpl);?>

                        </select>
                        <div class="input-group-append">
                            <button class="btn btn-success" id="class_btn" type="button">+</button>
                        </div>
                    </div>
                    <span class="form-text text-black-50"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_GroupMsg_clase_id');?>
</span>
                </div>
                <div class="col-lg-4">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_orden_id');?>
: </label>
                    <div class="input-group">
                        <select class="form-control m-select2 select2_general_order"
                                name="item[order_id]" id="order_id"
                                data-placeholder="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_Holder_orden_id');?>
" <?php echo $_smarty_tpl->tpl_vars['privFace']->value['input'];?>

                        >
                            <option></option>
                            <?php echo smarty_function_html_options(array('options'=>$_smarty_tpl->tpl_vars['cataobj']->value['order'],'selected'=>$_smarty_tpl->tpl_vars['item']->value['order_id']),$_smarty_tpl);?>

                        </select>
                        <div class="input-group-append">
                            <button class="btn btn-success" id="order_btn" type="button">+</button>
                        </div>
                    </div>
                    <span class="form-text text-black-50"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_GroupMsg_orden_id');?>
</span>
                </div>
                <div class="col-lg-4">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_familia_id');?>
 : </label>
                    <div class="input-group">
                        <select class="form-control m-select2 select2_general_family"
                                name="item[family_id]" id="family_id"
                                data-placeholder="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_Holder_familia_id');?>
" <?php echo $_smarty_tpl->tpl_vars['privFace']->value['input'];?>

                        >
                            <option></option>
                            <?php echo smarty_function_html_options(array('options'=>$_smarty_tpl->tpl_vars['cataobj']->value['family'],'selected'=>$_smarty_tpl->tpl_vars['item']->value['family_id']),$_smarty_tpl);?>

                        </select>
                        <div class="input-group-append">
                            <button class="btn btn-success" id="family_btn" type="button">+</button>
                        </div>
                    </div>
                    <span class="form-text text-black-50"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_GroupMsg_familia_id');?>
</span>
                </div>
                <div class="col-lg-4">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_genero_id');?>
 : </label>
                    <div class="input-group">
                        <select class="form-control m-select2 select2_general_genus"
                                name="item[genus_id]" id="genus_id"
                                data-placeholder="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_Holder_genero_id');?>
" <?php echo $_smarty_tpl->tpl_vars['privFace']->value['input'];?>

                        >
                            <option></option>
                            <?php echo smarty_function_html_options(array('options'=>$_smarty_tpl->tpl_vars['cataobj']->value['genus'],'selected'=>$_smarty_tpl->tpl_vars['item']->value['genus_id']),$_smarty_tpl);?>

                        </select>
                        <div class="input-group-append">
                            <button class="btn btn-success" id="genus_btn" type="button">+</button>
                        </div>
                    </div>
                    <span class="form-text text-black-50"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_GroupMsg_genero_id');?>
</span>
                </div>
                <div class="col-lg-12">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'especie_field');?>
  <span class="text-danger bold">*</span> :</label>
                    <div class="input-group">
                        <input type="text" class="form-control"
                               name="item[species]" value="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['item']->value['species'], ENT_QUOTES, 'UTF-8', true);?>
"
                               required
                               data-fv-not-empty___message="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glFieldRequired');?>
"
                               minlength="3"
                               data-fv-string-length___message="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'especie_field_length');?>
"
                        >
                        <div class="input-group-append"><span class="input-group-text field_info"><i class="fas fa-otter"></i></span></div>
                    </div>
                    <span class="form-text text-black-50"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'especie_field_msg');?>
</span>
                </div>
                <div class="col-lg-12">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'nombre_cientifico_field');?>
  <span class="text-danger bold">*</span> :</label>
                    <div class="input-group">
                        <input type="text" class="form-control"
                               name="item[scientific_name]" value="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['item']->value['scientific_name'], ENT_QUOTES, 'UTF-8', true);?>
"
                               required
                               data-fv-not-empty___message="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glFieldRequired');?>
"
                               minlength="3"
                               data-fv-string-length___message="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'nombre_cientifico_field_length');?>
"
                        >
                        <div class="input-group-append"><span class="input-group-text field_info"><i class="fab fa-sistrix"></i></span></div>
                    </div>
                    <span class="form-text text-black-50"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'nombre_cientifico_field_msg');?>
</span>
                </div>
                <div class="col-lg-12">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'scientific_name_authorship_field');?>
:</label>
                    <div class="input-group">
                        <input type="text" class="form-control"
                               name="item[scientific_name_authorship]" value="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['item']->value['scientific_name_authorship'], ENT_QUOTES, 'UTF-8', true);?>
"
                               minlength="3"
                               data-fv-string-length___message="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'scientific_name_authorship_field_length');?>
"
                        >
                        <div class="input-group-append"><span class="input-group-text field_info"><i class="fas fa-user"></i></span></div>
                    </div>
                    <span class="form-text text-black-50"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'scientific_name_authorship_field_msg');?>
</span>
                </div>
            </div>
        </div>


        <div class="card-footer">
            <?php if ($_smarty_tpl->tpl_vars['privFace']->value['edit'] == 1) {?>
                <button type="reset" class="btn btn-primary mr-2" id="general_submit">
                    <i class="la la-save"></i>
                    <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glBtnSaveChanges');?>
</button>
            <?php }?>
            <a href="<?php echo $_smarty_tpl->tpl_vars['path_url']->value;?>
" class="btn btn-light-primary ">
                <i class="la la-angle-double-left"></i><?php if ($_smarty_tpl->tpl_vars['type']->value == "new") {?> <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glBtnCancel');?>
 <?php } else { ?> <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glBtnBackToList');
}?>
            </a>
        </div>

    </form>
    <!--end::Form-->
</div>

<!--begin::Modal-->
<div class="modal fade" id="form_modal_<?php echo $_smarty_tpl->tpl_vars['subcontrol']->value;?>
_peque"
     data-backdrop="static" tabindex="-1" role="dialog"
     aria-labelledby="staticBackdrop" aria-hidden="true"
     style="z-index:1044;"
>
    <div class="modal-dialog " role="document">
        <div class="modal-content " id="modal-content_<?php echo $_smarty_tpl->tpl_vars['subcontrol']->value;?>
_peque">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Modal Title</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <i aria-hidden="true" class="ki ki-close"></i>
                </button>
            </div>

        </div>
    </div>
</div>
<!--end::Modal-->
<?php $_smarty_tpl->_subTemplateRender("file:index.js.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
