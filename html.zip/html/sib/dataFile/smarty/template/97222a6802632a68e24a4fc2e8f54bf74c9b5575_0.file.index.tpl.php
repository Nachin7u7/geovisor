<?php
/* Smarty version 4.2.1, created on 2024-05-27 11:50:52
  from '/var/www/html/sib/webapp/app/sib/module/zoologia_invertebrado/snippet/datoscolecta/view/index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_6654abdc0543d4_64753254',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '97222a6802632a68e24a4fc2e8f54bf74c9b5575' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/zoologia_invertebrado/snippet/datoscolecta/view/index.tpl',
      1 => 1678278586,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:index.css.tpl' => 1,
    'file:index.js.tpl' => 1,
  ),
),false)) {
function content_6654abdc0543d4_64753254 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_checkPlugins(array(0=>array('file'=>'/var/www/html/sib/vendor/smarty/smarty/libs/plugins/modifier.date_format.php','function'=>'smarty_modifier_date_format',),));
$_smarty_tpl->_subTemplateRender("file:index.css.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
<div class="card card-custom gutter-b example example-compact">
    <div class="card-body pt-0 pb-0 pl-5 pr-5">
        <div class="alert alert-custom fade show pt-1 pb-1 pl-5 pr-5 ayuda" role="alert">
            <div class="alert-icon"><i class="flaticon-notes"></i></div>
            <div class="alert-text text-justify text-dark-65" ><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'message');?>
</div>
        </div>
    </div>

    <div class="card-header py-3">
        <div class="card-title">
            <span class="card-icon"><i class="flaticon2-next text-dark-25"></i></span>
            <h3 class="card-label text-dark-50"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'title');?>
</h3>
        </div>
    </div>
    <!--begin::Form-->
    <form method="POST"
          action="<?php echo $_smarty_tpl->tpl_vars['path_url']->value;?>
/<?php echo $_smarty_tpl->tpl_vars['subcontrol']->value;?>
_/<?php if ($_smarty_tpl->tpl_vars['type']->value == "update") {
echo $_smarty_tpl->tpl_vars['id']->value;?>
/<?php }?>save/"
          id="general_form">

        <div class="card-body">
            <div class="form-group row">
                <div class="col-lg-6">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_date');?>
:</label>
                    <div class="input-group">
                        <input type="text" class="form-control date_general" id="valid_until"
                               name="item[date]" value="<?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['item']->value['date'],'%d/%m/%Y');?>
"
                               data-fv-not-empty___message="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glFieldRequired');?>
"
                        >
                        <div class="input-group-append"><span class="input-group-text calendar"><i class="flaticon-event-calendar-symbol"></i></span></div>
                    </div>
                    <span class="form-text text-black-50"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_msg_date');?>
</span>
                </div>
                <div class="col-lg-6">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_verbatimEventDate');?>
:</label>
                    <div class="input-group">
                        <input type="text" class="form-control date_general" id="valid_until"
                               name="item[verbatim_event_date]" value="<?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['item']->value['verbatim_event_date'],'%d/%m/%Y');?>
"
                               data-fv-not-empty___message="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glFieldRequired');?>
"
                        >
                        <div class="input-group-append"><span class="input-group-text calendar"><i class="flaticon-event-calendar-symbol"></i></span></div>
                    </div>
                    <span class="form-text text-black-50"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_msg_verbatimEventDate');?>
</span>
                </div>
                <div class="col-lg-6">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_eventTime');?>
:</label>
                    <div class="input-group">
                        <input class="form-control" id="hora"
                               name="item[event_time]" value="<?php echo $_smarty_tpl->tpl_vars['item']->value['event_time'];?>
"
                               readonly="readonly" placeholder="Seleccione la hora" type="text"/>
                    </div>
                    <span class="form-text text-muted"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_msg_eventTime');?>
</span>
                </div>
                <div class="col-lg-6">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_fieldNumber');?>
:</label>
                    <div class="input-group">
                        <input type="text" class="form-control number_integer2"
                               name="item[field_number]" value="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['item']->value['field_number'], ENT_QUOTES, 'UTF-8', true);?>
"
                        >
                        <div class="input-group-append"><span class="input-group-text"><i class="fa fa-info"></i></span></div>
                    </div>
                    <span class="form-text text-muted"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_msg_fieldNumber');?>
</span>
                </div>
                <div class="col-lg-12">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_eventRemarks');?>
:</label>
                    <input type="text" class="form-control"
                           name="item[event_remarks]"
                           value="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['item']->value['event_remarks'], ENT_QUOTES, 'UTF-8', true);?>
"
                           minlength="3"
                           data-fv-string-length___message="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_length_eventRemarks');?>
"
                    >
                    <span class="form-text text-black-50"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_msg_eventRemarks');?>
</span>
                </div>
                <div class="col-lg-12">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_description_area_colecta');?>
:</label>
                    <input type="text" class="form-control"
                           name="item[description_area_colecta]"
                           value="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['item']->value['description_area_colecta'], ENT_QUOTES, 'UTF-8', true);?>
"
                           minlength="3"
                           data-fv-string-length___message="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_length_description_area_colecta');?>
"
                    >
                    <span class="form-text text-black-50"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_msg_description_area_colecta');?>
</span>
                </div>
                <div class="col-lg-12">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_colector_principal');?>
  <span class="text-danger bold">*</span> :</label>
                    <div class="input-group">
                        <input type="text" class="form-control"
                               name="item[colector_principal]" value="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['item']->value['colector_principal'], ENT_QUOTES, 'UTF-8', true);?>
"
                               required
                               data-fv-not-empty___message="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glFieldRequired');?>
"
                               minlength="3"
                               data-fv-string-length___message="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_length_colector_principal');?>
"
                        >
                        <div class="input-group-append"><span class="input-group-text field_info"><i class="far fa-user-circle"></i></span></div>
                    </div>
                    <span class="form-text text-black-50"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_msg_colector_principal');?>
</span>
                </div>
            </div>
        </div>


        <div class="card-footer">
            <?php if ($_smarty_tpl->tpl_vars['privFace']->value['edit'] == 1) {?>
                <button type="reset" class="btn btn-primary mr-2" id="general_submit">
                    <i class="la la-save"></i>
                    <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glBtnSaveChanges');?>
</button>
            <?php }?>
            <a href="<?php echo $_smarty_tpl->tpl_vars['path_url']->value;?>
" class="btn btn-light-primary ">
                <i class="la la-angle-double-left"></i><?php if ($_smarty_tpl->tpl_vars['type']->value == "new") {?> <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glBtnCancel');?>
 <?php } else { ?> <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glBtnBackToList');
}?>
            </a>
        </div>

    </form>
    <!--end::Form-->
</div>

<?php $_smarty_tpl->_subTemplateRender("file:index.js.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
