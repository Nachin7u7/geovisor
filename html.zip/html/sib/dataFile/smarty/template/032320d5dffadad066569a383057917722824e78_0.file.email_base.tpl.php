<?php
/* Smarty version 4.2.1, created on 2022-11-10 08:41:50
  from '/var/www/html/sib/webapp/app/core/template/email_core/email_base.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_636cf18ecf6eb7_65735122',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '032320d5dffadad066569a383057917722824e78' => 
    array (
      0 => '/var/www/html/sib/webapp/app/core/template/email_core/email_base.tpl',
      1 => 1668084031,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_636cf18ecf6eb7_65735122 (Smarty_Internal_Template $_smarty_tpl) {
?><div  style="width: 100%;margin: 0 auto;">
    <div style="width: 100%; min-height: 100vh;
  display: -webkit-box;  display: -webkit-flex;  display: -moz-box;  display: -ms-flexbox;  display: flex;  flex-wrap: wrap;
  justify-content: center;  align-items: center;  padding: 15px;  background: #f2f3f8;">
        <div style="width: 670px; background: #fff;  border-radius: 10px;  overflow: hidden;  position: relative;">


            <div style="width: 100%;position: relative;  z-index: 1;
            display: -webkit-box;  display: -webkit-flex;  display: -moz-box;  display: -ms-flexbox;
  display: flex;  flex-wrap: wrap;  flex-direction: column;  align-items: center;  background-repeat: no-repeat;
  background-size: cover; background-color:#202234;   background-position: center; " >
            <div style="text-align: center; padding: 10px; width: 100%;"><img src="cid:mmayaLogo" style="width: 152px;"></div>

            </div>

            <?php $_smarty_tpl->_subTemplateRender(((string)$_smarty_tpl->tpl_vars['subpage']->value), $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, true);
?>

            <div style="font-size: 13px; margin-top:50px;margin-bottom: 19px;width: 100%;text-align: center;font-family:'Roboto', Tahoma, Verdana, Segoe, sans-serif;">
                <div style='text-align: center;'>
                    <strong>
                        MUSEO NACIONAL<br>
                        DE HISTORIA NATURAL<br>
                    </strong>

                    Calle 26 de Cota, Cota (Ovidio Suárez)<br>
                    Tel&eacute;fono.: +591 (2) 2795364<br>
                    <a href='http://www.mnhn.gob.bo' target='_blank'>www.mnhn.gob.bo</a><br>
                    La Paz - Bolivia<br>
                </div>
            </div>
        </div>
    </div>
</div><?php }
}
