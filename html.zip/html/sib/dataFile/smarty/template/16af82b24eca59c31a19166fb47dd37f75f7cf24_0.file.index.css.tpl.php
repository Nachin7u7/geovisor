<?php
/* Smarty version 4.2.1, created on 2023-02-03 16:45:54
  from '/var/www/html/sib/webapp/app/sib/module/botanica/snippet/lugarcolecta/view/formprincipal/index.css.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_63dd728292a542_39553784',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '16af82b24eca59c31a19166fb47dd37f75f7cf24' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/botanica/snippet/lugarcolecta/view/formprincipal/index.css.tpl',
      1 => 1675456623,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_63dd728292a542_39553784 (Smarty_Internal_Template $_smarty_tpl) {
?>
    <style>
        .select2-results__group{
            background: #e7f1f6;
            border-bottom: 2px solid #006ba2;
        }
    </style>
<?php }
}
