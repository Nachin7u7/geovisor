<?php
/* Smarty version 4.2.1, created on 2023-03-02 08:38:05
  from '/var/www/html/sib/webapp/app/sib/module/zoologia_herpetologia/snippet/index/view/item/index.css.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_640098ad91a123_19765888',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '7c421161b78702174113e7d85d5b8d0fce38ac38' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/zoologia_herpetologia/snippet/index/view/item/index.css.tpl',
      1 => 1677146357,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_640098ad91a123_19765888 (Smarty_Internal_Template $_smarty_tpl) {
?><link rel="stylesheet" type="text/css" href="/js/geo/leaflet.1.7.1/leaflet.css"  />
<link rel="stylesheet" type="text/css" href="/js/geo/leaflet.fullscreen/Control.FullScreen.css" />
<link rel="stylesheet" type="text/css" href="/js/geo/leaflet.groupedlayercontrol/dist/leaflet.groupedlayercontrol.min.css" />

    <style>
    </style>
<?php }
}
