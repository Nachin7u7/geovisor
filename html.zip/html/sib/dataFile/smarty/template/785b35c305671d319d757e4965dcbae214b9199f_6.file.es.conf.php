<?php /* Smarty version 4.2.1, created on 2023-03-08 08:33:04
         compiled from '/var/www/html/sib/webapp/app/sib/module/zoologia_anfibios/snippet/general/language/es.conf' */ ?>
<?php
/* Smarty version 4.2.1, created on 2023-03-08 08:33:04
  from '/var/www/html/sib/webapp/app/sib/module/zoologia_anfibios/snippet/general/language/es.conf' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_6408808070c605_61523353',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '785b35c305671d319d757e4965dcbae214b9199f' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/zoologia_anfibios/snippet/general/language/es.conf',
      1 => 1678278586,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6408808070c605_61523353 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigVars($_smarty_tpl, array (
  'sections' => 
  array (
    'general' => 
    array (
      'vars' => 
      array (
        'title' => 'CARACTERISTICAS GENERALES DEL ESPECIMEN',
        'title2' => 'DATOS DE LA INSTITUCIÓN',
        'message' => 'Se podrá realizar el registro los datos iniciales del especimen',
        'field_tipo_id' => 'Tipo de institución',
        'field_Holder_tipo_id' => 'Seleccione una opción',
        'field_GroupMsg_tipo_id' => 'Seleccione el tipo de institución',
        'occurrence_id_field' => 'ID del Registro biológico',
        'occurrence_id_field_length' => 'Tiene que ser mayor o igual a 3 caracteres',
        'occurrence_id_field_msg' => 'Ingrese un identificador único del registro biológico',
        'recorded_by_field' => 'Registrado por',
        'recorded_by_field_length' => 'Tiene que ser mayor o igual a 3 caracteres',
        'recorded_by_field_msg' => 'Ingrese al colector u observador principal. Una lista (en una fila continua y separada por una barra vertical " | ") de los nombres de las personas (observadores o recolectores) responsables de realizar el registro.',
        'field_occurrence_id' => 'ID del registro biológico',
        'field_msg_occurrence_id' => 'Ingrese el ID del registro biológico',
        'field_basis_of_record' => 'Base del registro',
        'field_msg_basis_of_record' => 'Ingrese la base del registro',
        'field_type' => 'Tipo',
        'field_length_type' => 'Tiene que ser mayor o igual a 3 caracteres',
        'field_msg_type' => 'Ingrese el tipo',
        'field_institution_id' => 'Institución',
        'field_Holder_institution_id' => 'Seleccione una opción',
        'field_GroupMsg_institution_id' => 'Seleccione la institución',
        'field_institucion_code' => 'Código de la institucion',
        'field_msg_institution_code' => 'Ingrese el código de la institucion',
        'field_collection_code' => 'Código de la colección',
        'field_msg_collection_code' => 'Ingrese el código de la colección',
        'field_collection_id' => 'ID de la colección',
        'field_msg_collection_id' => 'Ingrese el ID de la colección',
        'field_catalog_number' => 'Número de catálogo CBF',
        'field_msg_catalog_number' => 'Ingrese el número de catálogo CBF',
        'field_language_id' => 'Idioma',
        'field_Holder_language_id' => 'Seleccione una opción',
        'field_GroupMsg_language_id' => 'Seleccione el idioma',
        'field_license_id' => 'Derechos',
        'field_Holder_license_id' => 'Seleccione una opción',
        'field_GroupMsg_license_id' => 'Seleccione el derecho',
        'field_rights_holder' => 'Titular de los derechos',
        'field_length_rights_holder' => 'Tiene que ser mayor o igual a 3 caracteres',
        'field_msg_rights_holder' => 'Ingrese el titular de los derechos',
        'field_access_rights' => 'Derechos de acceso',
        'field_length_access_rights' => 'Tiene que ser mayor o igual a 3 caracteres',
        'field_msg_access_rights' => 'Ingrese los derechos de acceso',
        'field_information_withheld' => 'Información retenida',
        'field_length_information_withheld' => 'Tiene que ser mayor o igual a 3 caracteres',
        'field_msg_information_withheld' => 'Ingrese la información retenida',
        'field_recorded_by' => 'Registrado por',
        'field_length_recorded_by' => 'Tiene que ser mayor o igual a 3 caracteres',
        'field_msg_recorded_by' => 'Ingrese por quien fue registrado',
        'field_individual_count' => 'Número de individuos',
        'field_msg_individual_count' => 'Ingrese el número de individuos',
        'field_sex_id' => 'Sexo',
        'field_Holder_sex_id' => 'Seleccione una opción',
        'field_GroupMsg_sex_id' => 'Seleccione el Sexo',
        'field_life_stage_id' => 'Etapa de vida',
        'field_Holder_life_stage_id' => 'Seleccione una opción',
        'field_GroupMsg_life_stage_id' => 'Seleccione la etapa de vida',
        'field_preparations_id' => 'Preparaciones',
        'field_Holder_preparations_id' => 'Seleccione una opción',
        'field_GroupMsg_preparations_id' => 'Seleccione la preparación',
        'field_occurrence_status_id' => 'Estado del registro biológico',
        'field_Holder_occurrence_status_id' => 'Seleccione una opción',
        'field_GroupMsg_occurrence_status_id' => 'Seleccione el estado del registro biológico',
        'field_disposition' => 'Disposición',
        'field_length_disposition' => 'Tiene que ser mayor o igual a 3 caracteres',
        'field_msg_disposition' => 'Ingrese la disposición',
        'field_event_id' => 'ID del evento',
        'field_msg_event_id' => 'Ingrese el ID del evento',
        'field_sampling_protocol' => 'Protocolo de muestreo',
        'field_msg_sampling_protocol' => 'Protocolo de muestreo',
        'field_occurrence_remarks' => 'Comentarios del registro biológico',
      ),
    ),
    'form' => 
    array (
      'vars' => 
      array (
        'title1' => 'INFORMACIÓN GENERAL DE LA TAXONOMIA BOTANICA',
      ),
    ),
  ),
  'vars' => 
  array (
  ),
));
}
}
