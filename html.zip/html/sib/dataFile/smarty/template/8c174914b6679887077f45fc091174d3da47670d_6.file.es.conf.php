<?php /* Smarty version 4.2.1, created on 2023-01-10 11:32:04
         compiled from '/var/www/html/sib/webapp/app/setting/module/app/snippet/general/language/es.conf' */ ?>
<?php
/* Smarty version 4.2.1, created on 2023-01-10 11:32:04
  from '/var/www/html/sib/webapp/app/setting/module/app/snippet/general/language/es.conf' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_63bd84f4108483_79830124',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '8c174914b6679887077f45fc091174d3da47670d' => 
    array (
      0 => '/var/www/html/sib/webapp/app/setting/module/app/snippet/general/language/es.conf',
      1 => 1668028010,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_63bd84f4108483_79830124 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigVars($_smarty_tpl, array (
  'sections' => 
  array (
    'general' => 
    array (
      'vars' => 
      array (
        'fieldActivoName' => 'Activo',
        'fieldActivoMsg' => 'Poder activar o desactivar la aplicación para su funcionamiento',
        'title' => 'Datos de la Aplicación',
        'message' => 'Podrás realizar el registro y configuración de una aplicación para el FrameWork Uyuni',
        'fieldGroup' => 'Grupo',
        'fieldGroupHolder' => 'Elija Submódulo',
        'fieldGroupMsg' => 'Seleccione el grúpo al que pertenece',
        'fieldTituloName' => 'Nombre',
        'fieldTituloLength' => 'Tiene que ser mayor o igual a 3 caracteres',
        'fieldTituloMsg' => 'Ingrese el nombre de la aplicación',
        'fieldFolderName' => 'Nombre de la carpeta',
        'fieldFolderLength' => 'Tiene que ser mayor o igual a 3 caracteres',
        'fieldFolderMsg' => 'Ingrese el nombre de la carpeta que se creará dentro la carpeta <strong>"module"</strong>',
        'fieldActiveName' => 'Activo',
        'fieldActiveMsg' => 'Activiar o desactivar la aplicación, para su funcionamiento',
        'fieldDescripcionName' => 'Descripción',
        'fielClass' => 'Icono - Class',
        'fielClassMsg' => 'Ingrese la "clase" del ícono (CSS)',
        'fieldPrivateName' => 'Privado',
        'fieldPrivateMsg' => 'Si la aplicación es Privada',
        'fieldHideName' => 'Ocultar',
        'fieldHideMsg' => 'Ocultar la aplicación en el menu',
        'fielOrder' => 'Orden',
        'fielOrderMsg' => 'Ingrese el número de posición',
        'fieldTarget' => 'Abrir en nueva ventana',
        'fieldTargetMsg' => 'Permite abrir el módulo o url en otra ventana',
        'fielType' => 'Tipo',
        'fielTypeHolder' => 'Elija un tipo',
        'fielUrl' => 'URL',
        'fielUrlMsg' => 'Ingrese la URL',
        'OptApp' => 'Aplicación',
        'OptUrl' => 'Url',
      ),
    ),
    'form' => 
    array (
      'vars' => 
      array (
        'title' => 'Datos de la Aplicación2 22 22',
      ),
    ),
  ),
  'vars' => 
  array (
  ),
));
}
}
