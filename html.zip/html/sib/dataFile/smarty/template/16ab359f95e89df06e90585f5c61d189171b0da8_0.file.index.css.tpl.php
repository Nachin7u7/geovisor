<?php
/* Smarty version 4.2.1, created on 2023-09-20 09:13:08
  from '/var/www/html/sib/webapp/app/sib/module/zoologia_ormitologia/snippet/index/view/item/index.css.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_650aefe48aa8e4_64505943',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '16ab359f95e89df06e90585f5c61d189171b0da8' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/zoologia_ormitologia/snippet/index/view/item/index.css.tpl',
      1 => 1678278586,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_650aefe48aa8e4_64505943 (Smarty_Internal_Template $_smarty_tpl) {
?><link rel="stylesheet" type="text/css" href="/js/geo/leaflet.1.7.1/leaflet.css"  />
<link rel="stylesheet" type="text/css" href="/js/geo/leaflet.fullscreen/Control.FullScreen.css" />
<link rel="stylesheet" type="text/css" href="/js/geo/leaflet.groupedlayercontrol/dist/leaflet.groupedlayercontrol.min.css" />

    <style>
    </style>
<?php }
}
