<?php
/* Smarty version 4.2.1, created on 2023-09-20 09:13:25
  from '/var/www/html/sib/webapp/app/sib/module/zoologia_ormitologia/snippet/taxonomia/view/index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_650aeff5a90e48_11390614',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '085f1d02f02700002538e70727660903f627e90b' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/zoologia_ormitologia/snippet/taxonomia/view/index.tpl',
      1 => 1688391178,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:index.css.tpl' => 1,
    'file:index.js.tpl' => 1,
  ),
),false)) {
function content_650aeff5a90e48_11390614 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_checkPlugins(array(0=>array('file'=>'/var/www/html/sib/vendor/smarty/smarty/libs/plugins/function.html_options.php','function'=>'smarty_function_html_options',),));
$_smarty_tpl->_subTemplateRender("file:index.css.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
<div class="card card-custom gutter-b example example-compact">
    <div class="card-body pt-0 pb-0 pl-5 pr-5">
        <div class="alert alert-custom fade show pt-1 pb-1 pl-5 pr-5 ayuda" role="alert">
            <div class="alert-icon"><i class="flaticon-notes"></i></div>
            <div class="alert-text text-justify text-dark-65" ><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'message');?>
</div>
        </div>
    </div>

    <div class="card-header py-3">
        <div class="card-title">
            <span class="card-icon"><i class="flaticon2-next text-dark-25"></i></span>
            <h3 class="card-label text-dark-50"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'title');?>
</h3>
        </div>
    </div>
    <!--begin::Form-->
    <form method="POST"
          action="<?php echo $_smarty_tpl->tpl_vars['path_url']->value;?>
/<?php echo $_smarty_tpl->tpl_vars['subcontrol']->value;?>
_/<?php if ($_smarty_tpl->tpl_vars['type']->value == "update") {
echo $_smarty_tpl->tpl_vars['id']->value;?>
/<?php }?>save/"
          id="general_form">

        <div class="card-body">
            <div class="form-group row">
                <div class="col-lg-12">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_identified_by');?>
<span class="text-danger bold">*</span> :</label>
                    <div class="input-group">
                        <input type="text" class="form-control"
                               name="item[identified_by]"
                               value="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['item']->value['identified_by'], ENT_QUOTES, 'UTF-8', true);?>
"
                               required
                               data-fv-not-empty___message="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glFieldRequired');?>
"
                               minlength="3"
                               data-fv-string-length___message="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_length_identified_by');?>
"
                        >
                        <div class="input-group-append"><span class="input-group-text field_info"><i class="far fa-user"></i></span></div>
                    </div>
                    <span class="form-text text-black-50"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_msg_identified_by');?>
</span>
                </div>
                <div class="col-lg-6">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_type_status');?>
 :</label>
                    <div class="input-group">
                        <input type="text" class="form-control"
                               name="item[type_status]"
                               value="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['item']->value['type_status'], ENT_QUOTES, 'UTF-8', true);?>
"
                               minlength="3"
                               data-fv-string-length___message="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_length_type_status');?>
"
                        >
                        <div class="input-group-append"><span class="input-group-text field_info"><i class="fab fa-centercode"></i></span></div>
                    </div>
                    <span class="form-text text-black-50"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_msg_type_status');?>
</span>
                </div>
                <div class="col-lg-6">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_identification_qualifier');?>
 :</label>
                    <div class="input-group">
                        <input type="text" class="form-control"
                               name="item[identification_qualifier]"
                               value="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['item']->value['identification_qualifier'], ENT_QUOTES, 'UTF-8', true);?>
"
                               minlength="3"
                               data-fv-string-length___message="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_length_identification_qualifier');?>
"
                        >
                        <div class="input-group-append"><span class="input-group-text field_info"><i class="fas fa-user-edit"></i></span></div>
                    </div>
                    <span class="form-text text-black-50"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_msg_identification_qualifier');?>
</span>
                </div>
                <div class="col-lg-6">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_scientific_name');?>
: </label>
                    <div class="input-group">
                        <select class="form-control m-select2 select2_general"
                                name="item[catalogo_taxonomia_id]"
                                id="catalogo_taxonomia_id"
                                data-placeholder="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_Holder_scientific_name');?>
" <?php echo $_smarty_tpl->tpl_vars['privFace']->value['input'];?>

                        >
                            <option></option>
                            <?php echo smarty_function_html_options(array('options'=>$_smarty_tpl->tpl_vars['cataobj']->value['taxonomia'],'selected'=>$_smarty_tpl->tpl_vars['item']->value['catalogo_taxonomia_id']),$_smarty_tpl);?>

                        </select>
                    </div>
                    <span class="form-text text-black-50"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_GroupMsg_scientific_name');?>
</span>
                </div>

                <div class="col-lg-6" id="scientific_name_authorship_s">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_scientific_name_authorship');?>
<span class="text-danger bold">*</span> :</label>
                    <div class="input-group">
                        <input type="text" class="form-control"
                               name="item[scientific_name_authorship]"
                               id="scientific_name_authorship"
                               value="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['item']->value['scientific_name_authorship'], ENT_QUOTES, 'UTF-8', true);?>
"
                               required
                               data-fv-not-empty___message="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glFieldRequired');?>
"
                               minlength="3"
                               data-fv-string-length___message="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_length_scientific_name_authorship');?>
"
                        >
                        <div class="input-group-append"><span class="input-group-text field_info"><i class="far fa-user"></i></span></div>
                    </div>
                    <span class="form-text text-black-50"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_msg_scientific_name_authorship');?>
</span>
                </div>

                <div class="col-lg-4" id="kingdom_s">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_kingdom');?>
:</label>
                    <div class="input-group">
                        <input type="text" class="form-control"
                               name="item[kingdom]" id="kingdom"
                               value="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['item']->value['kingdom'], ENT_QUOTES, 'UTF-8', true);?>
"
                        >
                        <div class="input-group-append"><span class="input-group-text"><i class="fa fa-info"></i></span></div>
                    </div>
                                    </div>
                <div class="col-lg-4" id="class_s">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_class');?>
:</label>
                    <div class="input-group">
                        <input type="text" class="form-control"
                               name="item[class]" id="class"
                               value="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['item']->value['class'], ENT_QUOTES, 'UTF-8', true);?>
"
                        >
                        <div class="input-group-append"><span class="input-group-text"><i class="fa fa-info"></i></span></div>
                    </div>
                                    </div>
                <div class="col-lg-4" id="order_s">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_order');?>
:</label>
                    <div class="input-group">
                        <input type="text" class="form-control"
                               name="item[order]" id="order"
                               value="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['item']->value['order'], ENT_QUOTES, 'UTF-8', true);?>
"
                        >
                        <div class="input-group-append"><span class="input-group-text"><i class="fa fa-info"></i></span></div>
                    </div>
                                    </div>
                <div class="col-lg-4" id="family_s">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_family');?>
:</label>
                    <div class="input-group">
                        <input type="text" class="form-control"
                               name="item[family]" id="family"
                               value="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['item']->value['family'], ENT_QUOTES, 'UTF-8', true);?>
"
                        >
                        <div class="input-group-append"><span class="input-group-text"><i class="fa fa-info"></i></span></div>
                    </div>
                                    </div>
                <div class="col-lg-4" id="genus_s">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_genus');?>
:</label>
                    <div class="input-group">
                        <input type="text" class="form-control"
                               name="item[genus]" id="genus"
                               value="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['item']->value['genus'], ENT_QUOTES, 'UTF-8', true);?>
"
                        >
                        <div class="input-group-append"><span class="input-group-text"><i class="fa fa-info"></i></span></div>
                    </div>
                                    </div>
                <div class="col-lg-4">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_specific_epithet');?>
:</label>
                    <div class="input-group">
                        <input type="text" class="form-control"
                               name="item[specific_epithet]" id="specific_epithet"
                               value="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['item']->value['specific_epithet'], ENT_QUOTES, 'UTF-8', true);?>
"
                               minlength="3"
                               data-fv-string-length___message="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_length_specific_epithet');?>
"
                        >
                        <div class="input-group-append"><span class="input-group-text"><i class="fa fa-info"></i></span></div>
                    </div>
                    <span class="form-text text-black-50"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_msg_specific_epithet');?>
</span>
                </div>
                <div class="col-lg-4">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_vernacular_name');?>
:</label>
                    <div class="input-group">
                        <input type="text" class="form-control"
                               name="item[vernacular_name]" id="vernacular_name"
                               value="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['item']->value['vernacular_name'], ENT_QUOTES, 'UTF-8', true);?>
"
                               minlength="3"
                               data-fv-string-length___message="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_length_vernacular_name');?>
"
                        >
                        <div class="input-group-append"><span class="input-group-text"><i class="fa fa-info"></i></span></div>
                    </div>
                    <span class="form-text text-black-50"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_msg_vernacular_name');?>
</span>
                </div>
                <div class="col-lg-4">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_taxon_rank');?>
:</label>
                    <div class="input-group">
                        <input type="text" class="form-control"
                               name="item[taxon_rank]" id="taxon_rank"
                               value="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['item']->value['taxon_rank'], ENT_QUOTES, 'UTF-8', true);?>
"
                               minlength="3"
                               data-fv-string-length___message="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_length_taxon_rank');?>
"
                        >
                        <div class="input-group-append"><span class="input-group-text"><i class="fa fa-info"></i></span></div>
                    </div>
                    <span class="form-text text-black-50"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'field_msg_taxon_rank');?>
</span>
                </div>
            </div>
        </div>


        <div class="card-footer">
            <?php if ($_smarty_tpl->tpl_vars['privFace']->value['edit'] == 1) {?>
                <button type="reset" class="btn btn-primary mr-2" id="general_submit">
                    <i class="la la-save"></i>
                    <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glBtnSaveChanges');?>
</button>
            <?php }?>
            <a href="<?php echo $_smarty_tpl->tpl_vars['path_url']->value;?>
" class="btn btn-light-primary ">
                <i class="la la-angle-double-left"></i><?php if ($_smarty_tpl->tpl_vars['type']->value == "new") {?> <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glBtnCancel');?>
 <?php } else { ?> <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'glBtnBackToList');
}?>
            </a>
        </div>

    </form>
    <!--end::Form-->
</div>

<?php $_smarty_tpl->_subTemplateRender("file:index.js.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
