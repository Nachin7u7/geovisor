<?php
/* Smarty version 4.2.1, created on 2023-07-03 09:47:26
  from '/var/www/html/sib/webapp/app/sib/module/institucion/snippet/index/view/item/index.css.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_64a2d16e0c3060_61560651',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '5d44a93f75f92b9cdd32e2d231a677635a7ab79a' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/institucion/snippet/index/view/item/index.css.tpl',
      1 => 1676393396,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_64a2d16e0c3060_61560651 (Smarty_Internal_Template $_smarty_tpl) {
?><link rel="stylesheet" type="text/css" href="/js/geo/leaflet.1.7.1/leaflet.css"  />
<link rel="stylesheet" type="text/css" href="/js/geo/leaflet.fullscreen/Control.FullScreen.css" />
<link rel="stylesheet" type="text/css" href="/js/geo/leaflet.groupedlayercontrol/dist/leaflet.groupedlayercontrol.min.css" />

    <style>
    </style>
<?php }
}
