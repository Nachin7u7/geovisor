<?php
/* Smarty version 4.2.1, created on 2023-02-14 13:04:14
  from '/var/www/html/sib/webapp/app/sib/module/botanica/snippet/general/view/index.css.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_63ebbf0e62e235_70424069',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '643ecaac1a879a43b5d96558b7f3df25c3203306' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/botanica/snippet/general/view/index.css.tpl',
      1 => 1676393396,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_63ebbf0e62e235_70424069 (Smarty_Internal_Template $_smarty_tpl) {
?>
    <style>
        .select2-results__group{
            background: #e7f1f6;
            border-bottom: 2px solid #006ba2;
        }

        .proyecto{
            background: #c0deed;
            border-bottom: 1px solid #dfeff7;
            border-top: 1px solid #dfeff7;
        }
        .proyecto label{
            color: #059ded;
        }

    </style>
<?php }
}
