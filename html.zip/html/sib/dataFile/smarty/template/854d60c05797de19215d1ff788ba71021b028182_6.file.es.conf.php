<?php /* Smarty version 4.2.1, created on 2023-03-01 14:09:43
         compiled from '/var/www/html/sib/webapp/app/sib/module/botanica/snippet/preparador/language/es.conf' */ ?>
<?php
/* Smarty version 4.2.1, created on 2023-03-01 14:09:43
  from '/var/www/html/sib/webapp/app/sib/module/botanica/snippet/preparador/language/es.conf' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_63ff94e772d1c9_76044869',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '854d60c05797de19215d1ff788ba71021b028182' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/botanica/snippet/preparador/language/es.conf',
      1 => 1677671930,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_63ff94e772d1c9_76044869 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigVars($_smarty_tpl, array (
  'sections' => 
  array (
    'index' => 
    array (
      'vars' => 
      array (
        'title' => 'Preparadores',
        'message' => '<strong>Adicionar preparador</strong><br> Haga clic en el boton <strong>"Adicionar preparador"</strong> para registrar un nuevo preparador.',
        'btnNew' => 'Adicionar preparador',
        'dataTableExportTitle' => 'Preparadores',
      ),
    ),
    'tableIndex' => 
    array (
      'vars' => 
      array (
        'table_nombre' => 'Nombres y apellidos',
      ),
    ),
    'formItem' => 
    array (
      'vars' => 
      array (
        'title' => 'Registrar Preparador',
        'message' => 'Podrás registrar un nuevo preparador',
        'field_nombre' => 'Nombres y apellidos',
        'field_length_nombre' => 'Tiene que ser mayor o igual a 3 caracteres',
        'field_msg_nombre' => 'Ingrese los nombres y apellidos',
      ),
    ),
  ),
  'vars' => 
  array (
  ),
));
}
}
