<?php /* Smarty version 4.2.1, created on 2023-09-06 10:10:55
         compiled from '/var/www/html/sib/webapp/app/sib/module/taxonomia_botanica/snippet/general/language/es.conf' */ ?>
<?php
/* Smarty version 4.2.1, created on 2023-09-06 10:10:55
  from '/var/www/html/sib/webapp/app/sib/module/taxonomia_botanica/snippet/general/language/es.conf' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_64f8886f8c6a76_93044072',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '89d0eeb64af317d41ffb8328326b9f336daf290d' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/taxonomia_botanica/snippet/general/language/es.conf',
      1 => 1681417417,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_64f8886f8c6a76_93044072 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigVars($_smarty_tpl, array (
  'sections' => 
  array (
    'general' => 
    array (
      'vars' => 
      array (
        'title' => 'CARACTERISTICAS GENERALES DE LA TAXONOMIA',
        'message' => 'Se podra realizar el registro los datos iniciales de la taxonomia',
        'field_reino_id' => 'Reino',
        'field_Holder_reino_id' => 'Seleccione una opción',
        'field_GroupMsg_reino_id' => 'Seleccione el reino',
        'field_division_id' => 'Division',
        'field_Holder_division_id' => 'Seleccione una opción',
        'field_GroupMsg_division_id' => 'Seleccione el division',
        'field_orden_id' => 'Orden',
        'field_Holder_orden_id' => 'Seleccione una opción',
        'field_GroupMsg_orden_id' => 'Seleccione el orden',
        'field_familia_id' => 'Familia',
        'field_Holder_familia_id' => 'Seleccione una opción',
        'field_GroupMsg_familia_id' => 'Seleccione el familia',
        'field_genero_id' => 'Género',
        'field_Holder_genero_id' => 'Seleccione una opción',
        'field_GroupMsg_genero_id' => 'Seleccione el genero',
        'field_especie_id' => 'Especie',
        'field_Holder_especie_id' => 'Seleccione una opción',
        'field_GroupMsg_especie_id' => 'Seleccione el especie',
        'field_filo_id' => 'Filo',
        'field_Holder_filo_id' => 'Seleccione una opción',
        'field_GroupMsg_filo_id' => 'Seleccione el filo',
        'field_clase_id' => 'Clase',
        'field_Holder_clase_id' => 'Seleccione una opción',
        'field_GroupMsg_clase_id' => 'Seleccione el clase',
        'field_tipo_nomenclatura_id' => 'Tipo nomenclatura',
        'field_Holder_tipo_nomenclatura_id' => 'Seleccione una opción',
        'field_GroupMsg_tipo_nomenclatura_id' => 'Seleccione el tipo nomenclatura',
        'field_categoria_taxon_id' => 'Categoria taxon',
        'field_Holder_categoria_taxon_id' => 'Seleccione una opción',
        'field_GroupMsg_categoria_taxon_id' => 'Seleccione el categoria taxon',
        'field_epiteto_id' => 'Epiteto',
        'field_Holder_epiteto_id' => 'Seleccione una opción',
        'field_GroupMsg_epiteto_id' => 'Seleccione el epiteto',
        'especie_field' => 'Especie',
        'especie_field_length' => 'Tiene que ser mayor o igual a 3 caracteres',
        'especie_field_msg' => 'Ingrese la especie',
        'nombre_cientifico_field' => 'Nombre cientifico',
        'nombre_cientifico_field_length' => 'Tiene que ser mayor o igual a 3 caracteres',
        'nombre_cientifico_field_msg' => 'Ingrese el nombre cientifico',
        'scientific_name_authorship_field' => 'Autor del nombre científico',
        'scientific_name_authorship_field_length' => 'Tiene que ser mayor o igual a 3 caracteres',
        'scientific_name_authorship_field_msg' => 'Ingrese el autor del nombre científico',
      ),
    ),
    'formItemAddPhylum' => 
    array (
      'vars' => 
      array (
        'title' => 'Filo',
        'field_nombre' => 'Nombre del filo',
        'field_msg_nombre' => 'Ingrese el nombre del filo',
      ),
    ),
    'formItemAddClass' => 
    array (
      'vars' => 
      array (
        'title' => 'Clase',
        'field_nombre' => 'Nombre de la clase',
        'field_msg_nombre' => 'Ingrese el nombre de la clase',
      ),
    ),
    'formItemAddOrder' => 
    array (
      'vars' => 
      array (
        'title' => 'Orden',
        'field_nombre' => 'Nombre del orden',
        'field_msg_nombre' => 'Ingrese el nombre del orden',
      ),
    ),
    'formItemAddFamily' => 
    array (
      'vars' => 
      array (
        'title' => 'Familia',
        'field_nombre' => 'Nombre de la familia',
        'field_msg_nombre' => 'Ingrese el nombre de la familia',
      ),
    ),
    'formItemAddGenus' => 
    array (
      'vars' => 
      array (
        'title' => 'Género',
        'field_nombre' => 'Nombre del género',
        'field_msg_nombre' => 'Ingrese el nombre del género',
      ),
    ),
    'form' => 
    array (
      'vars' => 
      array (
        'title1' => 'INFORMACIÓN GENERAL DEL CATALOGO',
      ),
    ),
  ),
  'vars' => 
  array (
  ),
));
}
}
