<?php /* Smarty version 4.2.1, created on 2022-11-10 11:06:30
         compiled from '/var/www/html/sib/webapp/app/setting/module/user/snippet/index/language/es.conf' */ ?>
<?php
/* Smarty version 4.2.1, created on 2022-11-10 11:06:30
  from '/var/www/html/sib/webapp/app/setting/module/user/snippet/index/language/es.conf' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_636d13768e8977_36070627',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a56f336bb6c7f0d36c20e2a3cdd157065e67e47f' => 
    array (
      0 => '/var/www/html/sib/webapp/app/setting/module/user/snippet/index/language/es.conf',
      1 => 1668028010,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_636d13768e8977_36070627 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigVars($_smarty_tpl, array (
  'sections' => 
  array (
    'index' => 
    array (
      'vars' => 
      array (
        'title' => 'Gestión de usuarios',
        'btnNew' => 'Nuevo usuario',
        'filterName' => 'Buscar por Nombre',
        'filterLastName' => 'Buscar por Apellido',
        'filterType' => 'Buscar por tipo de usuario',
        'filterHolderType' => 'Seleccione',
        'filterAppStatusSelectAll' => 'Todos los tipos',
        'dataTableExportTitle' => 'Lista de usuario',
        'opt_typeuser_1' => 'Administrador',
        'opt_typeuser_2' => 'Normal',
      ),
    ),
    'tableIndex' => 
    array (
      'vars' => 
      array (
        'table_name' => 'Nombre',
        'table_name_last' => 'Apellido',
        'table_usernme' => 'Usuario',
        'table_mobile' => 'Número celular',
        'table_type' => 'Tipo de Usuario',
        'table_status' => 'Estado',
      ),
    ),
    'item' => 
    array (
      'vars' => 
      array (
        'fieldActive' => 'Activo',
        'title' => 'Gestión de usuarios',
      ),
    ),
    'tabItem' => 
    array (
      'vars' => 
      array (
        'tab_general' => 'General',
        'tab_permits' => 'Permisos',
      ),
    ),
  ),
  'vars' => 
  array (
  ),
));
}
}
