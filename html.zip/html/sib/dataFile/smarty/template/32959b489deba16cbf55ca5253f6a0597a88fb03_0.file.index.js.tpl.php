<?php
/* Smarty version 4.2.1, created on 2023-03-02 08:38:06
  from '/var/www/html/sib/webapp/app/sib/module/zoologia_herpetologia/snippet/taxonomia/view/index.js.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_640098ae718a96_72956397',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '32959b489deba16cbf55ca5253f6a0597a88fb03' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/zoologia_herpetologia/snippet/taxonomia/view/index.js.tpl',
      1 => 1677146357,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_640098ae718a96_72956397 (Smarty_Internal_Template $_smarty_tpl) {
echo '<script'; ?>
>
    var snippet_general_form = function(){
        "use strict";
        /**
         * Datos del formulario y el boton
         */
        let urlmodule = "<?php echo $_smarty_tpl->tpl_vars['path_url']->value;?>
/<?php echo $_smarty_tpl->tpl_vars['subcontrol']->value;?>
_";
        var form = $('#general_form');
        var btn_submit = $('#general_submit');

        var formv;
        /**
         * Antes de enviar el formulario se ejecuta la siguiente funcion
         */
        var showRequest= function(formData, jqForm, op)  {
            btn_submit.addClass('spinner spinner-white spinner-right').attr('disabled', true);
            return true;
        };

        var showResponse = function (res, statusText) {
            btn_submit.removeClass('spinner spinner-white spinner-right').attr('disabled', false);
            let url = "<?php echo $_smarty_tpl->tpl_vars['path_url']->value;?>
";
            coreUyuni.generalShowResponse(res,url);

        };

        /**
         * Opciones para generar el objeto del formulario
         */
        var options = {
            beforeSubmit:showRequest
            , success:  showResponse
            , data: {type:'<?php echo $_smarty_tpl->tpl_vars['type']->value;?>
'}
        };

        /**
         * Se da las propiedades de ajaxform al formulario
         */
        var handle_form_submit=function(){
            form.ajaxForm(options);
            formv = FormValidation.formValidation(
                document.getElementById('general_form'),
                {
                    plugins: {
                        declarative: new FormValidation.plugins.Declarative({html5Input: true,}),
                        trigger: new FormValidation.plugins.Trigger(),
                        bootstrap: new FormValidation.plugins.Bootstrap(),
                        submitButton: new FormValidation.plugins.SubmitButton(),
                    }
                }
            );

        };
        /**
         * Se da las funcionalidades al boton enviar
         */
        var handle_btn_submit = function() {
            btn_submit.click(function(e) {
                e.preventDefault();
                /**
                 * Copiamos los datos de summerNote a una variable
                 */
                $('#descripcion_input').val($('#descripcion').summernote('code'));

                formv.validate().then(function(status) {
                    if(status === 'Valid'){
                        form.submit();
                    }else{
                        Swal.fire({icon: 'error',title: lngUyuni.formFieldControlTitle, text: lngUyuni.formFieldControlMsg});
                    }
                });

            });
        };
        /**
         * Iniciamos los componentes necesarios como , summernote, select2 entre otros
         */
        var handle_components = function(){
            coreUyuni.setComponents();
        };

        var handle_type_select = function(){
            $('#type_select_category').on('change',function(){
                handle_type();
            });
        };
        var handle_font_select = function(){
            $('#type_select_font').on('change',function(){
                handle_font();
            });
        };

        var mini_div= $('#mini_div');
        var font_div= $('#font_div');

        var handle_type = function(){
            var id = $('#type_select_category').val();
            id = id==null? '': id.toString();
            console.log(id);
            mini_div.addClass('d-none');
            switch (id){
                case '3':
                    mini_div.removeClass('d-none');
                    break;
            }
        };
        var handle_font = function(){
            var id = $('#type_select_font').val();
            id = id==null? '': id.toString();
            font_div.addClass('d-none');
            switch (id){
                case '1':
                    font_div.removeClass('d-none');
                    break;
            }
        };

        var handle_select_taxonomia = function(){
            $('#catalogo_taxonomia_id').on('change',function(){
                var id = $('#catalogo_taxonomia_id').val();
                $('#kingdom_s').addClass('spinner spinner-right').attr('disabled', true);
                $('#class_s').addClass('spinner spinner-right').attr('disabled', true);
                $('#order_s').addClass('spinner spinner-right').attr('disabled', true);
                $('#family_s').addClass('spinner spinner-right').attr('disabled', true);
                $('#genus_s').addClass('spinner spinner-right').attr('disabled', true);
                $('#scientific_name_authorship_s').addClass('spinner spinner-right').attr('disabled', true);
                if(id!="") {
                    $.post(urlmodule+"/get.item"
                        , {id: id}
                        , function (res, textStatus, jqXHR) {
                            for (var row in res) {
                                $('#kingdom').val(res[row].kingdom);
                                $('#class').val(res[row].class);
                                $('#order').val(res[row].order);
                                $('#family').val(res[row].family);
                                $('#genus').val(res[row].genus);
                                $('#scientific_name_authorship').val(res[row].scientific_name_authorship);
                            }
                            $('#kingdom_s').removeClass('spinner spinner-right').attr('disabled', false);
                            $('#class_s').removeClass('spinner spinner-right').attr('disabled', false);
                            $('#order_s').removeClass('spinner spinner-right').attr('disabled', false);
                            $('#family_s').removeClass('spinner spinner-right').attr('disabled', false);
                            $('#genus_s').removeClass('spinner spinner-right').attr('disabled', false);
                            $('#scientific_name_authorship_s').removeClass('spinner spinner-right').attr('disabled', false);
                        }
                        , 'json');
                }
            });
            // $('#kingdom').prop('disabled', true);
            // $('#class').prop('disabled', true);
        };

        return {
            init: function() {
                handle_form_submit();
                handle_btn_submit();
                handle_components();
                handle_type_select();
                handle_font_select();
                handle_select_taxonomia();
            }
        };
    }();

    //== Class Initialization
    jQuery(document).ready(function() {
        snippet_general_form.init();
    });

<?php echo '</script'; ?>
>
<?php }
}
