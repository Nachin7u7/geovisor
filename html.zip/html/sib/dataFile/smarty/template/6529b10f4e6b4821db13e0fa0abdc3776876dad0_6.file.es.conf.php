<?php /* Smarty version 4.2.1, created on 2023-11-06 08:28:22
         compiled from '/var/www/html/sib/webapp/app/sib/module/taxonomia_p_invertebrado/snippet/index/language/es.conf' */ ?>
<?php
/* Smarty version 4.2.1, created on 2023-11-06 08:28:22
  from '/var/www/html/sib/webapp/app/sib/module/taxonomia_p_invertebrado/snippet/index/language/es.conf' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_6548dbe6b56866_46283640',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6529b10f4e6b4821db13e0fa0abdc3776876dad0' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/taxonomia_p_invertebrado/snippet/index/language/es.conf',
      1 => 1694087965,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6548dbe6b56866_46283640 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigVars($_smarty_tpl, array (
  'sections' => 
  array (
    'index' => 
    array (
      'vars' => 
      array (
        'title' => 'Gestión de Catalogos de Taxonomias',
        'title_filter' => 'Filtro',
        'btnNew' => 'Nueva Taxonomia',
        'filterName' => 'Buscar por nombre de la',
        'filterHolderName' => 'Escribir el nombre institución',
        'filterorma' => 'Buscar por norma',
        'filterNormaSelectAll' => 'Todas las normas',
        'filterStatus' => 'Estado',
        'filterStatusSelectAll' => 'Todos los estados',
        'dataTableExportTitle' => 'Lista de INSTITUCIONES CIENTIFICAS AUTORIZADAS',
      ),
    ),
    'tableIndex' => 
    array (
      'vars' => 
      array (
        'table_scientific_name' => 'Nombre Científico',
        'table_kingdom' => 'Reino',
        'table_class' => 'Clase',
        'table_order' => 'Orden',
        'table_family' => 'Familia',
        'table_genus' => 'Género',
      ),
    ),
    'item' => 
    array (
      'vars' => 
      array (
        'title' => 'Gestión de Catalogos Taxonomicos',
      ),
    ),
    'tabItem' => 
    array (
      'vars' => 
      array (
        'tabGeneral' => 'General',
        'tab_foto' => 'Fotografias',
      ),
    ),
  ),
  'vars' => 
  array (
  ),
));
}
}
