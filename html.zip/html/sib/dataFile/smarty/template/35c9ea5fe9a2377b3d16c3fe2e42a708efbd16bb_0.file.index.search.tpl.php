<?php
/* Smarty version 4.2.1, created on 2022-11-10 11:06:30
  from '/var/www/html/sib/webapp/app/setting/module/user/snippet/index/view/index.search.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_636d137699c0a6_35873371',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '35c9ea5fe9a2377b3d16c3fe2e42a708efbd16bb' => 
    array (
      0 => '/var/www/html/sib/webapp/app/setting/module/user/snippet/index/view/index.search.tpl',
      1 => 1668028010,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_636d137699c0a6_35873371 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_checkPlugins(array(0=>array('file'=>'/var/www/html/sib/vendor/smarty/smarty/libs/plugins/function.html_options.php','function'=>'smarty_function_html_options',),));
?>
<div class="row alert alert-custom alert-light-primary fade show mb-5" role="alert" >
    <div class="col-lg-4 alert-text">
        <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'filterName');?>
:</label>
        <input type="text" class="filtro-buscar-text form-control m-input" placeholder="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'filterName');?>
" data-col-index="0">
    </div>
    <div class="col-lg-4 alert-text">
        <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'filterLastName');?>
:</label>
        <input type="text" class="filtro-buscar-text form-control m-input" placeholder="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'filterLastName');?>
" data-col-index="1">
    </div>


    <div class="col-lg-4 alert-text">
        <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'filterType');?>
:</label>
        <select class="filtro-buscar form-control m-input select2_busqueda"
                data-placeholder="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'filterHolderType');?>
" data-col-index="4">
            <option value="3""><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'filterAppStatusSelectAll');?>
</option>
            <?php echo smarty_function_html_options(array('options'=>$_smarty_tpl->tpl_vars['cataobj']->value['tipo']),$_smarty_tpl);?>

        </select>
    </div>

</div>

<?php }
}
