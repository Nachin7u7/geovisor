<?php
/* Smarty version 4.2.1, created on 2023-04-07 09:18:00
  from '/var/www/html/sib/webapp/app/sib/module/zoologia_ictiologia/snippet/general/view/index.css.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_64301808f00aa2_70845212',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '0124e87d4e9c8cb946173b18a727f5c7ed08eb2d' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/zoologia_ictiologia/snippet/general/view/index.css.tpl',
      1 => 1677671930,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_64301808f00aa2_70845212 (Smarty_Internal_Template $_smarty_tpl) {
?>
    <style>
        .select2-results__group{
            background: #e7f1f6;
            border-bottom: 2px solid #006ba2;
        }

        .proyecto{
            background: #c0deed;
            border-bottom: 1px solid #dfeff7;
            border-top: 1px solid #dfeff7;
        }
        .proyecto label{
            color: #059ded;
        }

    </style>
<?php }
}
