<?php
/* Smarty version 4.2.1, created on 2022-11-09 17:48:36
  from '/var/www/html/sib/webapp/app/sib/module/user/snippet/general/view/index.css.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_636c2034f12154_34111522',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '74246479db2e28dfad510557bf76147e51dfc14d' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/user/snippet/general/view/index.css.tpl',
      1 => 1668028010,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_636c2034f12154_34111522 (Smarty_Internal_Template $_smarty_tpl) {
?>
    <style>
        .select2-results__group{
            background: #e7f1f6;
            border-bottom: 2px solid #006ba2;
        }
    </style>
<?php }
}
