<?php
/* Smarty version 4.2.1, created on 2023-09-14 21:55:52
  from '/var/www/html/sib/webapp/app/core/template/base/baseAjax.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_6503b9a81bc9e0_16577058',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '5981b97246dfb6b0a666e2ea99ee972c67576dc1' => 
    array (
      0 => '/var/www/html/sib/webapp/app/core/template/base/baseAjax.tpl',
      1 => 1668028010,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6503b9a81bc9e0_16577058 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender(((string)$_smarty_tpl->tpl_vars['subpage']->value), $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, true);
}
}
