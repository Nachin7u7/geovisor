<?php
/* Smarty version 4.2.1, created on 2023-03-02 08:38:06
  from '/var/www/html/sib/webapp/app/sib/module/zoologia_herpetologia/snippet/taxonomia/view/index.css.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_640098ae70ca13_03107120',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '23399e287a151102d22060ecf8c9730e4d2b97c8' => 
    array (
      0 => '/var/www/html/sib/webapp/app/sib/module/zoologia_herpetologia/snippet/taxonomia/view/index.css.tpl',
      1 => 1677146357,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_640098ae70ca13_03107120 (Smarty_Internal_Template $_smarty_tpl) {
?>
    <style>
        .select2-results__group{
            background: #e7f1f6;
            border-bottom: 2px solid #006ba2;
        }

    </style>
<?php }
}
